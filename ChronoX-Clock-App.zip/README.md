# ChronoX – Native Android Clock

Fully native (Kotlin + Jetpack Compose, no WebView) clock app:
Alarms, World Clock with a real-time 3D Earth (day/night), Stopwatch and Timer.

## Build the APK on GitHub
1. Create a new GitHub repository and upload **all files of this folder** (keep the `.github` folder).
2. Open the **Actions** tab -> *Build ChronoX APK* runs automatically (or press *Run workflow*).
3. When it finishes, open the run and download **ChronoX-debug-apk** (or release-apk) from *Artifacts*.
4. Unzip it and install the `.apk` on your phone.

## First launch
Allow notifications, and (Android 14+) allow "full-screen notifications" when asked so the alarm
screen can appear on the lock screen.
