package com.chronox.clock

import android.content.Context
import android.media.*
import android.net.Uri
import android.os.Handler
import android.os.Looper
import android.os.VibrationEffect
import android.os.Vibrator
import kotlin.math.*

object ToneSynth {
    const val SR = 22050
    val NAMES = listOf("Sunrise", "Digital", "Crystal", "Radar", "System alarm", "Ringtone", "Notification", "Device tone")

    private fun add(buf: FloatArray, start: Float, dur: Float, freq: Float, amp: Float, decay: Float, harm: Float = 0.25f, bell: Boolean = false) {
        val s0 = (start * SR).toInt()
        val n = (dur * SR).toInt()
        val partials = if (bell) floatArrayOf(1f, 2.76f, 5.4f, 8.93f) else floatArrayOf(1f, 2f, 3f)
        val gains = if (bell) floatArrayOf(1f, 0.55f, 0.3f, 0.15f) else floatArrayOf(1f, harm, harm * 0.4f)
        for (i in 0 until n) {
            val idx = s0 + i
            if (idx >= buf.size) break
            val t = i.toFloat() / SR
            val env = min(1f, t / 0.006f) * exp(-decay * t)
            var v = 0f
            for (k in partials.indices) {
                val d = if (bell) exp(-decay * (0.6f + k * 0.8f) * t) / max(0.0001f, exp(-decay * t)) else 1f
                v += sin(2.0 * PI * freq * partials[k] * t).toFloat() * gains[k] * d
            }
            buf[idx] += v * env * amp
        }
    }

    fun make(type: Int): ShortArray {
        val len: Float = when (type) { 0 -> 4.0f; 1 -> 1.6f; 2 -> 3.2f; else -> 2.2f }
        val f = FloatArray((len * SR).toInt())
        when (type) {
            0 -> { // rising arpeggio chime
                val notes = floatArrayOf(523.25f, 659.25f, 783.99f, 1046.5f, 1318.5f, 1046.5f, 783.99f, 659.25f)
                for (i in notes.indices) add(f, i * 0.42f, 1.0f, notes[i], 0.35f, 3.2f)
            }
            1 -> { // digital beeps
                for (g in 0 until 2) for (b in 0 until 4) add(f, g * 0.8f + b * 0.14f, 0.09f, 1900f, 0.4f, 6f, 0.5f)
            }
            2 -> { // glass bell
                add(f, 0.0f, 1.6f, 880f, 0.3f, 2.2f, 0.2f, true)
                add(f, 1.5f, 1.6f, 1174.7f, 0.3f, 2.2f, 0.2f, true)
            }
            else -> { // radar ping
                for (i in 0 until 3) add(f, i * 0.7f, 0.6f, 1320f, 0.45f / (1 + i * 0.7f), 7f, 0.1f)
            }
        }
        var peak = 0.0001f
        for (v in f) peak = max(peak, abs(v))
        val g = 0.85f / peak
        return ShortArray(f.size) { (max(-1f, min(1f, f[it] * g)) * 32000f).toInt().toShort() }
    }
}

class AlarmPlayer(private val ctx: Context) {
    private var track: AudioTrack? = null
    private var mp: MediaPlayer? = null
    private val vib: Vibrator? = ctx.getSystemService(Context.VIBRATOR_SERVICE) as? Vibrator
    private val h = Handler(Looper.getMainLooper())
    private var vol = 1f
    private var ramp: Runnable? = null

    companion object {
        val PATTERNS: Array<LongArray?> = arrayOf(
            null,
            longArrayOf(0, 900, 500),
            longArrayOf(0, 120, 120, 120, 700),
            longArrayOf(0, 250, 150),
            longArrayOf(0, 100, 100, 200, 100, 300, 100, 400, 100, 500, 400),
            longArrayOf(0, 150, 150, 150, 150, 150, 300, 400, 150, 400, 150, 400, 300, 150, 150, 150, 150, 150, 900)
        )
        val VIBE_NAMES = listOf("Off", "Classic", "Heartbeat", "Rapid", "Wave", "SOS")
    }

    private fun setVol(v: Float) {
        vol = v
        try { track?.setVolume(v) } catch (e: Exception) { }
        try { mp?.setVolume(v, v) } catch (e: Exception) { }
    }

    fun start(sound: Int, uri: String?, gradual: Boolean, vibe: Int) {
        stop()
        val attrs = AudioAttributes.Builder().setUsage(AudioAttributes.USAGE_ALARM)
            .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION).build()
        var useSynth = sound in 0..3
        if (!useSynth) {
            try {
                val u: Uri = when {
                    sound == 7 && uri != null -> Uri.parse(uri)
                    sound == 5 -> RingtoneManager.getDefaultUri(RingtoneManager.TYPE_RINGTONE)
                    sound == 6 -> RingtoneManager.getDefaultUri(RingtoneManager.TYPE_NOTIFICATION)
                    else -> RingtoneManager.getDefaultUri(RingtoneManager.TYPE_ALARM)
                }
                val m = MediaPlayer()
                m.setAudioAttributes(attrs)
                m.setDataSource(ctx, u)
                m.isLooping = true
                m.prepare()
                m.start()
                mp = m
            } catch (e: Exception) { mp = null; useSynth = true }
        }
        if (useSynth) {
            try {
                val pcm = ToneSynth.make(if (sound in 0..3) sound else 0)
                val at = AudioTrack.Builder()
                    .setAudioAttributes(attrs)
                    .setAudioFormat(AudioFormat.Builder().setSampleRate(ToneSynth.SR)
                        .setEncoding(AudioFormat.ENCODING_PCM_16BIT).setChannelMask(AudioFormat.CHANNEL_OUT_MONO).build())
                    .setBufferSizeInBytes(pcm.size * 2)
                    .setTransferMode(AudioTrack.MODE_STATIC).build()
                at.write(pcm, 0, pcm.size)
                at.setLoopPoints(0, pcm.size, -1)
                at.play()
                track = at
            } catch (e: Exception) { }
        }
        if (gradual) {
            setVol(0.08f)
            val r = object : Runnable {
                override fun run() {
                    setVol(min(1f, vol + 0.035f))
                    if (vol < 1f) h.postDelayed(this, 700)
                }
            }
            ramp = r; h.postDelayed(r, 700)
        } else setVol(1f)
        vibrate(vibe)
    }

    fun vibrate(vibe: Int) {
        val p = PATTERNS.getOrNull(vibe) ?: return
        try {
            vib?.vibrate(VibrationEffect.createWaveform(p, 0),
                AudioAttributes.Builder().setUsage(AudioAttributes.USAGE_ALARM).build())
        } catch (e: Exception) { }
    }

    fun stop() {
        ramp?.let { h.removeCallbacks(it) }; ramp = null
        try { track?.stop() } catch (e: Exception) { }
        try { track?.release() } catch (e: Exception) { }
        track = null
        try { mp?.stop() } catch (e: Exception) { }
        try { mp?.release() } catch (e: Exception) { }
        mp = null
        try { vib?.cancel() } catch (e: Exception) { }
    }
}
