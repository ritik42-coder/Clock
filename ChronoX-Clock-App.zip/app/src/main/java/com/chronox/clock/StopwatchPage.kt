package com.chronox.clock

import android.content.Context
import android.graphics.*
import android.view.*
import android.view.animation.DecelerateInterpolator
import android.view.animation.OvershootInterpolator
import android.widget.*
import kotlin.math.*

fun fmtSw(ms: Long): String {
    val cs = (ms / 10) % 100; val s = (ms / 1000) % 60; val m = (ms / 60000) % 60; val h = ms / 3600000
    return (if (h > 0) "$h:${two(m.toInt())}" else two(m.toInt())) + ":" + two(s.toInt()) + "." + two(cs.toInt())
}

class StopDial(ctx: Context) : View(ctx) {
    var elapsed = 0L; var running = false
    private val track = strokePaint(0x1AFFFFFF, dp(8)); private val tick = strokePaint(Color.WHITE, dp(2))
    private val arc = strokePaint(Color.WHITE, dp(8)); private val hand = strokePaint(C.ORANGE, dp(3))
    private val dotP = fillPaint(); private val big = textPaint(C.TEXT, dp(54), THIN, Paint.Align.CENTER)
    private val small = textPaint(C.ORANGE, dp(24), LIGHT, Paint.Align.CENTER)
    private val oval = RectF(); private val m = Matrix()
    override fun onDraw(c: Canvas) {
        val cx = width / 2f; val cy = height / 2f; val R = min(width, height) * 0.40f
        val frac = (elapsed % 60000L) / 60000f
        val handDeg = frac * 360f - 90f
        for (i in 0 until 60) {
            val ang = Math.toRadians(i * 6.0 - 90.0); val big5 = i % 5 == 0
            val near = 1f - min(1f, abs(((i / 60f) - frac + 1.5f) % 1f - 0.5f) * 10f)
            tick.color = mixColor(if (big5) 0x88FFFFFF.toInt() else 0x33FFFFFF, C.ORANGE, if (running || elapsed > 0) max(0f, near) else 0f)
            tick.strokeWidth = dp(if (big5) 2.6f else 1.6f)
            val r1 = R + dp(if (big5) 20 else 24); val r2 = R + dp(32)
            c.drawLine(cx + cos(ang).toFloat() * r1, cy + sin(ang).toFloat() * r1, cx + cos(ang).toFloat() * r2, cy + sin(ang).toFloat() * r2, tick)
        }
        oval.set(cx - R, cy - R, cx + R, cy + R)
        c.drawCircle(cx, cy, R, track)
        if (elapsed > 0) {
            val trail = 90f
            val sh = SweepGradient(cx, cy, intArrayOf(0x00FF9F43, C.MAGENTA, 0x00FF4FD8, 0x00FF4FD8), floatArrayOf(0f, trail / 360f, trail / 360f + 0.001f, 1f))
            m.reset(); m.postRotate(handDeg - trail, cx, cy); sh.setLocalMatrix(m)
            arc.shader = sh; c.drawArc(oval, handDeg - trail, trail, false, arc)
            val a = Math.toRadians(handDeg.toDouble()); val hx = cx + cos(a).toFloat() * R; val hy = cy + sin(a).toFloat() * R
            hand.color = C.ORANGE; c.drawLine(cx + cos(a).toFloat() * R * 0.62f, cy + sin(a).toFloat() * R * 0.62f, hx, hy, hand)
            dotP.color = alphaColor(C.ORANGE, 0.3f); c.drawCircle(hx, hy, dp(14), dotP)
            dotP.color = Color.WHITE; c.drawCircle(hx, hy, dp(5.5f), dotP)
        }
        val t = fmtSw(elapsed); val main = t.substring(0, t.length - 3); val cs = t.substring(t.length - 3)
        big.textSize = if (main.length > 5) R * 0.34f else R * 0.46f
        c.drawText(main, cx, cy + R * 0.10f, big)
        c.drawText(cs, cx, cy + R * 0.42f, small)
        if (running) postInvalidateOnAnimation()
    }
}

class StopwatchPage(ctx: Context) : Page(ctx) {
    private val dial = StopDial(ctx)
    private val title = tv(ctx, "Stopwatch", 34f, C.TEXT, THIN)
    private val leftBtn = CircleBtn(ctx, dp(72), false)
    private val rightBtn = CircleBtn(ctx, dp(92), true)
    private val btnRow = LinearLayout(ctx)
    private val scroll = FxScrollView(ctx, 0.8f)
    private val list = LinearLayout(ctx).apply { orientation = LinearLayout.VERTICAL }
    private val loop = FrameLoop { frame() }
    private var lastRun: Boolean? = null
    private var lapCount = -1

    init {
        addView(title, LayoutParams(-2, -2).apply { leftMargin = dpi(24) })
        addView(dial, LayoutParams(-1, dpi(330), Gravity.TOP))
        rightBtn.accent = C.ORANGE; rightBtn.accent2 = C.MAGENTA
        btnRow.orientation = LinearLayout.HORIZONTAL; btnRow.gravity = Gravity.CENTER
        btnRow.addView(leftBtn, LinearLayout.LayoutParams(dpi(72), dpi(72)).apply { rightMargin = dpi(40) })
        btnRow.addView(rightBtn, LinearLayout.LayoutParams(dpi(92), dpi(92)))
        addView(btnRow, LayoutParams(-1, -2, Gravity.TOP))
        scroll.addView(list, FrameLayout.LayoutParams(-1, -2)); addView(scroll, LayoutParams(-1, -1, Gravity.TOP))
        rightBtn.setOnClickListener { hold(); StopwatchStore.toggle(context) }
        leftBtn.setOnClickListener {
            thud()
            if (StopwatchStore.running(context)) { StopwatchStore.addLap(context); rebuildLaps(true) }
            else { StopwatchStore.reset(context); rebuildLaps(false) }
        }
        rebuildLaps(false)
    }

    override fun applyInsets() {
        (title.layoutParams as LayoutParams).topMargin = topInset + dpi(18)
        val top = topInset + dpi(70)
        (dial.layoutParams as LayoutParams).topMargin = top
        (btnRow.layoutParams as LayoutParams).topMargin = top + dpi(332)
        (scroll.layoutParams as LayoutParams).topMargin = top + dpi(445)
        scroll.setPadding(dpi(22), dpi(6), dpi(22), bottomInset + dpi(20))
        requestLayout()
    }
    override fun onShow() { loop.start() }
    override fun onHide() { loop.stop() }
    override fun onAttachedToWindow() { super.onAttachedToWindow(); loop.start() }
    override fun onDetachedFromWindow() { loop.stop(); super.onDetachedFromWindow() }
    override fun playEntrance() {
        listOf<View>(dial, btnRow, scroll).forEachIndexed { i, v -> v.alpha = 0f; v.translationY = dp(50); v.animate().alpha(1f).translationY(0f).setStartDelay(i * 90L).setDuration(500).setInterpolator(DecelerateInterpolator(2f)).start() }
    }

    private fun frame() {
        val run = StopwatchStore.running(context); val el = StopwatchStore.elapsed(context)
        dial.elapsed = el; dial.running = run
        if (lastRun != run) {
            lastRun = run
            rightBtn.setIcon(if (run) CircleBtn.PAUSE else CircleBtn.PLAY)
            leftBtn.setIcon(if (run) CircleBtn.LAP else CircleBtn.RESET)
            dial.invalidate()
        }
        leftBtn.dimmed = !run && el == 0L
        if (!run) dial.invalidate()
    }

    private fun rebuildLaps(animateTop: Boolean) {
        val laps = StopwatchStore.laps(context)
        list.removeAllViews()
        if (laps.isEmpty()) { lapCount = 0; return }
        val splits = laps.mapIndexed { i, v -> v - (if (i == 0) 0L else laps[i - 1]) }
        val best = splits.minOrNull(); val worst = splits.maxOrNull()
        for (i in laps.indices.reversed()) {
            val row = LinearLayout(context).apply {
                orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL; setPadding(dpi(18), dpi(14), dpi(18), dpi(14)); background = glassBg(dp(18))
            }
            val col = if (laps.size >= 3 && splits[i] == best) C.GREEN else if (laps.size >= 3 && splits[i] == worst) C.RED else C.TEXT
            row.addView(tv(context, "Lap ${i + 1}", 15f, C.DIM, MED), LinearLayout.LayoutParams(0, -2, 1f))
            row.addView(tv(context, fmtSw(splits[i]), 18f, col, LIGHT).apply { gravity = Gravity.END }, LinearLayout.LayoutParams(0, -2, 1.3f))
            row.addView(tv(context, fmtSw(laps[i]), 14f, C.DIM, REG).apply { gravity = Gravity.END }, LinearLayout.LayoutParams(0, -2, 1.2f))
            list.addView(row, LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = dpi(8) })
            if (animateTop && i == laps.size - 1) {
                row.alpha = 0f; row.translationY = -dp(40); row.scaleX = 0.92f
                row.animate().alpha(1f).translationY(0f).scaleX(1f).setDuration(420).setInterpolator(OvershootInterpolator(1.2f)).start()
            }
        }
        scroll.post { scroll.applyFx() }
    }
}
