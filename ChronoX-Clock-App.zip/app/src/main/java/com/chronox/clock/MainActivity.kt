package com.chronox.clock

import android.Manifest
import android.app.Activity
import android.app.NotificationManager
import android.content.*
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.FrameLayout
import androidx.core.content.ContextCompat
import androidx.core.view.ViewCompat
import androidx.core.view.WindowCompat
import androidx.core.view.WindowInsetsCompat
import android.view.animation.DecelerateInterpolator

class MainActivity : Activity() {
    private lateinit var root: FrameLayout
    private lateinit var aurora: AuroraView
    private lateinit var nav: BottomNavView
    private lateinit var pages: Array<Page>
    private lateinit var holder: FrameLayout
    private var cur = 0
    private var splash: SplashView? = null
    private var inTop = 0; private var inBottom = 0

    private val ringRcv = object : BroadcastReceiver() {
        override fun onReceive(c: Context, i: Intent) {
            if (i.action == AlarmService.ACTION_RING_START) {
                try { startActivity(Intent(this@MainActivity, AlarmRingActivity::class.java).putExtras(i).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP)) } catch (e: Exception) { }
            }
        }
    }

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        DENSITY = resources.displayMetrics.density
        WindowCompat.setDecorFitsSystemWindows(window, false)
        root = FrameLayout(this)
        aurora = AuroraView(this); root.addView(aurora, FrameLayout.LayoutParams(-1, -1))
        holder = FrameLayout(this); root.addView(holder, FrameLayout.LayoutParams(-1, -1))
        pages = arrayOf(AlarmPage(this), WorldPage(this), TimerPage(this), StopwatchPage(this))
        for ((i, p) in pages.withIndex()) { holder.addView(p, FrameLayout.LayoutParams(-1, -1)); p.visibility = if (i == 0) View.VISIBLE else View.GONE }
        nav = BottomNavView(this)
        root.addView(nav, FrameLayout.LayoutParams(-1, -2, Gravity.BOTTOM).apply { leftMargin = dpi(18); rightMargin = dpi(18); bottomMargin = dpi(12) })
        nav.onSelect = { switchTo(it) }
        ViewCompat.setOnApplyWindowInsetsListener(root) { _, ins ->
            val bars = ins.getInsets(WindowInsetsCompat.Type.systemBars())
            inTop = bars.top; inBottom = bars.bottom
            (nav.layoutParams as FrameLayout.LayoutParams).bottomMargin = inBottom + dpi(12); nav.requestLayout()
            for (p in pages) p.setInsets(inTop, inBottom + dpi(76) + dpi(12))
            ins
        }
        setContentView(root)
        // intro
        nav.alpha = 0f; holder.alpha = 0f
        val sp = SplashView(this, {
            holder.animate().alpha(1f).setDuration(500).start()
            nav.translationY = dp(90); nav.animate().alpha(1f).translationY(0f).setDuration(650).setInterpolator(DecelerateInterpolator(2f)).start()
            pages[cur].onShow(); pages[cur].playEntrance()
        }, {
            root.removeView(splash); splash = null; askPermissions()
        })
        splash = sp
        root.addView(sp, FrameLayout.LayoutParams(-1, -1))
        Scheduler.rescheduleAll(this)
    }

    private fun switchTo(i: Int) {
        if (i == cur) return
        val old = pages[cur]; val nw = pages[i]; val dir = if (i > cur) 1 else -1
        old.onHide(); old.animate().cancel()
        old.animate().alpha(0f).translationX(-dir * dp(50)).scaleX(0.94f).scaleY(0.94f).setDuration(240).withEndAction {
            if (cur != pages.indexOf(old)) old.visibility = View.GONE; old.alpha = 1f; old.translationX = 0f; old.scaleX = 1f; old.scaleY = 1f
        }.start()
        cur = i
        nw.animate().cancel(); nw.visibility = View.VISIBLE; nw.alpha = 0f; nw.translationX = dir * dp(60); nw.scaleX = 0.96f; nw.scaleY = 0.96f
        nw.animate().alpha(1f).translationX(0f).scaleX(1f).scaleY(1f).setDuration(420).setInterpolator(DecelerateInterpolator(2f)).start()
        nw.onShow(); nw.playEntrance()
        aurora.setTab(i)
    }

    private fun askPermissions() {
        if (Build.VERSION.SDK_INT >= 33 && checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != android.content.pm.PackageManager.PERMISSION_GRANTED)
            requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 1)
        else askFullScreen()
    }
    override fun onRequestPermissionsResult(code: Int, p: Array<out String>, r: IntArray) { super.onRequestPermissionsResult(code, p, r); askFullScreen() }
    private fun askFullScreen() {
        if (Build.VERSION.SDK_INT >= 34) {
            val nm = getSystemService(NotificationManager::class.java)
            val sp = getSharedPreferences("app", Context.MODE_PRIVATE)
            if (!nm.canUseFullScreenIntent() && !sp.getBoolean("fsAsked", false)) {
                sp.edit().putBoolean("fsAsked", true).apply()
                try { startActivity(Intent(Settings.ACTION_MANAGE_APP_USE_FULL_SCREEN_INTENT, Uri.parse("package:$packageName"))) } catch (e: Exception) { }
            }
        }
    }

    override fun onResume() {
        super.onResume()
        ContextCompat.registerReceiver(this, ringRcv, IntentFilter(AlarmService.ACTION_RING_START), ContextCompat.RECEIVER_NOT_EXPORTED)
        if (splash == null) pages[cur].onShow()
    }
    override fun onPause() { super.onPause(); try { unregisterReceiver(ringRcv) } catch (e: Exception) { }; pages[cur].onHide() }

    @Suppress("OVERRIDE_DEPRECATION")
    override fun onBackPressed() {
        val p = pages[cur]
        if (p is AlarmPage && p.handleBack()) return
        if (p is WorldPage && p.handleBack()) return
        super.onBackPressed()
    }
}
