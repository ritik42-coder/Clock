package com.chronox.clock

import android.app.Activity
import android.os.Bundle
import android.view.Gravity
import android.view.WindowManager
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.TextView
import androidx.core.view.WindowCompat

class SolarActivity : Activity() {
    private lateinit var sv: SolarView
    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        DENSITY = resources.displayMetrics.density
        WindowCompat.setDecorFitsSystemWindows(window, false)
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        val root = FrameLayout(this)
        sv = SolarView(this); root.addView(sv, FrameLayout.LayoutParams(-1, -1))
        val panel = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dpi(12), dpi(12), dpi(12), dpi(10)); background = glassBg(dp(28), 0xCC0B1022.toInt()) }
        val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        var playBtn: TextView? = null
        playBtn = ghostButton(this, "Pause", C.CYAN) { sv.playing = !sv.playing; playBtn?.text = if (sv.playing) "Pause" else "Play" }.apply { textSize = 14f }
        row.addView(playBtn, LinearLayout.LayoutParams(0, dpi(44), 1f).apply { rightMargin = dpi(8) })
        row.addView(ghostButton(this, "Today", C.TEXT) { sv.today() }.apply { textSize = 14f }, LinearLayout.LayoutParams(0, dpi(44), 1f).apply { rightMargin = dpi(8) })
        row.addView(ghostButton(this, "System view", C.VIOLET) { sv.goOverview() }.apply { textSize = 14f }, LinearLayout.LayoutParams(0, dpi(44), 1.3f))
        panel.addView(row, LinearLayout.LayoutParams(-1, -2))
        val speedRow = ChipRow(this, Solar.SPEED_NAMES, 4, C.CYAN) { sv.setSpeedIndex(it) }
        panel.addView(speedRow, LinearLayout.LayoutParams(-1, -2).apply { topMargin = dpi(10) })
        val layers = ToggleRow(this, listOf("Orbits" to true, "Labels" to true, "Moons" to true, "Asteroids" to true, "True scale" to false), C.VIOLET) { i, on ->
            when (i) { 0 -> sv.showOrbits = on; 1 -> sv.showLabels = on; 2 -> sv.showMoons = on; 3 -> sv.showBelt = on; else -> sv.trueScale = on }
            Unit
        }
        panel.addView(layers, LinearLayout.LayoutParams(-1, -2).apply { topMargin = dpi(8) })
        root.addView(panel, FrameLayout.LayoutParams(-1, -2, Gravity.BOTTOM).apply { leftMargin = dpi(10); rightMargin = dpi(10); bottomMargin = dpi(22) })
        sv.onSpeedAuto = { idx -> speedRow.post { speedRow.select(idx, true) } }
        sv.onExit = { finish() }
        sv.bottomPad = dp(236)
        setContentView(root)
    }
    override fun onResume() { super.onResume(); sv.start() }
    override fun onPause() { super.onPause(); sv.stop() }
}
