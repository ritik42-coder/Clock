package com.chronox.clock

import android.content.Context
import android.graphics.*
import android.hardware.GeomagneticField
import android.hardware.Sensor
import android.hardware.SensorEvent
import android.hardware.SensorEventListener
import android.hardware.SensorManager
import android.os.SystemClock
import android.view.GestureDetector
import android.view.MotionEvent
import android.view.ScaleGestureDetector
import android.view.View
import java.util.TimeZone
import kotlin.math.*

private class SItem(val id: Int, val name: String, val mag: Float) {
    var x = 0f; var y = 0f; var vis = false; var alt = 0f; var az = 0f; var ra = 0.0; var dec = 0.0
}

class SkyView(ctx: Context) : View(ctx), SensorEventListener {
    var onExit: (() -> Unit)? = null
    var bottomPad = dp(236)
    var camOn = false
    var showLines = true; var showGrid = false; var showLabels = true; var showDeep = true
    var dragMode = false
    var fov = 70f
    var locNote = "approximate location"
    private var lat = 28.6; private var lon = 77.2; private var decl = 0.0
    private val is24 = android.text.format.DateFormat.is24HourFormat(ctx)

    private val sm = ctx.getSystemService(Context.SENSOR_SERVICE) as SensorManager
    private val rvSensor: Sensor? = sm.getDefaultSensor(Sensor.TYPE_ROTATION_VECTOR)
    private val magSensor: Sensor? = sm.getDefaultSensor(Sensor.TYPE_MAGNETIC_FIELD)
    private val rm = FloatArray(9)
    private val R = floatArrayOf(1f, 0f, 0f, 0f, 1f, 0f, 0f, 0f, 1f)
    private var gotRot = false
    private var magAcc = SensorManager.SENSOR_STATUS_ACCURACY_HIGH
    private var yawT = 0f; private var pitchT = 0.5f

    private val items = ArrayList<SItem>()
    private val stars: Array<SItem>
    private val sunI = SItem(0, "Sun", -26.7f)
    private val moonI = SItem(1, "Moon", -12f)
    private val planI = HashMap<Int, SItem>()
    private val dsoI: Array<SItem>
    private var moonIllum = 0.5; private var moonWax = true
    private var sunAlt = -30.0

    private val fill = fillPaint(); private val line = strokePaint(Color.WHITE, dp(1.2f)).apply { strokeCap = Paint.Cap.ROUND }
    private val txt = textPaint(Color.WHITE, dp(11), MED, Paint.Align.LEFT)
    private val txtS = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.STROKE; color = 0xCC000814.toInt(); strokeWidth = dp(2.4f); typeface = MED; textSize = dp(11); strokeJoin = Paint.Join.ROUND }
    private val glow = Paint(Paint.ANTI_ALIAS_FLAG).apply { xfermode = PorterDuffXfermode(PorterDuff.Mode.SCREEN) }
    private val path = Path(); private val rect = RectF(); private val backR = RectF(); private val card = RectF()
    private val placed = ArrayList<RectF>()
    private val lineBuf = FloatArray(700 * 4)
    private val pj = FloatArray(3); private val aa = DoubleArray(2); private val eq = DoubleArray(5)
    private var cx = 0f; private var cy = 0f; private var F = 1f; private var vw = 0f; private var vh = 0f
    private var decR = 0.0
    private var lastT = 0L
    private var sel: SItem? = null
    private var infoTitle = ""; private var infoLines: List<String> = emptyList(); private var infoJd = 0.0

    private var downX = 0f; private var downY = 0f; private var moved = 0f; private var downT = 0L
    private val scaleDet = ScaleGestureDetector(ctx, object : ScaleGestureDetector.SimpleOnScaleGestureListener() {
        override fun onScale(d: ScaleGestureDetector): Boolean { if (!camOn) fov = (fov / d.scaleFactor).coerceIn(25f, 110f); return true }
    })

    init {
        stars = Array(SkyData.ALL.size) { SItem(100 + it, SkyData.ALL[it].name, SkyData.ALL[it].mag) }
        dsoI = Array(SkyData.DEEP.size) { SItem(200 + it, SkyData.DEEP[it].name, 4f) }
        for (p in intArrayOf(1, 2, 4, 5, 6, 7, 8)) planI[10 + p] = SItem(10 + p, Solar.NAMES[p], 0f)
        items.add(sunI); items.add(moonI); items.addAll(planI.values); items.addAll(dsoI); items.addAll(stars)
        setLocation(lat, lon, locNote)
    }

    fun setLocation(la: Double, lo: Double, note: String) {
        lat = la; lon = lo; locNote = note
        decl = try { GeomagneticField(la.toFloat(), lo.toFloat(), 0f, System.currentTimeMillis()).declination.toDouble() } catch (e: Exception) { 0.0 }
    }
    val hasSensor: Boolean get() = rvSensor != null
    fun start() {
        rvSensor?.let { sm.registerListener(this, it, SensorManager.SENSOR_DELAY_GAME) }
        magSensor?.let { sm.registerListener(this, it, SensorManager.SENSOR_DELAY_NORMAL) }
        invalidate()
    }
    fun stop() { sm.unregisterListener(this) }
    override fun onDetachedFromWindow() { stop(); super.onDetachedFromWindow() }
    override fun onSensorChanged(e: SensorEvent) {
        if (e.sensor.type == Sensor.TYPE_ROTATION_VECTOR) {
            SensorManager.getRotationMatrixFromVector(rm, e.values)
            if (!gotRot) { for (k in 0..8) R[k] = rm[k]; gotRot = true }
            else for (k in 0..8) R[k] += (rm[k] - R[k]) * 0.22f
        }
    }
    override fun onAccuracyChanged(s: Sensor?, a: Int) { if (s != null && s.type == Sensor.TYPE_MAGNETIC_FIELD) magAcc = a }

    fun select(id: Int) { sel = items.firstOrNull { it.id == id }; sel?.let { buildInfo(it, SkyMath.jd(Tt.now())) } }
    fun selectStar(name: String) { val i = SkyData.ALL.indexOfFirst { it.name == name }; if (i >= 0) select(100 + i) }

    // ------------------------------------------------------------------ geometry
    private fun projE(x: Float, y: Float, z: Float): Boolean {
        val dz = R[2] * x + R[5] * y + R[8] * z
        if (dz > -0.02f) return false
        val dx = R[0] * x + R[3] * y + R[6] * z; val dy = R[1] * x + R[4] * y + R[7] * z; val t = -dz
        pj[0] = cx + F * dx / t; pj[1] = cy - F * dy / t; pj[2] = t
        return true
    }
    private fun enuProj(alt: Double, az: Double): Boolean {
        val a = az - decR
        return projE((cos(alt) * sin(a)).toFloat(), (cos(alt) * cos(a)).toFloat(), sin(alt).toFloat())
    }
    private fun place(it: SItem, ra: Double, dec: Double, latR: Double, lstR: Double) {
        it.ra = ra; it.dec = dec
        SkyMath.altAz(ra, dec, latR, lstR, aa); it.alt = aa[0].toFloat(); it.az = aa[1].toFloat()
        it.vis = enuProj(aa[0], aa[1]); it.x = pj[0]; it.y = pj[1]
    }
    private fun smooth(e0: Double, e1: Double, x: Double): Float { val t = ((x - e0) / (e1 - e0)).coerceIn(0.0, 1.0); return (t * t * (3 - 2 * t)).toFloat() }

    // ------------------------------------------------------------------ info card
    private fun altOf(id: Int, jd: Double): Double {
        val latR = Math.toRadians(lat); val lstR = Math.toRadians(SkyMath.gmstDeg(jd) + lon)
        val e = DoubleArray(5)
        when {
            id == 0 -> SkyMath.sunEq(jd, e)
            id == 1 -> SkyMath.moonEq(jd, e)
            id in 10..18 -> SkyMath.planetEq(id - 10, jd, e)
            id >= 200 -> { e[0] = SkyData.DEEP[id - 200].ra * PI / 12.0; e[1] = Math.toRadians(SkyData.DEEP[id - 200].dec.toDouble()) }
            else -> { e[0] = SkyData.raRad[id - 100]; e[1] = SkyData.decRad[id - 100] }
        }
        val o = DoubleArray(2); SkyMath.altAz(e[0], e[1], latR, lstR, o); return Math.toDegrees(o[0])
    }
    private fun fmtJd(jd: Double): String {
        if (jd.isNaN()) return "\u2013"
        val ms = ((jd - 2440587.5) * 86400000.0).toLong(); val p = partsFor(TimeZone.getDefault(), ms)
        return hm(p[0], p[1], is24) + (if (is24) "" else " " + ampmOf(p[0]))
    }
    private fun buildInfo(s: SItem, jd: Double) {
        infoJd = jd; infoTitle = s.name
        val l = ArrayList<String>()
        val thr = if (s.id == 0) -0.833 else 0.0
        val rs = SkyMath.riseSet({ altOf(s.id, it) }, jd, thr)
        val altD = Math.toDegrees(s.alt.toDouble()); val azD = Math.toDegrees(s.az.toDouble())
        when {
            s.id == 0 -> { SkyMath.sunEq(jd, eq); l.add("Our star \u00B7 8 min 20 s away"); l.add("Never look at the Sun directly") }
            s.id == 1 -> { SkyMath.moonEq(jd, eq); l.add(SkyMath.moonPhaseName(eq[2], eq[3] > 0.5) + String.format(" \u00B7 %d%% lit", (eq[2] * 100).toInt())); l.add("About 384,000 km away") }
            s.id in 10..18 -> { SkyMath.planetEq(s.id - 10, jd, eq); l.add(String.format("Magnitude %.1f \u00B7 %.2f AU \u00B7 %d%% lit", eq[3], eq[2], (eq[4] * 100).toInt())); l.add(String.format("Light from it takes %.1f min", eq[2] * 8.317)) }
            s.id >= 200 -> { val d = SkyData.DEEP[s.id - 200]; l.add(if (d.kind == 0) "Nebula or bright region" else if (d.kind == 1) "Galaxy" else "Star cluster"); l.add("Best seen from a dark sky") }
            else -> { val st = SkyData.ALL[s.id - 100]; l.add(String.format("Star \u00B7 magnitude %.2f", st.mag)); l.add(String.format("RA %dh %02dm \u00B7 Dec %+.1f\u00B0", st.ra.toInt(), ((st.ra - st.ra.toInt()) * 60).toInt(), st.dec)) }
        }
        l.add(String.format("Altitude %+d\u00B0 \u00B7 %s %d\u00B0%s", altD.toInt(), SkyMath.dirName(azD), azD.toInt(), if (altD < 0) "  (below horizon)" else ""))
        l.add("Rises " + fmtJd(rs[0]) + "  \u00B7  sets " + fmtJd(rs[1]))
        infoLines = l
    }

    // ------------------------------------------------------------------ draw
    override fun onDraw(c: Canvas) {
        vw = width.toFloat(); vh = height.toFloat()
        val now = SystemClock.uptimeMillis(); lastT = now
        val tt = now / 1000f
        val jd = SkyMath.jd(Tt.now())
        val latR = Math.toRadians(lat); val lstR = Math.toRadians(SkyMath.gmstDeg(jd) + lon)
        decR = Math.toRadians(decl)
        cx = vw / 2f; cy = if (camOn) vh / 2f else (dp(90) + vh - bottomPad) / 2f
        F = (vh / 2f) / tan(Math.toRadians(fov / 2.0)).toFloat()
        if (dragMode || !hasSensor) {
            val cp = cos(pitchT); val f0 = sin(yawT) * cp; val f1 = cos(yawT) * cp; val f2 = sin(pitchT)
            val u0 = -sin(pitchT) * sin(yawT); val u1 = -sin(pitchT) * cos(yawT); val u2 = cos(pitchT)
            val r0 = f1 * u2 - f2 * u1; val r1 = f2 * u0 - f0 * u2; val r2 = f0 * u1 - f1 * u0
            R[0] = r0; R[3] = r1; R[6] = r2; R[1] = u0; R[4] = u1; R[7] = u2; R[2] = -f0; R[5] = -f1; R[8] = -f2
        }
        // sun first (sky brightness)
        SkyMath.sunEq(jd, eq); place(sunI, eq[0], eq[1], latR, lstR); sunAlt = Math.toDegrees(sunI.alt.toDouble())
        val skyK = smooth(-12.0, 2.0, sunAlt)
        val starA = if (camOn) (1f - 0.7f * skyK) else (1f - skyK * 0.95f)
        if (!camOn) {
            val top = mixColor(0xFF03040C.toInt(), 0xFF1D4F9E.toInt(), skyK); val bot = mixColor(0xFF0A1030.toInt(), 0xFF7FB6E8.toInt(), skyK)
            fill.shader = LinearGradient(0f, 0f, 0f, vh, top, bot, Shader.TileMode.CLAMP); c.drawRect(0f, 0f, vw, vh, fill); fill.shader = null
        }
        // Milky Way
        for (m in SkyData.MILKY) {
            SkyMath.altAz(m[0], m[1], latR, lstR, aa)
            if (aa[0] < -0.05 || !enuProj(aa[0], aa[1])) continue
            fill.color = alphaColor(0xFFB8C8FF.toInt(), (0.055f * m[2].toFloat() * starA)); c.drawCircle(pj[0], pj[1], dp(26), fill)
        }
        if (showGrid) drawGrid(c)
        drawHorizon(c)
        // objects
        for (k in stars.indices) { val s = stars[k]; place(s, SkyData.raRad[k], SkyData.decRad[k], latR, lstR) }
        SkyMath.moonEq(jd, eq); moonIllum = eq[2]; moonWax = eq[3] > 0.5; place(moonI, eq[0], eq[1], latR, lstR)
        for ((id, s) in planI) { SkyMath.planetEq(id - 10, jd, eq); place(s, eq[0], eq[1], latR, lstR) }
        for (k in dsoI.indices) place(dsoI[k], SkyData.DEEP[k].ra * PI / 12.0, Math.toRadians(SkyData.DEEP[k].dec.toDouble()), latR, lstR)
        if (showLines) {
            val ln = SkyData.LINES; var n = 0
            for (k in 0 until ln.size / 2) {
                val a = stars[ln[k * 2]]; val b = stars[ln[k * 2 + 1]]
                if (a.vis && b.vis && (a.alt > -0.08f || b.alt > -0.08f)) { lineBuf[n * 4] = a.x; lineBuf[n * 4 + 1] = a.y; lineBuf[n * 4 + 2] = b.x; lineBuf[n * 4 + 3] = b.y; n++ }
            }
            line.color = alphaColor(0xFF8FB4FF.toInt(), 0.32f * starA); line.strokeWidth = dp(1f); c.drawLines(lineBuf, 0, n * 4, line)
        }
        if (showDeep) for (d in dsoI) if (d.vis) {
            val r = dp(if (d.id == 204) 26 else 16)
            glow.shader = RadialGradient(d.x, d.y, r, intArrayOf(alphaColor(0xFFB9A8FF.toInt(), 0.55f * starA), 0), null, Shader.TileMode.CLAMP)
            c.drawCircle(d.x, d.y, r, glow); glow.shader = null
        }
        for (s in stars) if (s.vis) {
            val r = dp(max(0.6f, 3.1f - s.mag * 0.72f)); val a = (if (s.alt > 0f) 1f else 0.25f) * starA
            fill.color = alphaColor(if (s.id % 3 == 0) 0xFFFFE9C4.toInt() else 0xFFE4EEFF.toInt(), a)
            c.drawCircle(s.x, s.y, r, fill)
            if (s.mag < 0.6f) { glow.shader = RadialGradient(s.x, s.y, r * 4.5f, intArrayOf(alphaColor(Color.WHITE, 0.35f * a), 0), null, Shader.TileMode.CLAMP); c.drawCircle(s.x, s.y, r * 4.5f, glow); glow.shader = null }
        }
        for ((id, s) in planI) if (s.vis) {
            val p = id - 10; SkyMath.planetEq(p, jd, eq); val r = dp(min(7.5f, max(3.2f, 5.6f - eq[3].toFloat() * 0.9f)))
            val a = if (s.alt > 0f) 1f else 0.3f
            glow.shader = RadialGradient(s.x, s.y, r * 3.2f, intArrayOf(alphaColor(Solar.COL[p], 0.55f * a), 0), null, Shader.TileMode.CLAMP); c.drawCircle(s.x, s.y, r * 3.2f, glow); glow.shader = null
            fill.color = alphaColor(Solar.COL[p], a); c.drawCircle(s.x, s.y, r, fill)
        }
        if (moonI.vis) drawMoonDisc(c, moonI.x, moonI.y, dp(15))
        if (sunI.vis) {
            val a = if (sunI.alt > 0f) 1f else 0.35f; val r = dp(14)
            glow.shader = RadialGradient(sunI.x, sunI.y, r * 6f, intArrayOf(alphaColor(0xFFFFC857.toInt(), 0.7f * a), alphaColor(0xFFFF8A2A.toInt(), 0.18f * a), 0), floatArrayOf(0f, 0.4f, 1f), Shader.TileMode.CLAMP)
            c.drawCircle(sunI.x, sunI.y, r * 6f, glow); glow.shader = null
            fill.color = alphaColor(0xFFFFF1C2.toInt(), a); c.drawCircle(sunI.x, sunI.y, r, fill)
        }
        if (showLabels) drawLabels(c)
        sel?.let { drawSelection(c, it, tt) }
        drawHud(c, jd)
        sel?.let { if (abs(jd - infoJd) > 0.003) buildInfo(it, jd); drawCard(c) }
        postInvalidateOnAnimation()
    }

    private fun drawGrid(c: Canvas) {
        var n = 0
        fun seg(a0: Double, z0: Double, a1: Double, z1: Double) {
            val ok0 = enuProj(a0, z0); val x0 = pj[0]; val y0 = pj[1]
            val ok1 = enuProj(a1, z1)
            if (ok0 && ok1 && n < 690) { lineBuf[n * 4] = x0; lineBuf[n * 4 + 1] = y0; lineBuf[n * 4 + 2] = pj[0]; lineBuf[n * 4 + 3] = pj[1]; n++ }
        }
        for (alt in intArrayOf(30, 60)) for (k in 0 until 72) seg(Math.toRadians(alt.toDouble()), k * PI / 36, Math.toRadians(alt.toDouble()), (k + 1) * PI / 36)
        for (az in 0 until 12) for (k in 0 until 18) seg(Math.toRadians(k * 5.0), az * PI / 6, Math.toRadians((k + 1) * 5.0), az * PI / 6)
        line.color = 0x22BFD4FF; line.strokeWidth = dp(1f); c.drawLines(lineBuf, 0, n * 4, line)
    }

    private fun drawHorizon(c: Canvas) {
        var px = 0f; var py = 0f; var ok = false; var n = 0
        for (k in 0..72) {
            val good = enuProj(0.0, k * PI / 36)
            if (good && ok && n < 690) { lineBuf[n * 4] = px; lineBuf[n * 4 + 1] = py; lineBuf[n * 4 + 2] = pj[0]; lineBuf[n * 4 + 3] = pj[1]; n++ }
            ok = good; px = pj[0]; py = pj[1]
        }
        line.color = 0x33FFB347; line.strokeWidth = dp(7); c.drawLines(lineBuf, 0, n * 4, line)
        line.color = 0xCCFFB347.toInt(); line.strokeWidth = dp(1.6f); c.drawLines(lineBuf, 0, n * 4, line)
        val letters = arrayOf("N", "E", "S", "W")
        txt.textAlign = Paint.Align.CENTER
        for (q in 0..3) {
            if (enuProj(Math.toRadians(4.0), q * PI / 2)) { txt.textSize = dp(16); txt.color = if (q == 0) 0xFFFF6B6B.toInt() else 0xFFFFD79A.toInt(); c.drawText(letters[q], pj[0], pj[1], txt) }
        }
        txt.textAlign = Paint.Align.LEFT; txt.textSize = dp(11)
    }

    private fun drawMoonDisc(c: Canvas, x: Float, y: Float, r: Float) {
        val a = if (moonI.alt > 0f) 1f else 0.35f
        glow.shader = RadialGradient(x, y, r * 3f, intArrayOf(alphaColor(0xFFE8F0FF.toInt(), 0.25f * a * (0.3f + moonIllum.toFloat())), 0), null, Shader.TileMode.CLAMP)
        c.drawCircle(x, y, r * 3f, glow); glow.shader = null
        c.save(); if (!moonWax) c.scale(-1f, 1f, x, y)
        rect.set(x - r, y - r, x + r, y + r)
        fill.color = alphaColor(0xFFEDE8D8.toInt(), a); c.drawCircle(x, y, r, fill)
        fill.color = alphaColor(0xFF1B2030.toInt(), 0.93f * a)
        path.reset(); path.addArc(rect, 90f, 180f); path.close(); c.drawPath(path, fill)
        val k = (1.0 - 2.0 * moonIllum).toFloat(); val ew = abs(k) * r
        val eo = RectF(x - ew, y - r, x + ew, y + r)
        path.reset()
        if (k > 0f) { path.addArc(eo, 270f, 180f); path.close(); c.drawPath(path, fill) }
        else if (k < 0f) { path.addArc(eo, 90f, 180f); path.close(); fill.color = alphaColor(0xFFEDE8D8.toInt(), a); c.drawPath(path, fill) }
        c.restore()
    }

    private fun drawLabels(c: Canvas) {
        placed.clear()
        val lim = 1.7f + 1.5f * (70f / fov - 1f).coerceIn(-0.5f, 2.2f)
        fun lab(x: Float, y: Float, name: String, col: Int, off: Float, size: Float, alpha: Float) {
            txt.textSize = size; txtS.textSize = size
            val tw = txt.measureText(name); val tx = x + off; val ty = y + size * 0.35f
            val rc = RectF(tx - dp(2), ty - size, tx + tw + dp(2), ty + dp(3))
            if (rc.right < 0 || rc.left > vw || rc.bottom < 0 || rc.top > vh) return
            for (p in placed) if (RectF.intersects(p, rc)) return
            placed.add(rc); txt.color = alphaColor(col, alpha); txtS.alpha = (190 * alpha).toInt()
            c.drawText(name, tx, ty, txtS); c.drawText(name, tx, ty, txt)
        }
        if (moonI.vis) lab(moonI.x, moonI.y, "Moon", Color.WHITE, dp(20), dp(12), 1f)
        if (sunI.vis) lab(sunI.x, sunI.y, "Sun", 0xFFFFE08A.toInt(), dp(20), dp(12), 1f)
        for ((id, s) in planI) if (s.vis) lab(s.x, s.y, s.name, Solar.COL[id - 10], dp(12), dp(12), if (s.alt > 0f) 1f else 0.5f)
        for (s in stars) if (s.vis && s.mag < lim) lab(s.x, s.y, s.name, 0xFFCFE0FF.toInt(), dp(7), dp(10.5f), if (s.alt > 0f) 0.95f else 0.4f)
        if (showDeep) for (d in dsoI) if (d.vis) lab(d.x, d.y, d.name, 0xFFC9B8FF.toInt(), dp(12), dp(10), 0.9f)
        txt.textSize = dp(11)
    }

    private fun drawSelection(c: Canvas, s: SItem, tt: Float) {
        val dxE = ((cos(s.alt.toDouble()) * sin(s.az - decR))).toFloat(); val dyE = ((cos(s.alt.toDouble()) * cos(s.az - decR))).toFloat(); val dzE = sin(s.alt.toDouble()).toFloat()
        val inFront = (R[2] * dxE + R[5] * dyE + R[8] * dzE) < -0.02f
        val onScreen = inFront && s.x > 0 && s.x < vw && s.y > 0 && s.y < vh
        line.color = C.CYAN; line.strokeWidth = dp(1.8f)
        if (onScreen) {
            val rr = dp(20) + dp(3) * sin(tt * 4f)
            c.drawCircle(s.x, s.y, rr, line)
            for (k in 0..3) { val a = k * 1.5708f + tt; c.drawLine(s.x + cos(a) * rr, s.y + sin(a) * rr, s.x + cos(a) * (rr + dp(8)), s.y + sin(a) * (rr + dp(8)), line) }
        } else {
            val dx = R[0] * dxE + R[3] * dyE + R[6] * dzE; val dy = R[1] * dxE + R[4] * dyE + R[7] * dzE
            val ang = atan2(-dy, dx); val rad = min(vw, vh) * 0.40f
            val px = cx + cos(ang) * rad; val py = cy + sin(ang) * rad
            path.reset(); path.moveTo(px + cos(ang) * dp(22), py + sin(ang) * dp(22)); path.lineTo(px + cos(ang + 2.4f) * dp(14), py + sin(ang + 2.4f) * dp(14)); path.lineTo(px + cos(ang - 2.4f) * dp(14), py + sin(ang - 2.4f) * dp(14)); path.close()
            fill.color = alphaColor(C.CYAN, 0.9f); c.drawPath(path, fill)
            txt.textAlign = Paint.Align.CENTER; txt.textSize = dp(12); txt.color = C.CYAN
            c.drawText(s.name, cx + cos(ang) * (rad - dp(24)), cy + sin(ang) * (rad - dp(24)), txt); txt.textAlign = Paint.Align.LEFT; txt.textSize = dp(11)
        }
    }

    private fun drawHud(c: Canvas, jd: Double) {
        backR.set(dp(14), dp(40), dp(104), dp(80)); fill.color = 0x66101830; c.drawRoundRect(backR, dp(20), dp(20), fill)
        txt.textAlign = Paint.Align.CENTER; txt.color = Color.WHITE; txt.textSize = dp(14); c.drawText("\u2039 Back", backR.centerX(), backR.centerY() + dp(5), txt)
        val fxw = -R[2]; val fyw = -R[5]; val fzw = -R[8]
        val head = (Math.toDegrees(atan2(fxw.toDouble(), fyw.toDouble())) + decl + 360.0) % 360.0
        val elev = Math.toDegrees(asin(fzw.toDouble().coerceIn(-1.0, 1.0)))
        txt.textAlign = Paint.Align.LEFT; txt.textSize = dp(12.5f); txt.color = 0xE6FFFFFF.toInt()
        c.drawText(String.format("Facing %s %d\u00B0  \u00B7  elevation %+d\u00B0", SkyMath.dirName(head), head.toInt(), elev.toInt()), dp(18), dp(104), txt)
        txt.textSize = dp(11); txt.color = C.CYAN
        val ms = ((jd - 2440587.5) * 86400000.0).toLong(); val p = partsFor(TimeZone.getDefault(), ms)
        c.drawText(String.format("%02d:%02d  \u00B7  %.1f\u00B0N %.1f\u00B0E (%s)", p[0], p[1], lat, lon, locNote), dp(18), dp(121), txt)
        if (!dragMode && hasSensor && magAcc <= SensorManager.SENSOR_STATUS_ACCURACY_LOW) { txt.color = C.ORANGE; c.drawText("Compass needs calibrating \u2013 wave the phone in a figure 8", dp(18), dp(138), txt) }
        else if (!hasSensor) { txt.color = C.ORANGE; c.drawText("No orientation sensor \u2013 drag to look around", dp(18), dp(138), txt) }
        txt.textSize = dp(11)
    }

    private fun drawCard(c: Canvas) {
        val cw = min(vw - dp(24), dp(350)); val ch = dp(130)
        card.set((vw - cw) / 2f, vh - bottomPad - ch - dp(8), (vw + cw) / 2f, vh - bottomPad - dp(8))
        fill.color = 0xEA0B1022.toInt(); c.drawRoundRect(card, dp(24), dp(24), fill)
        line.color = alphaColor(C.CYAN, 0.55f); line.strokeWidth = dp(1.2f); c.drawRoundRect(card, dp(24), dp(24), line)
        val x = card.left + dp(18)
        txt.textSize = dp(18); txt.color = Color.WHITE; c.drawText(infoTitle, x, card.top + dp(30), txt)
        txt.textSize = dp(12.5f); txt.color = 0xFFC9D2EE.toInt()
        for ((k, s) in infoLines.withIndex()) c.drawText(s, x, card.top + dp(54) + k * dp(19), txt)
        txt.textSize = dp(11)
    }

    // ------------------------------------------------------------------ touch
    override fun onTouchEvent(e: MotionEvent): Boolean {
        scaleDet.onTouchEvent(e)
        if (scaleDet.isInProgress || e.pointerCount > 1) { moved += 200f; downX = e.x; downY = e.y; return true }
        when (e.actionMasked) {
            MotionEvent.ACTION_DOWN -> { downX = e.x; downY = e.y; moved = 0f; downT = SystemClock.uptimeMillis() }
            MotionEvent.ACTION_MOVE -> {
                val dx = e.x - downX; val dy = e.y - downY; moved += abs(dx) + abs(dy)
                if (dragMode || !hasSensor) { yawT -= dx * 0.0035f * (fov / 70f); pitchT = (pitchT + dy * 0.0035f * (fov / 70f)).coerceIn(-1.5f, 1.5f) }
                downX = e.x; downY = e.y
            }
            MotionEvent.ACTION_UP -> if (moved < dp(12) && SystemClock.uptimeMillis() - downT < 350L) {
                if (backR.contains(e.x, e.y)) { onExit?.invoke(); return true }
                var best: SItem? = null; var bd = Float.MAX_VALUE
                for (s in items) { if (!s.vis || (s.id >= 100 && s.mag > 3.2f)) continue
                    val d = hypot(s.x - e.x, s.y - e.y) + s.mag * dp(1.5f)
                    if (d < dp(40) && d < bd) { bd = d; best = s } }
                if (best != null) { sel = best; buildInfo(best, SkyMath.jd(Tt.now())); thud() } else sel = null
            }
        }
        return true
    }
}
