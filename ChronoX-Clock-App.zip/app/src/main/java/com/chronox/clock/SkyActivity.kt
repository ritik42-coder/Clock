package com.chronox.clock

import android.Manifest
import android.app.Activity
import android.content.Context
import android.content.pm.PackageManager
import android.graphics.SurfaceTexture
import android.hardware.Camera
import android.location.LocationManager
import android.os.Bundle
import android.view.Gravity
import android.view.TextureView
import android.view.View
import android.view.WindowManager
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.Toast
import androidx.core.view.WindowCompat

/** Live camera feed drawn behind the sky map. */
class CamLayer(ctx: Context, private val onFov: (Float) -> Unit) : TextureView(ctx), TextureView.SurfaceTextureListener {
    private var cam: Camera? = null
    init { surfaceTextureListener = this }
    override fun onSurfaceTextureAvailable(st: SurfaceTexture, w: Int, h: Int) { open(st) }
    override fun onSurfaceTextureSizeChanged(st: SurfaceTexture, w: Int, h: Int) {}
    override fun onSurfaceTextureDestroyed(st: SurfaceTexture): Boolean { release(); return true }
    override fun onSurfaceTextureUpdated(st: SurfaceTexture) {}
    private fun open(st: SurfaceTexture) {
        try {
            val c = Camera.open(); val p = c.parameters
            var best: Camera.Size? = null
            for (s in p.supportedPreviewSizes) { if (s.width <= 1280 && (best == null || s.width * s.height > best.width * best.height)) best = s }
            if (best != null) p.setPreviewSize(best.width, best.height)
            if (p.supportedFocusModes.contains(Camera.Parameters.FOCUS_MODE_CONTINUOUS_PICTURE)) p.focusMode = Camera.Parameters.FOCUS_MODE_CONTINUOUS_PICTURE
            c.parameters = p; c.setDisplayOrientation(90); c.setPreviewTexture(st); c.startPreview(); cam = c
            val pw = best?.width ?: 1280; val ph = best?.height ?: 720
            post { fillParent(pw, ph) }
            onFov(p.horizontalViewAngle)
        } catch (e: Exception) { }
    }
    private fun fillParent(pw: Int, ph: Int) {
        val par = parent as? View ?: return
        val ar = ph.toFloat() / pw.toFloat()
        var tw = par.width; var th = (par.width / ar).toInt()
        if (th < par.height) { th = par.height; tw = (par.height * ar).toInt() }
        layoutParams = FrameLayout.LayoutParams(tw, th, Gravity.CENTER)
    }
    fun release() { val c = cam ?: return; cam = null; try { c.stopPreview(); c.release() } catch (e: Exception) { } }
}

class SkyActivity : Activity() {
    private lateinit var root: FrameLayout
    private lateinit var sv: SkyView
    private var cam: CamLayer? = null

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        DENSITY = resources.displayMetrics.density
        WindowCompat.setDecorFitsSystemWindows(window, false)
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        root = FrameLayout(this)
        sv = SkyView(this); root.addView(sv, FrameLayout.LayoutParams(-1, -1))
        val panel = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dpi(12), dpi(12), dpi(12), dpi(6)); background = glassBg(dp(28), 0xCC0B1022.toInt()) }
        val labels = listOf("Moon", "Sun", "Venus", "Mars", "Jupiter", "Saturn", "Mercury", "Polaris", "Sirius")
        val chips = ChipRow(this, labels, -1, C.CYAN) { i ->
            when (labels[i]) { "Moon" -> sv.select(1); "Sun" -> sv.select(0); "Venus" -> sv.select(12); "Mars" -> sv.select(14); "Jupiter" -> sv.select(15)
                "Saturn" -> sv.select(16); "Mercury" -> sv.select(11); "Polaris" -> sv.selectStar("Polaris"); else -> sv.selectStar("Sirius") }
            Unit
        }
        panel.addView(chips, LinearLayout.LayoutParams(-1, -2))
        val toggles = ToggleRow(this, listOf("Camera" to false, "Constellations" to true, "Grid" to false, "Labels" to true, "Deep sky" to true, "Drag mode" to false), C.VIOLET) { i, on ->
            when (i) { 0 -> setCamera(on); 1 -> sv.showLines = on; 2 -> sv.showGrid = on; 3 -> sv.showLabels = on; 4 -> sv.showDeep = on; else -> sv.dragMode = on }
            Unit
        }
        panel.addView(toggles, LinearLayout.LayoutParams(-1, -2).apply { topMargin = dpi(8) })
        panel.addView(TimeScrub(this) { }, LinearLayout.LayoutParams(-1, dpi(84)))
        root.addView(panel, FrameLayout.LayoutParams(-1, -2, Gravity.BOTTOM).apply { leftMargin = dpi(10); rightMargin = dpi(10); bottomMargin = dpi(22) })
        sv.onExit = { finish() }
        sv.bottomPad = dp(236)
        setContentView(root)
        findLocation()
        if (checkSelfPermission(Manifest.permission.ACCESS_COARSE_LOCATION) != PackageManager.PERMISSION_GRANTED) requestPermissions(arrayOf(Manifest.permission.ACCESS_COARSE_LOCATION), 31)
    }

    private fun findLocation() {
        var best: android.location.Location? = null
        if (checkSelfPermission(Manifest.permission.ACCESS_COARSE_LOCATION) == PackageManager.PERMISSION_GRANTED) {
            try {
                val lm = getSystemService(Context.LOCATION_SERVICE) as LocationManager
                for (p in lm.getProviders(true)) { val l = lm.getLastKnownLocation(p); if (l != null && (best == null || l.time > best.time)) best = l }
            } catch (e: Exception) { }
        }
        if (best != null) sv.setLocation(best.latitude, best.longitude, "from phone")
        else { val c = Cities.localCity(); sv.setLocation(c.lat, c.lon, "approximate") }
    }
    private fun setCamera(on: Boolean) {
        if (on) {
            if (checkSelfPermission(Manifest.permission.CAMERA) != PackageManager.PERMISSION_GRANTED) {
                requestPermissions(arrayOf(Manifest.permission.CAMERA), 32); Toast.makeText(this, "Allow camera access, then switch Camera on again", Toast.LENGTH_LONG).show(); return
            }
            if (cam != null) return
            val cl = CamLayer(this) { f -> runOnUiThread { sv.fov = f.coerceIn(40f, 95f) } }
            cam = cl; root.addView(cl, 0, FrameLayout.LayoutParams(-1, -1)); sv.camOn = true
        } else { cam?.let { it.release(); root.removeView(it) }; cam = null; sv.camOn = false; sv.fov = 70f }
    }
    override fun onRequestPermissionsResult(code: Int, p: Array<out String>, r: IntArray) { super.onRequestPermissionsResult(code, p, r); if (code == 31) findLocation() }
    override fun onResume() { super.onResume(); sv.start() }
    override fun onPause() { super.onPause(); sv.stop() }
}
