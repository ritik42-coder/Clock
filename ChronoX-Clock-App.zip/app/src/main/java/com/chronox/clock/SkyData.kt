package com.chronox.clock

import kotlin.math.*

class Star(val name: String, val ra: Float, val dec: Float, val mag: Float)
class Dso(val name: String, val ra: Float, val dec: Float, val kind: Int)

object SkyData {
    private const val S1 = "Sirius,6.7525,-16.7161,-1.46;Canopus,6.3992,-52.6957,-0.74;Arcturus,14.2610,19.1824,-0.05;Rigil Kent,14.6600,-60.8340,-0.01;Vega,18.6156,38.7837,0.03;Capella,5.2782,45.9980,0.08;Rigel,5.2423,-8.2016,0.13;Procyon,7.6550,5.2250,0.34;Achernar,1.6286,-57.2367,0.46;Betelgeuse,5.9195,7.4071,0.50;Hadar,14.0637,-60.3730,0.61;Altair,19.8464,8.8683,0.76;Acrux,12.4433,-63.0991,0.76;Aldebaran,4.5987,16.5093,0.85;Antares,16.4901,-26.4320,0.96;Spica,13.4199,-11.1613,0.97;Pollux,7.7553,28.0262,1.14;Fomalhaut,22.9608,-29.6222,1.16;Deneb,20.6905,45.2803,1.25;Mimosa,12.7953,-59.6888,1.25;Regulus,10.1395,11.9672,1.35;Adhara,6.9771,-28.9721,1.50;Castor,7.5767,31.8883,1.58;Shaula,17.5601,-37.1038,1.62;Gacrux,12.5194,-57.1132,1.64;Bellatrix,5.4189,6.3497,1.64;Elnath,5.4382,28.6075,1.65;Miaplacidus,9.2200,-69.7172,1.67;Alnilam,5.6036,-1.2019,1.69;Alnair,22.1372,-46.9610,1.74;Alnitak,5.6793,-1.9426,1.77;Alioth,12.9005,55.9598,1.77;Dubhe,11.0621,61.7510,1.79;Mirfak,3.4054,49.8612,1.80;Wezen,7.1399,-26.3932,1.84;Sargas,17.6220,-42.9978,1.87;Kaus Australis,18.4029,-34.3846,1.85;Avior,8.3752,-59.5095,1.86;Alkaid,13.7923,49.3133,1.86;Menkalinan,5.9921,44.9474,1.90;Atria,16.8112,-69.0277,1.92;Alhena,6.6285,16.3993,1.93;Peacock,20.4275,-56.7351,1.94;Mirzam,6.3783,-17.9559,1.98;Alphard,9.4598,-8.6586,1.98;Polaris,2.5303,89.2641,1.98;Hamal,2.1196,23.4624,2.00;Algieba,10.3329,19.8415,2.01;Diphda,0.7265,-17.9866,2.02;Mizar,13.3988,54.9254,2.04;Nunki,18.9211,-26.2967,2.05;Menkent,14.1114,-36.3700,2.06;Mirach,1.1622,35.6206,2.06;Alpheratz,0.1398,29.0905,2.06;Rasalhague,17.5822,12.5600,2.07;Kochab,14.8451,74.1555,2.08;Saiph,5.7959,-9.6696,2.06;Denebola,11.8177,14.5720,2.14;Algol,3.1361,40.9556,2.12;Muhlifain,12.6919,-48.9599,2.17;Alphecca,15.5781,26.7147,2.23;Mintaka,5.5334,-0.2991,2.23;Sadr,20.3705,40.2567,2.23;Eltanin,17.9434,51.4889,2.23;Schedar,0.6751,56.5373,2.24;Almach,2.0650,42.3297,2.26;Caph,0.1529,59.1498,2.27;Dschubba,16.0056,-22.6217,2.29;Larawag,16.8360,-34.2932,2.29;Merak,11.0307,56.3824,2.37;Enif,21.7364,9.8750,2.39;Scheat,23.0629,28.0828,2.42;Phecda,11.8972,53.6948,2.44;Navi,0.9451,60.7167,2.47;Markab,23.0793,15.2053,2.49;Acrab,16.0906,-19.8054,2.50;Zosma,11.2351,20.5237,2.56;Arneb,5.5455,-17.8223,2.58"
    private const val S2 = "Imai,12.2524,-58.7489,2.80;Megrez,12.2571,57.0326,3.31;Meissa,5.5855,9.9342,3.39;Lesath,17.5127,-37.2958,2.70;Ruchbah,1.4303,60.2353,2.68;Segin,1.9066,63.6701,3.37;Pherkad,15.3455,71.8340,3.00;Yildun,17.5369,86.5864,4.36;Fawaris,19.7496,45.1308,2.87;Albireo,19.5120,27.9597,3.10;Sheliak,18.8347,33.3627,3.50;Sulafat,18.9824,32.6896,3.24;Tarazed,19.7710,10.6133,2.72;Alshain,19.9219,6.4068,3.71;Mebsuta,6.7322,25.1311,3.06;Tejat,6.3827,22.5136,2.88;Wasat,7.3354,21.9823,3.50;Tianguan,5.6273,21.1426,3.00;Ain,4.4770,19.1804,3.50;Alcyone,3.7914,24.1051,2.87;Algenib,0.2206,15.1836,2.83;Nekkar,15.0324,40.3906,3.50;Seginus,14.5348,38.3083,3.00;Muphrid,13.9111,18.3977,2.68;Izar,14.7498,27.0742,2.35;Porrima,12.6944,-1.4494,2.74;Vindemiatrix,13.0364,10.9592,2.83;Mahasim,5.9954,37.2126,2.62;Hassaleh,4.9499,33.1661,2.69;Adhafera,10.2782,23.4173,3.44;Rasalas,9.8794,26.0070,3.88;Chertan,11.2373,15.4297,3.30;Aljanah,20.7702,33.9703,2.46;Sabik,17.1730,-15.7249,2.43;Aludra,7.4016,-29.3031,2.45;Suhail,9.1330,-43.4326,2.21;Naos,8.0597,-40.0031,2.25;Zubeneschamali,15.2835,-9.3829,2.61;Unukalhai,15.7378,6.4256,2.65;Menkar,3.0380,4.0897,2.53;Gienah,12.2634,-17.5419,2.59;Ascella,19.0435,-29.8801,2.60;Sheratan,1.9109,20.8080,2.64;Alsephina,8.7452,-54.7088,1.96"
    private const val L = "Betelgeuse-Alnitak-Alnilam-Mintaka-Bellatrix-Meissa-Betelgeuse|Alnitak-Saiph-Rigel-Mintaka|Dubhe-Merak-Phecda-Megrez-Dubhe|Megrez-Alioth-Mizar-Alkaid|Polaris-Yildun-Kochab-Pherkad|Caph-Schedar-Navi-Ruchbah-Segin|Gacrux-Acrux|Mimosa-Imai|Acrab-Dschubba-Antares-Larawag-Sargas-Shaula-Lesath|Regulus-Algieba-Zosma-Denebola-Chertan-Regulus|Algieba-Adhafera-Rasalas|Deneb-Sadr-Albireo|Fawaris-Sadr-Aljanah|Vega-Sheliak-Sulafat-Vega|Tarazed-Altair-Alshain|Castor-Mebsuta-Tejat|Pollux-Wasat-Alhena|Castor-Pollux|Aldebaran-Ain|Aldebaran-Elnath|Aldebaran-Tianguan|Sirius-Mirzam|Sirius-Wezen-Aludra|Wezen-Adhara|Alpheratz-Scheat-Markab-Algenib-Alpheratz|Alpheratz-Mirach-Almach|Arcturus-Muphrid|Arcturus-Izar-Nekkar-Seginus-Arcturus|Spica-Porrima-Vindemiatrix|Capella-Menkalinan-Mahasim-Elnath|Capella-Hassaleh|Rigil Kent-Hadar|Hadar-Muhlifain|Menkent-Muhlifain"

    val ALL: List<Star> by lazy {
        val out = ArrayList<Star>()
        for (blk in listOf(S1, S2)) for (e in blk.split(";")) { val a = e.split(","); out.add(Star(a[0], a[1].toFloat(), a[2].toFloat(), a[3].toFloat())) }
        out
    }
    val raRad: DoubleArray by lazy { DoubleArray(ALL.size) { ALL[it].ra * PI / 12.0 } }
    val decRad: DoubleArray by lazy { DoubleArray(ALL.size) { Math.toRadians(ALL[it].dec.toDouble()) } }
    val LINES: IntArray by lazy {
        val idx = HashMap<String, Int>(); for ((i, s) in ALL.withIndex()) idx[s.name] = i
        val out = ArrayList<Int>()
        for (chain in L.split("|")) { val n = chain.split("-"); for (k in 0 until n.size - 1) { val a = idx[n[k]]; val b = idx[n[k + 1]]; if (a != null && b != null) { out.add(a); out.add(b) } } }
        out.toIntArray()
    }
    val DEEP = listOf(Dso("Orion Nebula", 5.588f, -5.39f, 0), Dso("Andromeda Galaxy", 0.7123f, 41.27f, 1), Dso("Pleiades", 3.79f, 24.12f, 2), Dso("Beehive Cluster", 8.667f, 19.67f, 2),
        Dso("Galactic Centre", 17.761f, -29.0f, 0), Dso("Large Magellanic Cloud", 5.392f, -69.76f, 1), Dso("Small Magellanic Cloud", 0.877f, -72.8f, 1))
    /** Milky Way sample points (ra, dec radians, weight) along the galactic plane */
    val MILKY: Array<DoubleArray> by lazy {
        val r = java.util.Random(9); val out = ArrayList<DoubleArray>()
        val aG = Math.toRadians(192.85948); val dG = Math.toRadians(27.12825); val lN = Math.toRadians(122.93192)
        for (k in 0 until 420) {
            val l = Math.toRadians(r.nextDouble() * 360.0); val b = Math.toRadians((r.nextGaussian() * 6.0).coerceIn(-20.0, 20.0))
            val sd = sin(dG) * sin(b) + cos(dG) * cos(b) * cos(lN - l)
            val dec = asin(sd.coerceIn(-1.0, 1.0))
            val ra = aG + atan2(cos(b) * sin(lN - l), cos(dG) * sin(b) - sin(dG) * cos(b) * cos(lN - l))
            val w = (0.45 + 0.55 * cos(l)) * exp(-(b * b) / (2 * 0.1 * 0.1))
            out.add(doubleArrayOf(ra, dec, w))
        }
        out.toTypedArray()
    }
}

object SkyMath {
    const val EPS = 23.4393
    fun jd(ms: Long): Double = ms / 86400000.0 + 2440587.5
    fun gmstDeg(jd: Double): Double { var g = (280.46061837 + 360.98564736629 * (jd - 2451545.0)) % 360.0; if (g < 0) g += 360.0; return g }
    /** out[0] altitude, out[1] azimuth (from north through east), radians */
    fun altAz(ra: Double, dec: Double, latR: Double, lstR: Double, out: DoubleArray) {
        val h = lstR - ra
        val sa = sin(dec) * sin(latR) + cos(dec) * cos(latR) * cos(h)
        out[0] = asin(sa.coerceIn(-1.0, 1.0))
        val az = atan2(sin(h), cos(h) * sin(latR) - tan(dec) * cos(latR)) + PI
        out[1] = (az % (2 * PI) + 2 * PI) % (2 * PI)
    }
    private fun eclToEq(x: Double, y: Double, z: Double, o: DoubleArray) {
        val e = Math.toRadians(EPS); val ye = y * cos(e) - z * sin(e); val ze = y * sin(e) + z * cos(e)
        o[0] = atan2(ye, x); o[1] = asin((ze / sqrt(x * x + ye * ye + ze * ze)).coerceIn(-1.0, 1.0))
    }
    private val tmpE = DoubleArray(3); private val tmpP = DoubleArray(3)
    /** out: ra, dec, distance AU, (unused) */
    fun sunEq(jd: Double, out: DoubleArray) {
        Solar.helio(3, jd - 2451545.0, tmpE); eclToEq(-tmpE[0], -tmpE[1], -tmpE[2], out)
        out[2] = sqrt(tmpE[0] * tmpE[0] + tmpE[1] * tmpE[1] + tmpE[2] * tmpE[2])
    }
    /** out: ra, dec, illuminated fraction, waxing (1/0) */
    fun moonEq(jd: Double, out: DoubleArray) {
        val t = (jd - 2451545.0) / 36525.0
        fun s(a: Double, b: Double) = sin(Math.toRadians(a + b * t))
        val lon = 218.32 + 481267.881 * t + 6.29 * s(135.0, 477198.87) - 1.27 * s(259.3, -413335.36) + 0.66 * s(235.7, 890534.22) + 0.21 * s(269.9, 954397.74) - 0.19 * s(357.5, 35999.05) - 0.11 * s(186.5, 966404.03)
        val lat = 5.13 * s(93.3, 483202.02) + 0.28 * s(228.2, 960400.89) - 0.28 * s(318.3, 6003.15) - 0.17 * s(217.6, -407332.21)
        val lr = Math.toRadians(lon); val br = Math.toRadians(lat)
        eclToEq(cos(br) * cos(lr), cos(br) * sin(lr), sin(br), out)
        Solar.helio(3, jd - 2451545.0, tmpE)
        val sunLon = Math.toDegrees(atan2(-tmpE[1], -tmpE[0]))
        val el = (((lon - sunLon) % 360.0) + 360.0) % 360.0
        out[2] = (1.0 - cos(Math.toRadians(el))) / 2.0; out[3] = if (el < 180.0) 1.0 else 0.0
    }
    private val V0 = doubleArrayOf(0.0, -0.36, -4.34, 0.0, -1.51, -9.25, -8.88, -7.19, -6.87)
    /** out: ra, dec, distance AU, magnitude, illuminated fraction */
    fun planetEq(p: Int, jd: Double, out: DoubleArray) {
        val d = jd - 2451545.0
        Solar.helio(p, d, tmpP); Solar.helio(3, d, tmpE)
        val gx = tmpP[0] - tmpE[0]; val gy = tmpP[1] - tmpE[1]; val gz = tmpP[2] - tmpE[2]
        val dl = sqrt(gx * gx + gy * gy + gz * gz); val r = sqrt(tmpP[0] * tmpP[0] + tmpP[1] * tmpP[1] + tmpP[2] * tmpP[2]); val rs = sqrt(tmpE[0] * tmpE[0] + tmpE[1] * tmpE[1] + tmpE[2] * tmpE[2])
        eclToEq(gx, gy, gz, out)
        out[2] = dl
        val ci = ((r * r + dl * dl - rs * rs) / (2 * r * dl)).coerceIn(-1.0, 1.0); val i = Math.toDegrees(acos(ci))
        var m = V0[p] + 5 * log10(r * dl)
        m += when (p) { 1 -> 0.0380 * i - 0.000273 * i * i + 0.000002 * i * i * i; 2 -> 0.013 * i + 4.2e-7 * i * i * i; 4 -> 0.016 * i; 5 -> 0.014 * i; else -> 0.0 }
        out[3] = m; out[4] = (1 + ci) / 2
    }
    fun dirName(azDeg: Double): String {
        val n = arrayOf("N", "NNE", "NE", "ENE", "E", "ESE", "SE", "SSE", "S", "SSW", "SW", "WSW", "W", "WNW", "NW", "NNW")
        return n[(((azDeg + 11.25) / 22.5).toInt()) % 16]
    }
    fun moonPhaseName(illum: Double, waxing: Boolean): String = when {
        illum < 0.03 -> "New Moon"; illum > 0.97 -> "Full Moon"
        illum < 0.4 -> if (waxing) "Waxing crescent" else "Waning crescent"
        illum < 0.6 -> if (waxing) "First quarter" else "Last quarter"
        else -> if (waxing) "Waxing gibbous" else "Waning gibbous"
    }
    /** next rise and set (Julian dates, NaN if none within 24 h) for an altitude function in degrees */
    fun riseSet(altFn: (Double) -> Double, jd0: Double, thr: Double): DoubleArray {
        var rise = Double.NaN; var set = Double.NaN
        var prev = altFn(jd0) - thr
        for (k in 1..144) {
            val j = jd0 + k / 144.0; val a = altFn(j) - thr
            if (prev < 0 && a >= 0 && rise.isNaN()) rise = j - (1.0 / 144.0) * (a / (a - prev))
            if (prev >= 0 && a < 0 && set.isNaN()) set = j - (1.0 / 144.0) * (a / (a - prev))
            prev = a
        }
        return doubleArrayOf(rise, set)
    }
}
