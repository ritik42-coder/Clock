package com.chronox.clock

import android.content.Context
import android.graphics.*
import android.text.Editable
import android.text.InputType
import android.text.TextWatcher
import android.text.format.DateFormat
import android.view.*
import android.view.animation.DecelerateInterpolator
import android.widget.*
import java.util.TimeZone
import kotlin.math.*

class CityRowView(ctx: Context, private val name: String, private val sub: String, private val tz: TimeZone, private val accent: Int, private val is24: Boolean) : View(ctx) {
    private val bg = fillPaint(); private val st = strokePaint(0x26FFFFFF, dp(1)); private val rect = RectF()
    private val nameP = textPaint(C.TEXT, dp(18), MED); private val subP = textPaint(C.DIM, dp(13), REG)
    private val timeP = textPaint(C.TEXT, dp(34), LIGHT, Paint.Align.RIGHT); private val secP = textPaint(C.DIM, dp(15), REG)
    private val sun = fillPaint(); private val sunS = strokePaint(C.ORANGE, dp(1.8f))
    override fun onDraw(c: Canvas) {
        val now = Tt.now()
        rect.set(dp(6), dp(6), width - dp(6), height - dp(6))
        bg.shader = LinearGradient(rect.left, rect.top, rect.right, rect.bottom, intArrayOf(0x24FFFFFF, alphaColor(accent, 0.10f)), null, Shader.TileMode.CLAMP)
        c.drawRoundRect(rect, dp(26), dp(26), bg); bg.shader = null; c.drawRoundRect(rect, dp(26), dp(26), st)
        val cy = height / 2f
        drawAnalog(c, dp(52), cy, dp(28), tz, accent, false, now)
        val tx = dp(96)
        c.drawText(name, tx, cy - dp(3), nameP)
        val p = partsFor(tz, now)
        val d = dayIndex(tz, now) - dayIndex(TimeZone.getDefault(), now)
        val diff = (tz.getOffset(now) - TimeZone.getDefault().getOffset(now)) / 3600000.0
        val dh = if (diff == 0.0) "Same time" else (if (diff > 0) "+" else "-") + (if (abs(diff) % 1.0 == 0.0) "${abs(diff).toInt()}" else "%.1f".format(abs(diff))) + "h"
        c.drawText((if (sub.isNotEmpty()) "$sub \u00B7 " else "") + (if (d == 0L) "Today" else if (d > 0) "Tomorrow" else "Yesterday") + ", " + dh, tx, cy + dp(20), subP)
        val hh = p[0]; val ts = hm(hh, p[1], is24)
        val right = width - dp(24)
        if (!is24) { secP.textAlign = Paint.Align.RIGHT; c.drawText(ampmOf(hh), right, cy - dp(6), secP) }
        timeP.textSize = dp(32); c.drawText(ts, right - (if (is24) 0f else dp(30)), cy + dp(12), timeP)
        secP.textAlign = Paint.Align.RIGHT; secP.color = alphaColor(accent, 0.9f); c.drawText(":" + two(p[2]), right, cy + dp(32), secP); secP.color = C.DIM
        // day / night glyph
        val gx = right - dp(2); val gy = dp(24)
        if (hh in 6..17) { sun.color = C.ORANGE; c.drawCircle(gx - dp(4), gy, dp(5), sun) } else { sun.color = 0xFFB9B4FF.toInt(); c.drawCircle(gx - dp(4), gy, dp(5), sun); sun.color = 0xFF14182E.toInt(); c.drawCircle(gx - dp(1), gy - dp(2), dp(4.2f), sun) }
        postInvalidateOnAnimation()
    }
}

class WorldPage(ctx: Context) : Page(ctx) {
    private val is24 = DateFormat.is24HourFormat(ctx)
    private val scroll = FxScrollView(ctx, 0.9f)
    private val list = LinearLayout(ctx).apply { orientation = LinearLayout.VERTICAL }
    private val earth = EarthView(ctx)
    private val info = tv(ctx, "", 14f, C.CYAN, MED)
    private var picker: FrameLayout? = null
    private val scrub = TimeScrub(ctx) { }
    private val tickRun = object : Runnable {
        override fun run() { val u = Tt.now(); val p = partsFor(TimeZone.getTimeZone("UTC"), u); info.text = "UTC ${two(p[0])}:${two(p[1])}:${two(p[2])}  \u00B7  " + (if (Math.abs(Tt.offset) < 30000L) "live day & night" else "time travel"); postDelayed(this, 250) }
    }
    init {
        scroll.addView(list, FrameLayout.LayoutParams(-1, -2)); addView(scroll, LayoutParams(-1, -1))
        reload()
    }
    override fun applyInsets() { scroll.setPadding(dpi(18), topInset + dpi(18), dpi(18), bottomInset + dpi(24)); scroll.applyFx() }
    override fun onShow() { earth.startLoop(); post(tickRun) }
    override fun onHide() { earth.stopLoop(); removeCallbacks(tickRun); scrub.playing = false }
    override fun onAttachedToWindow() { super.onAttachedToWindow(); post(tickRun) }
    override fun onDetachedFromWindow() { removeCallbacks(tickRun); super.onDetachedFromWindow() }
    override fun playEntrance() {
        for (i in 0 until list.childCount) { val v = list.getChildAt(i); v.alpha = 0f; v.translationY = dp(60); v.animate().alpha(1f).translationY(0f).setStartDelay(70L * min(i, 8)).setDuration(520).setInterpolator(DecelerateInterpolator(2f)).start() }
    }

    private fun reload() {
        list.removeAllViews()
        val ctx = context
        val saved = Cities.saved(ctx); val local = Cities.localCity()
        earth.markers = saved; earth.local = local
        list.addView(tv(ctx, "World", 34f, C.TEXT, THIN), LinearLayout.LayoutParams(-2, -2).apply { bottomMargin = dpi(6) })
        val sw = ctx.resources.displayMetrics.widthPixels - dpi(36)
        (earth.parent as? ViewGroup)?.removeView(earth)
        list.addView(earth, LinearLayout.LayoutParams(-1, (sw * 0.98f).toInt()))
        val row = LinearLayout(ctx).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
        row.addView(info, LinearLayout.LayoutParams(0, -2, 1f))
        row.addView(ghostButton(ctx, "My location", C.CYAN) { earth.locate(local) }.apply { textSize = 13f }, LinearLayout.LayoutParams(dpi(120), dpi(40)))
        list.addView(row, LinearLayout.LayoutParams(-1, -2).apply { topMargin = dpi(4); bottomMargin = dpi(2) })
        val tg = ToggleRow(ctx, listOf("Labels" to earth.showLabels, "Clouds" to earth.showClouds, "Night lights" to earth.showLights, "Borders" to earth.showBorders, "Tour" to earth.isTour()), C.CYAN) { i, on ->
            when (i) { 0 -> earth.showLabels = on; 1 -> earth.showClouds = on; 2 -> earth.showLights = on; 3 -> earth.showBorders = on; else -> earth.setTour(on) }
            Unit
        }
        list.addView(tg, LinearLayout.LayoutParams(-1, -2).apply { topMargin = dpi(4); bottomMargin = dpi(2) })
        (scrub.parent as? ViewGroup)?.removeView(scrub)
        list.addView(scrub, LinearLayout.LayoutParams(-1, dpi(84)).apply { bottomMargin = dpi(12) })
        list.addView(bigButton(ctx, "Explore the Solar System", C.VIOLET, C.CYAN) { ctx.startActivity(android.content.Intent(ctx, SolarActivity::class.java)) }, LinearLayout.LayoutParams(-1, dpi(56)).apply { bottomMargin = dpi(10) })
        list.addView(bigButton(ctx, "SkyScope \u2013 what's above me now", C.CYAN, C.VIOLET) { ctx.startActivity(android.content.Intent(ctx, SkyActivity::class.java)) }, LinearLayout.LayoutParams(-1, dpi(56)).apply { bottomMargin = dpi(14) })
        list.addView(CityRowView(ctx, if (local.name == "Local") "Your location" else local.name, if (local.name == "Local") local.tz else local.country, TimeZone.getDefault(), C.CYAN, is24), LinearLayout.LayoutParams(-1, dpi(104)))
        for (city in saved) {
            lateinit var rowRef: SwipeRow
            val v = CityRowView(ctx, city.name, city.country, TimeZone.getTimeZone(city.tz), C.ORANGE, is24)
            val r = SwipeRow(ctx, v, dpi(104)) {
                val l = Cities.saved(ctx); l.removeAll { it.name == city.name }; Cities.save(ctx, l); list.removeView(rowRef); earth.markers = l
            }
            rowRef = r; list.addView(r)
        }
        list.addView(ghostButton(ctx, "+  Add city", C.TEXT) { openPicker() }, LinearLayout.LayoutParams(-1, dpi(56)).apply { topMargin = dpi(14) })
        scroll.post { scroll.applyFx() }
    }

    private fun openPicker() {
        if (picker != null) return
        val ctx = context
        val ov = FrameLayout(ctx); picker = ov
        val dim = View(ctx).apply { setBackgroundColor(0xC0000000.toInt()); alpha = 0f; setOnClickListener { closePicker() } }
        ov.addView(dim, FrameLayout.LayoutParams(-1, -1))
        val sheet = LinearLayout(ctx).apply { orientation = LinearLayout.VERTICAL; setPadding(dpi(20), dpi(20), dpi(20), 0) }
        sheet.background = android.graphics.drawable.GradientDrawable().apply { setColor(0xFF0C1022.toInt()); cornerRadii = floatArrayOf(dp(32), dp(32), dp(32), dp(32), 0f, 0f, 0f, 0f) }
        ov.addView(sheet, FrameLayout.LayoutParams(-1, -1).apply { topMargin = topInset + dpi(80) })
        sheet.addView(tv(ctx, "Add city", 26f, C.TEXT, THIN))
        val et = EditText(ctx).apply {
            hint = "Search"; setHintTextColor(0xFF5B6180.toInt()); setTextColor(C.TEXT); textSize = 16f; setSingleLine(); inputType = InputType.TYPE_CLASS_TEXT
            background = glassBg(dp(18)); setPadding(dpi(18), dpi(12), dpi(18), dpi(12))
        }
        sheet.addView(et, LinearLayout.LayoutParams(-1, -2).apply { topMargin = dpi(12); bottomMargin = dpi(8) })
        val sv = FxScrollView(ctx, 0.6f); val col = LinearLayout(ctx).apply { orientation = LinearLayout.VERTICAL }
        sv.addView(col, FrameLayout.LayoutParams(-1, -2)); sv.setPadding(0, 0, 0, bottomInset + dpi(20))
        sheet.addView(sv, LinearLayout.LayoutParams(-1, 0, 1f))
        fun fill(q: String) {
            col.removeAllViews()
            val have = Cities.saved(ctx).map { it.name }.toSet()
            for (cty in Cities.ALL.filter { it.name !in have && (q.isBlank() || it.name.contains(q, true) || it.country.contains(q, true)) }) {
                val r = LinearLayout(ctx).apply { orientation = LinearLayout.VERTICAL; setPadding(dpi(18), dpi(12), dpi(18), dpi(12)); background = glassBg(dp(18)); pressable() }
                r.addView(tv(ctx, cty.name, 17f, C.TEXT, MED)); r.addView(tv(ctx, cty.country + " \u00B7 " + cty.tz, 12f, C.DIM, REG))
                r.setOnClickListener { thud(); val l = Cities.saved(ctx); l.add(cty); Cities.save(ctx, l); closePicker(); reload() }
                col.addView(r, LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = dpi(8) })
            }
            sv.post { sv.applyFx() }
        }
        et.addTextChangedListener(object : TextWatcher {
            override fun afterTextChanged(s: Editable?) { fill(s?.toString() ?: "") }
            override fun beforeTextChanged(s: CharSequence?, a: Int, b: Int, c: Int) {}
            override fun onTextChanged(s: CharSequence?, a: Int, b: Int, c: Int) {}
        })
        fill("")
        addView(ov, LayoutParams(-1, -1))
        sheet.post { sheet.translationY = sheet.height.toFloat(); animF(0f, 1f, 480L, DecelerateInterpolator(2f)) { sheet.translationY = (1 - it) * sheet.height; dim.alpha = it } }
    }
    private fun closePicker() {
        val ov = picker ?: return; picker = null
        val sheet = ov.getChildAt(1); val dim = ov.getChildAt(0)
        animF(0f, 1f, 300L, DecelerateInterpolator(), 0L, { removeView(ov) }) { sheet.translationY = it * sheet.height; dim.alpha = 1 - it }
    }
    fun handleBack(): Boolean { if (picker != null) { closePicker(); return true }; return false }
}
