package com.chronox.clock

import android.content.Context
import android.graphics.*
import android.os.SystemClock
import android.view.MotionEvent
import android.view.View
import kotlin.math.*

object Land {
    const val MW = 720
    const val MH = 360
    private val POLYS = listOf(
        // North America
        "-168,66 -162,70 -156,71 -140,70 -128,70 -115,68 -95,72 -82,69 -80,63 -93,60 -94,57 -85,55 -80,52 -78,58 -77,62 -70,60 -62,58 -56,52 -60,47 -66,44 -70,42 -74,40 -76,35 -81,31 -80,26 -82,27 -84,30 -90,29 -97,27 -97,22 -94,18 -90,21 -87,21 -88,16 -83,15 -83,10 -77,8 -80,7 -86,11 -92,15 -97,16 -105,20 -109,25 -113,31 -117,32 -121,35 -124,40 -124,47 -128,51 -134,57 -141,60 -148,60 -154,58 -162,55 -158,58 -165,61",
        // Greenland
        "-73,78 -60,82 -30,83 -20,80 -20,72 -30,68 -43,60 -50,64 -55,70 -68,76",
        // South America
        "-77,8 -72,12 -62,11 -52,5 -50,0 -44,-2 -35,-6 -39,-14 -41,-22 -48,-26 -53,-34 -58,-38 -65,-41 -68,-50 -69,-54 -74,-52 -74,-42 -71,-30 -70,-18 -76,-14 -81,-5 -80,0 -78,3",
        // Eurasia
        "-9,37 -9,43 -2,43.5 -4,48 2,51 8,54 14,54 22,55 24,58 30,60 34,66 40,67 44,68 60,69 70,73 80,73 100,77 113,74 130,72 142,72 160,70 170,70 180,68 180,65 178,62 165,60 163,60 157,52 155,57 143,59 137,54 141,52 140,48 135,43 130,42 129,35 126,35 126,38 125,40 122,40 121,38 118,38 119,35 122,31 122,28 119,25 114,22 108,21 106,18 109,13 105,9 100,13 100,8 103,1 100,4 98,10 98,16 94,17 92,21 90,22 87,21 80,15 80,10 77,8 73,16 72,21 67,24 62,25 57,26 56,26 58,23 55,17 44,12 43,15 39,21 35,28 34,31 35,34 36,36 30,36 27,37 26,40 24,38 22,36.5 21,38 19.5,41 16,43 13.5,45.5 12.5,44 14,42 16,41 18,40.3 16,38 15.5,40 12,42 10.5,43.5 8.5,44.5 6,43 3,43 0,39 -1,37 -5,36",
        // Scandinavia
        "5,59 5,62 14,68 24,71 31,70 28,66 24,65 21,61 18,60 16,56 12,56 11,59 8,58",
        // UK, Ireland, Iceland
        "-5,50 1,51 2,53 -2,56 -2,58 -5,58.5 -6,56 -3,54.5 -5,52",
        "-10,52 -6,52 -6,55 -9,54.5",
        "-24,65 -14,64 -14,66 -22,66.5",
        // Japan
        "130,31 132,34 135,34.5 140,35 141,38 142,41 140,41 139.5,38 136,37 132,35.5 130,33",
        "140,42 145,43 142,45.5",
        // Africa
        "-17,21 -13,28 -9,32 -6,36 10,37 11,33 20,31 25,32 32.5,31 34,28 35,24 38,18 43,12 51,12 48,5 41,-2 40,-10 40,-15 35,-20 35,-25 32,-29 27,-34 20,-35 18,-32 14,-23 12,-15 13,-6 9,-1 9,4 5,6 -4,5 -8,4 -13,8 -17,14",
        // Madagascar
        "44,-25 47,-25 50,-15 49,-12 44,-17",
        // Australia
        "114,-22 122,-18 130,-12 137,-12 136,-15 141,-17 142,-11 146,-19 153,-26 151,-34 147,-38 141,-38 135,-35 131,-31 124,-33 115,-34 114,-26",
        // Indonesia / New Guinea / NZ / Cuba
        "95,5 98,4 106,-3 105,-6 101,-3",
        "109,1 114,4 119,5 117,-1 116,-4 111,-3",
        "105,-6 114,-7 114,-8.5 106,-7.5",
        "131,-1 141,-3 150,-10 142,-9 138,-8 132,-4",
        "172,-34 178,-38 175,-41 172,-41",
        "172,-41 174,-42 170,-46 167,-46",
        "-85,22 -80,23 -74,20 -78,20",
        // Antarctica
        "-180,-90 -180,-71 -150,-76 -100,-73 -65,-68 -60,-64 -55,-72 -30,-72 0,-70 40,-67 80,-67 110,-66 150,-69 170,-72 180,-72 180,-90"
    )
    private val WATER = listOf(
        "28,41.5 28,45 34,46 37,47 41,42 36,41.5 31,41",
        "47,45 50,46 53,45 53,40 54,37 50,37 49,40 47,43"
    )
    val mask: IntArray by lazy {
        val bmp = Bitmap.createBitmap(MW, MH, Bitmap.Config.ARGB_8888)
        val cv = Canvas(bmp)
        val p = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.WHITE; style = Paint.Style.FILL }
        fun path(s: String): Path {
            val path = Path(); var first = true
            for (pt in s.split(" ")) {
                val a = pt.split(","); val x = ((a[0].toFloat() + 180f) * 2f); val y = ((90f - a[1].toFloat()) * 2f)
                if (first) { path.moveTo(x, y); first = false } else path.lineTo(x, y)
            }
            path.close(); return path
        }
        for (s in POLYS) cv.drawPath(path(s), p)
        p.xfermode = PorterDuffXfermode(PorterDuff.Mode.CLEAR)
        for (s in WATER) cv.drawPath(path(s), p)
        val px = IntArray(MW * MH); bmp.getPixels(px, 0, MW, 0, 0, MW, MH)
        for (i in px.indices) px[i] = px[i] ushr 24
        bmp.recycle(); px
    }
}

object Sun {
    /** returns (subsolar longitude, declination) in degrees */
    fun position(ms: Long): DoubleArray {
        val cal = java.util.Calendar.getInstance(java.util.TimeZone.getTimeZone("UTC")).also { it.timeInMillis = ms }
        val h = cal.get(java.util.Calendar.HOUR_OF_DAY) + cal.get(java.util.Calendar.MINUTE) / 60.0 +
            cal.get(java.util.Calendar.SECOND) / 3600.0 + cal.get(java.util.Calendar.MILLISECOND) / 3.6e6
        val doy = cal.get(java.util.Calendar.DAY_OF_YEAR)
        val b = 2 * PI * (doy - 81) / 364.0
        val eot = 9.87 * sin(2 * b) - 7.53 * cos(b) - 1.5 * sin(b)
        val lon = (12.0 - h) * 15.0 - eot / 4.0
        val dec = -23.44 * cos(2 * PI / 365.0 * (doy + 10))
        return doubleArrayOf(((lon + 540.0) % 360.0) - 180.0, dec)
    }
}

class EarthView(ctx: Context) : View(ctx) {
    private val RES = 220
    private val R = 0.86
    private val n = RES * RES
    private val vx = FloatArray(n); private val vy = FloatArray(n); private val vz = FloatArray(n); private val rr = FloatArray(n)
    private val pixels = IntArray(n)
    private var front = Bitmap.createBitmap(RES, RES, Bitmap.Config.ARGB_8888)
    private var back = Bitmap.createBitmap(RES, RES, Bitmap.Config.ARGB_8888)
    private val lock = Any()

    @Volatile var lon0 = 77.0
    @Volatile var lat0 = 18.0
    @Volatile private var lastTouch = 0L
    @Volatile private var target = Double.NaN
    @Volatile private var running = false
    @Volatile var sunLon = 0.0
    @Volatile var sunLat = 0.0
    private var thread: Thread? = null
    var markers: List<City> = emptyList()
    var local: City? = null
    private val bmpPaint = Paint(Paint.FILTER_BITMAP_FLAG or Paint.ANTI_ALIAS_FLAG)
    private val dot = fillPaint(); private val ring = strokePaint(Color.WHITE, dp(1.6f))
    private var lx = 0f; private var ly = 0f

    init {
        for (py in 0 until RES) for (px in 0 until RES) {
            val i = py * RES + px
            val x = ((px + 0.5) * 2 / RES - 1) / R; val y = (1 - (py + 0.5) * 2 / RES) / R
            val d2 = x * x + y * y
            vx[i] = x.toFloat(); vy[i] = y.toFloat(); rr[i] = sqrt(d2).toFloat()
            vz[i] = if (d2 <= 1.0) sqrt(1.0 - d2).toFloat() else -1f
        }
    }

    fun locate(c: City) { target = c.lon; lastTouch = SystemClock.uptimeMillis() }

    fun startLoop() {
        if (running) return
        running = true
        thread = Thread {
            Land.mask
            var last = SystemClock.uptimeMillis()
            while (running) {
                val now = SystemClock.uptimeMillis(); val dt = (now - last) / 1000.0; last = now
                val tg = target
                if (!tg.isNaN()) {
                    val d = ((tg - lon0 + 540.0) % 360.0) - 180.0
                    lon0 += d * min(1.0, dt * 4.0)
                    if (abs(d) < 0.3) target = Double.NaN
                } else if (now - lastTouch > 2500L) lon0 -= 6.0 * dt
                if (lon0 < -540.0) lon0 += 360.0
                val s = Sun.position(System.currentTimeMillis()); sunLon = s[0]; sunLat = s[1]
                render(lon0, lat0, sunLon, sunLat, System.currentTimeMillis() / 1000.0 * 0.004)
                back.setPixels(pixels, 0, RES, 0, 0, RES, RES)
                synchronized(lock) { val t = front; front = back; back = t }
                postInvalidateOnAnimation()
                val spent = SystemClock.uptimeMillis() - now
                if (spent < 28) try { Thread.sleep(28 - spent) } catch (e: InterruptedException) { }
            }
        }.also { it.priority = Thread.NORM_PRIORITY - 1; it.start() }
    }
    fun stopLoop() { running = false; thread?.interrupt(); thread = null }

    override fun onAttachedToWindow() { super.onAttachedToWindow() }
    override fun onDetachedFromWindow() { stopLoop(); super.onDetachedFromWindow() }

    private fun sm(e0: Double, e1: Double, x: Double): Double { val t = ((x - e0) / (e1 - e0)).coerceIn(0.0, 1.0); return t * t * (3 - 2 * t) }
    private fun hash(a: Int, b: Int): Double {
        var h = a * 374761393 + b * 668265263
        h = (h xor (h ushr 13)) * 1274126177; h = h xor (h ushr 16)
        return (h and 0xFFFF) / 65535.0
    }

    private fun render(lon0: Double, lat0: Double, sunLon: Double, sunLat: Double, cloudT: Double) {
        val mask = Land.mask
        val d2r = PI / 180
        val pl = lat0 * d2r; val pL = lon0 * d2r
        val cl = cos(pl); val sl = sin(pl); val cL = cos(pL); val sL = sin(pL)
        val cx = cl * cL; val cy = cl * sL; val cz = sl
        val ex = -sL; val ey = cL
        val nx = -sl * cL; val ny = -sl * sL; val nz = cl
        val sp = sunLat * d2r; val sq = sunLon * d2r
        val sx = cos(sp) * cos(sq); val sy = cos(sp) * sin(sq); val sz = sin(sp)
        val svx = sx * ex + sy * ey; val svy = sx * nx + sy * ny + sz * nz; val svz = sx * cx + sy * cy + sz * cz
        val hx = svx; val hy = svy; val hz = svz + 1.0
        val hn = max(1e-6, sqrt(hx * hx + hy * hy + hz * hz))
        val svl = max(1e-6, hypot(svx, svy))
        for (i in 0 until n) {
            val z = vz[i]
            val x = vx[i].toDouble(); val y = vy[i].toDouble()
            if (z < 0f) {
                val d = rr[i].toDouble()
                if (d >= 1.16) { pixels[i] = 0; continue }
                val t = (1.16 - d) / 0.16
                val lit = (0.5 + 0.5 * ((x / d) * svx + (y / d) * svy) / svl).coerceIn(0.0, 1.0)
                val a = (t * t * 0.55 * (0.15 + 0.85 * lit) * 255).toInt().coerceIn(0, 255)
                pixels[i] = (a shl 24) or (90 shl 16) or (160 shl 8) or 255
                continue
            }
            val zz = z.toDouble()
            val wx = x * ex + y * nx + zz * cx
            val wy = x * ey + y * ny + zz * cy
            val wz = y * nz + zz * cz
            val lat = asin(wz.coerceIn(-1.0, 1.0))
            val lon = atan2(wy, wx)
            val mi = (((lon / PI + 1) * 0.5 * Land.MW).toInt()).coerceIn(0, Land.MW - 1)
            val mj = (((0.5 - lat / PI) * Land.MH).toInt()).coerceIn(0, Land.MH - 1)
            val land = mask[mj * Land.MW + mi] / 255.0
            val dl = wx * sx + wy * sy + wz * sz
            val day = sm(-0.1, 0.22, dl)
            val alat = abs(lat) * 180 / PI
            // land colour
            var lr = 62.0; var lg = 128.0; var lb = 58.0
            val desert = sm(12.0, 24.0, alat) * (1 - sm(34.0, 44.0, alat)) * 0.6
            lr += (196 - lr) * desert; lg += (168 - lg) * desert; lb += (110 - lb) * desert
            val snow = sm(58.0, 72.0, alat)
            lr += (240 - lr) * snow; lg += (244 - lg) * snow; lb += (250 - lb) * snow
            val nz2 = 0.9 + 0.2 * hash(mi shr 1, mj shr 1)
            lr *= nz2; lg *= nz2; lb *= nz2
            var r = 12 + (lr - 12) * land; var g = 62 + (lg - 62) * land; var b = 140 + (lb - 140) * land
            val lit = 0.35 + 0.65 * max(0.0, dl)
            r *= lit; g *= lit; b *= lit
            // specular on ocean
            val nd = (x * hx + y * hy + zz * hz) / hn
            if (land < 0.5 && nd > 0) { val sp2 = nd.pow(60.0) * 0.7 * day; r += 255 * sp2; g += 255 * sp2; b += 255 * sp2 }
            // clouds
            val cv = sin(lon * 3.0 + 1.3 * sin(lat * 4.0) + cloudT * 20) * sin(lat * 5.0 + 0.8 * cos(lon * 4.0))
            val cloud = sm(0.35, 0.85, cv) * 0.5
            r += (255 - r) * cloud * lit; g += (255 - g) * cloud * lit; b += (255 - b) * cloud * lit
            // night side
            var nr = 4 + land * 8; var ng = 8 + land * 10; var nb = 22 + land * 8
            if (land > 0.5 && alat < 64) {
                val c1 = hash(mi / 3, mj / 3); val c2 = hash(mi / 14 + 7, mj / 14)
                if (c1 > 0.8 && c2 > 0.45) { nr += 255 * 0.9; ng += 190 * 0.9; nb += 90 * 0.9 }
            }
            r = nr * (1 - day) + r * day; g = ng * (1 - day) + g * day; b = nb * (1 - day) + b * day
            val tw = exp(-(dl / 0.13) * (dl / 0.13))
            r += 90 * tw * 0.8; g += 38 * tw * 0.8
            val f = 1 - zz; val atm = f * f * f * (0.25 + 0.75 * day)
            r += 70 * atm; g += 140 * atm; b += 255 * atm
            pixels[i] = (255 shl 24) or (r.toInt().coerceIn(0, 255) shl 16) or (g.toInt().coerceIn(0, 255) shl 8) or b.toInt().coerceIn(0, 255)
        }
    }

    private val dst = RectF()
    override fun onDraw(c: Canvas) {
        val s = min(width, height).toFloat(); val l = (width - s) / 2f; val t = (height - s) / 2f
        dst.set(l, t, l + s, t + s)
        synchronized(lock) { c.drawBitmap(front, null, dst, bmpPaint) }
        val rad = s / 2f * R.toFloat(); val cx = width / 2f; val cy = height / 2f
        val pulse = (SystemClock.uptimeMillis() % 1800L) / 1800f
        val d2r = PI / 180
        val pl = lat0 * d2r; val pL = lon0 * d2r
        val cl = cos(pl); val sl = sin(pl); val cL = cos(pL); val sL = sin(pL)
        fun mark(city: City, col: Int, big: Boolean) {
            val la = city.lat * d2r; val lo = city.lon * d2r
            val wx = cos(la) * cos(lo); val wy = cos(la) * sin(lo); val wz = sin(la)
            val z = wx * cl * cL + wy * cl * sL + wz * sl
            if (z < 0.08) return
            val x = wx * -sL + wy * cL
            val y = wx * (-sl * cL) + wy * (-sl * sL) + wz * cl
            val px = cx + (x * rad).toFloat(); val py = cy - (y * rad).toFloat()
            val a = ((z - 0.08) / 0.2).coerceIn(0.0, 1.0).toFloat()
            ring.color = alphaColor(col, (1f - pulse) * a); ring.strokeWidth = dp(1.6f)
            c.drawCircle(px, py, dp(3) + pulse * dp(if (big) 14 else 9), ring)
            dot.color = alphaColor(Color.WHITE, a); c.drawCircle(px, py, dp(if (big) 4.6f else 3.4f), dot)
            dot.color = alphaColor(col, a); c.drawCircle(px, py, dp(if (big) 3.2f else 2.2f), dot)
        }
        for (m in markers) mark(m, C.ORANGE, false)
        local?.let { mark(it, C.CYAN, true) }
        if (!running) startLoop()
    }

    override fun onTouchEvent(e: MotionEvent): Boolean {
        when (e.actionMasked) {
            MotionEvent.ACTION_DOWN -> { parent?.requestDisallowInterceptTouchEvent(true); lx = e.x; ly = e.y; lastTouch = SystemClock.uptimeMillis(); target = Double.NaN }
            MotionEvent.ACTION_MOVE -> {
                val k = 160f / (min(width, height) * 0.43f)
                lon0 -= (e.x - lx) * k * 0.55; lat0 = (lat0 + (e.y - ly) * k * 0.55).coerceIn(-75.0, 75.0)
                lx = e.x; ly = e.y; lastTouch = SystemClock.uptimeMillis()
            }
            MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> lastTouch = SystemClock.uptimeMillis()
        }
        return true
    }
}
