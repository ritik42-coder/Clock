package com.chronox.clock

import android.content.Context
import android.graphics.*
import android.os.SystemClock
import android.view.MotionEvent
import android.view.View
import java.util.TimeZone
import java.util.concurrent.Callable
import java.util.concurrent.Executors
import java.util.concurrent.atomic.AtomicBoolean
import kotlin.math.*

/** Global "time travel" offset used by the Earth and the world-clock rows. */
object Tt {
    @Volatile var offset = 0L
    fun now(): Long = System.currentTimeMillis() + offset
}

object Sun {
    /** returns [subsolar longitude, declination] in degrees */
    fun position(ms: Long): DoubleArray {
        val cal = java.util.Calendar.getInstance(TimeZone.getTimeZone("UTC")).also { it.timeInMillis = ms }
        val h = cal.get(java.util.Calendar.HOUR_OF_DAY) + cal.get(java.util.Calendar.MINUTE) / 60.0 +
            cal.get(java.util.Calendar.SECOND) / 3600.0 + cal.get(java.util.Calendar.MILLISECOND) / 3.6e6
        val doy = cal.get(java.util.Calendar.DAY_OF_YEAR)
        val b = 2 * PI * (doy - 81) / 364.0
        val eot = 9.87 * sin(2 * b) - 7.53 * cos(b) - 1.5 * sin(b)
        val lon = (12.0 - h) * 15.0 - eot / 4.0
        val dec = -23.44 * cos(2 * PI / 365.0 * (doy + 10))
        return doubleArrayOf(((lon + 540.0) % 360.0) - 180.0, dec)
    }
    fun elevation(lat: Double, lon: Double, sunLon: Double, sunLat: Double): Double {
        val p = Math.toRadians(lat); val d = Math.toRadians(sunLat); val dl = Math.toRadians(lon - sunLon)
        return Math.toDegrees(asin((sin(p) * sin(d) + cos(p) * cos(d) * cos(dl)).coerceIn(-1.0, 1.0)))
    }
    /** [sunrise, sunset] in epoch ms, or null during polar day / night */
    fun times(lat: Double, lon: Double, nowMs: Long): LongArray? {
        val jd = nowMs / 86400000.0 + 2440587.5
        val n = ceil(jd - 2451545.0 + 0.0008)
        val js = n - lon / 360.0
        val m = Math.toRadians((357.5291 + 0.98560028 * js) % 360.0)
        val c = 1.9148 * sin(m) + 0.02 * sin(2 * m) + 0.0003 * sin(3 * m)
        val lam = Math.toRadians((Math.toDegrees(m) + c + 180.0 + 102.9372) % 360.0)
        val jt = 2451545.0 + js + 0.0053 * sin(m) - 0.0069 * sin(2 * lam)
        val sinD = sin(lam) * sin(Math.toRadians(23.44)); val cosD = cos(asin(sinD))
        val phi = Math.toRadians(lat)
        val cw = (sin(Math.toRadians(-0.833)) - sin(phi) * sinD) / (cos(phi) * cosD)
        if (cw < -1.0 || cw > 1.0) return null
        val w0 = Math.toDegrees(acos(cw))
        return longArrayOf(((jt - w0 / 360.0 - 2440587.5) * 86400000.0).toLong(), ((jt + w0 / 360.0 - 2440587.5) * 86400000.0).toLong())
    }
}

private class Noise(seed: Long) {
    private val g = FloatArray(256 * 256)
    init { val r = java.util.Random(seed); for (i in g.indices) g[i] = r.nextFloat() }
    private fun cell(ix: Int, iy: Int): Float = g[((iy and 255) shl 8) or (ix and 255)]
    fun at(x: Float, y: Float, per: Int): Float {
        val x0 = floor(x).toInt(); val y0 = floor(y).toInt()
        val fx = x - x0; val fy = y - y0
        val sx = fx * fx * (3f - 2f * fx); val sy = fy * fy * (3f - 2f * fy)
        val xa = Math.floorMod(x0, per); val xb = Math.floorMod(x0 + 1, per)
        val a = cell(xa, y0); val b = cell(xb, y0); val c = cell(xa, y0 + 1); val d = cell(xb, y0 + 1)
        return a + (b - a) * sx + (c - a) * sy + (a - b - c + d) * sx * sy
    }
    /** u in [0,1) wraps seamlessly horizontally, v in [0,1] */
    fun fbm(u: Float, v: Float, oct: Int, base: Int = 16): Float {
        var f = base; var amp = 0.5f; var s = 0f; var norm = 0f
        for (k in 0 until oct) { s += amp * at(u * f, v * f * 0.5f, f); norm += amp; amp *= 0.5f; f *= 2 }
        return s / norm
    }
}

object Planet {
    const val TW = 1440
    const val TH = 720
    @Volatile var ready = false
    lateinit var landM: ByteArray
    lateinit var day: IntArray
    lateinit var lights: ByteArray
    lateinit var border: ByteArray
    lateinit var cloud: ByteArray
    private val busy = AtomicBoolean(false)

    fun ensure() {
        if (ready || !busy.compareAndSet(false, true)) return
        Thread {
            try { build() } catch (e: Throwable) { busy.set(false) }
        }.also { it.priority = Thread.NORM_PRIORITY - 1; it.start() }
    }

    private val POLYS = listOf(
        "-168,66 -162,70 -156,71 -140,70 -128,70 -115,68 -95,72 -82,69 -80,63 -93,60 -94,57 -85,55 -80,52 -78,58 -77,62 -70,60 -62,58 -56,52 -60,47 -66,44 -70,42 -74,40 -76,35 -81,31 -80,26 -82,27 -84,30 -90,29 -97,27 -97,22 -94,18 -90,21 -87,21 -88,16 -83,15 -83,10 -77,8 -80,7 -86,11 -92,15 -97,16 -105,20 -109,25 -113,31 -117,32 -121,35 -124,40 -124,47 -128,51 -134,57 -141,60 -148,60 -154,58 -162,55 -158,58 -165,61",
        "-73,78 -60,82 -30,83 -20,80 -20,72 -30,68 -43,60 -50,64 -55,70 -68,76",
        "-77,8 -72,12 -62,11 -52,5 -50,0 -44,-2 -35,-6 -39,-14 -41,-22 -48,-26 -53,-34 -58,-38 -65,-41 -68,-50 -69,-54 -74,-52 -74,-42 -71,-30 -70,-18 -76,-14 -81,-5 -80,0 -78,3",
        "-9,37 -9,43 -2,43.5 -4,48 2,51 8,54 14,54 22,55 24,58 30,60 34,66 40,67 44,68 60,69 70,73 80,73 100,77 113,74 130,72 142,72 160,70 170,70 180,68 180,65 178,62 165,60 163,60 157,52 155,57 143,59 137,54 141,52 140,48 135,43 130,42 129,35 126,35 126,38 125,40 122,40 121,38 118,38 119,35 122,31 122,28 119,25 114,22 108,21 106,18 109,13 105,9 100,13 100,8 103,1 100,4 98,10 98,16 94,17 92,21 90,22 87,21 80,15 80,10 77,8 73,16 72,21 67,24 62,25 57,26 56,26 58,23 55,17 44,12 43,15 39,21 35,28 34,31 35,34 36,36 30,36 27,37 26,40 24,38 22,36.5 21,38 19.5,41 16,43 13.5,45.5 12.5,44 14,42 16,41 18,40.3 16,38 15.5,40 12,42 10.5,43.5 8.5,44.5 6,43 3,43 0,39 -1,37 -5,36",
        "5,59 5,62 14,68 24,71 31,70 28,66 24,65 21,61 18,60 16,56 12,56 11,59 8,58",
        "-5,50 1,51 2,53 -2,56 -2,58 -5,58.5 -6,56 -3,54.5 -5,52",
        "-10,52 -6,52 -6,55 -9,54.5",
        "-24,65 -14,64 -14,66 -22,66.5",
        "130,31 132,34 135,34.5 140,35 141,38 142,41 140,41 139.5,38 136,37 132,35.5 130,33",
        "140,42 145,43 142,45.5",
        "-17,21 -13,28 -9,32 -6,36 10,37 11,33 20,31 25,32 32.5,31 34,28 35,24 38,18 43,12 51,12 48,5 41,-2 40,-10 40,-15 35,-20 35,-25 32,-29 27,-34 20,-35 18,-32 14,-23 12,-15 13,-6 9,-1 9,4 5,6 -4,5 -8,4 -13,8 -17,14",
        "44,-25 47,-25 50,-15 49,-12 44,-17",
        "114,-22 122,-18 130,-12 137,-12 136,-15 141,-17 142,-11 146,-19 153,-26 151,-34 147,-38 141,-38 135,-35 131,-31 124,-33 115,-34 114,-26",
        "95,5 98,4 106,-3 105,-6 101,-3",
        "109,1 114,4 119,5 117,-1 116,-4 111,-3",
        "105,-6 114,-7 114,-8.5 106,-7.5",
        "131,-1 141,-3 150,-10 142,-9 138,-8 132,-4",
        "172,-34 178,-38 175,-41 172,-41",
        "172,-41 174,-42 170,-46 167,-46",
        "-85,22 -80,23 -74,20 -78,20",
        "-80,73 -72,71 -62,67 -64,63 -72,62 -78,64 -88,70",
        "-125,72 -115,73 -105,73 -100,70 -112,69 -120,70",
        "-90,77 -80,76 -64,80 -70,83 -90,82",
        "12,77 22,80 27,79 18,77",
        "52,71 58,76 68,77 60,74 56,71",
        "-59,47.5 -53,47 -53,51 -56,52",
        "-74,19.5 -69,19.8 -68.5,18.4 -72,18",
        "120,22 121.9,25 121,25.3 120,23",
        "108.7,19.3 111,19.8 110.5,18.2",
        "142,46 143.5,49 143,54 142,52",
        "79.8,9.5 81.8,7.5 81,6 80,6.2",
        "120,18.5 122,18.3 122,14 120.5,14",
        "122,8.5 126,9 126.5,7 125,6 122,7",
        "119,-1 120.5,1 125,1.5 122,-1 123,-4.5 120.5,-5.5",
        "144.5,-41 148,-41 147,-43.5 145,-42.8",
        "-180,-90 -180,-71 -150,-76 -100,-73 -65,-68 -60,-64 -55,-72 -30,-72 0,-70 40,-67 80,-67 110,-66 150,-69 170,-72 180,-72 180,-90"
    )
    private val WATER = listOf(
        "28,41.5 28,45 34,46 37,47 41,42 36,41.5 31,41",
        "47,45 50,46 53,45 53,40 54,37 50,37 49,40 47,43",
        "48.5,30 50,28 51,26 51.5,24.5 54,24 56,26 56,27 53,27.5 50.5,29.5",
        "-92,46.7 -88,48.8 -84.5,47 -87,46.5",
        "-87.8,42 -87,45.8 -85,45.5 -86.5,42",
        "31.7,0 34.5,-0.2 33,-3 31.7,-2"
    )
    private val BORDERS = listOf(
        "-123,49 -95,49 -94.6,48.7 -89.6,48 -84.5,46.5 -82.5,45.3 -83,42 -79,43.3 -76,44 -74.7,45 -71.5,45 -69,47.4 -67.8,47.1 -67,45",
        "-117,32.5 -114.7,32.7 -111,31.3 -108.2,31.3 -106.5,31.8 -104.5,29.6 -103,29 -101,29.8 -99.5,27.5 -97.2,25.9",
        "-141,60 -141,69.6", "-92,14.5 -91.5,17.2 -90.5,17.8 -89,17.8 -88,18.5",
        "-53.5,-33.7 -57.6,-30.2 -55.5,-27.8 -54,-25.6 -54.6,-24 -55.5,-22 -58,-20 -58,-16 -60,-13.5 -65,-10 -69.5,-10.5 -73.5,-7.5 -70,-4 -69.5,-1.5 -67,1.5 -64,4 -60.5,5 -57,2 -54,2.2",
        "-68,-22 -68.5,-30 -70.5,-33 -71.5,-40 -72,-47 -72.5,-50 -69,-52 -68.5,-55",
        "-68,-22 -65,-22 -62,-22 -58,-24 -57.6,-30.2", "-70,-18 -69,-12 -69.5,-10.5", "-72.5,12 -72,7 -67.5,6 -67.8,2 -69.5,-1 -70,-4",
        "-80,-3 -75,-1 -73,-4 -70,-4", "-78,2 -77,0 -75,-1",
        "28.5,69.5 30,67.5 29.5,64 31.5,62 28,60.5", "28,59.5 28,56.5 31,55 32,52.5 35,52 38,50 40,49.5 40,48 38,47",
        "38,47 40,44 46,41.8 49,41.3", "47,47 50,51 61,50.5 61,54 70,55 76,54 80,51 87,49",
        "87,49 90,50.5 98,50 106,50.4 115,50 120,52.5", "119,52.5 126,52.8 127,50 135,48.2 134,45 131,43",
        "87,49 90,47.5 96,44.5 105,42 112,43 116,45 119,47 119,49.5 117,49.6",
        "80,45 80,42 74,40 74,37 75,36.5 77,35.5",
        "68,23.5 70,24.3 71,27 74.5,31 75,32.5 74,34.5", "74,34.5 78,35.5 79,33 81,30 88,27.5 92,27.8 95,29 97,28",
        "97,28 98,24 101,21.5 102,22.5 105,23 108,21.7", "97,28 94,24 92.5,22 89,22.5", "128,42 124,40",
        "53,42 56,45 58,45 61,44.5 66,43 70,42 74,43", "44.8,37 46,35 47.5,33 48.5,30", "61,25.5 62,28 61,31 60.5,34.5 61,36.5 60,37.5 54,37.3",
        "61,29.5 66,29.5 70,31.5 71,34 74,37", "36,29.5 39,32 44,29 47.5,29", "43,17 47,16.7 52,19", "52,22.5 55,22.8 55.7,24",
        "25,31.6 25,22", "25,22 36.9,22", "10,33 9.5,30 12,23.5 15,23 24,20", "8.5,37 7.5,34.5 9.5,30",
        "-1.7,35 -1.3,32 -2.2,32 -5,30 -8.7,28.7 -8.7,27.7 -13,27.7", "-8.7,27.7 -5,25 4.2,19.1 12,23.5", "-12.2,14.8 -12,17 -6,19.5",
        "4,13.7 7,13.4 13,13.7 14.5,12.5", "2.7,6.4 2.7,9 4,11 4,13.7", "24,20 22,15 22,12.5", "22,12.5 27,9.8 34,9.5 36,8.5",
        "36,8.5 34.5,6 39,3.7 41,4 43,3 47.5,8", "34,-1 37.5,-3 39.2,-4.7",
        "12,-5 16,-5 18,-8 21,-9 24,-11 28,-12 30,-8 29,-4 29.5,-1 30,1 31,3 27,5 23,4.5 18,4 15,2 12,-5",
        "16.5,-28.5 20,-25 22,-25.5 25,-25 27,-23 31.3,-22.4 32,-26.8 31,-29", "12,-17 17,-17.5 22,-17.5 24,-17.5 23.5,-13 22,-11 22,-8",
        "30,-8 33,-9.5 33.5,-14", "-1.8,43.3 3,42.5", "8,49 6,49.5 4,50.2 2.5,51", "14.2,54 14.6,52 15,51 14.8,50.9", "23.5,52 24,50.8 23,49.5 22.5,49",
        "36,36 38,36.8 42,37.2 44,37", "42,37.2 41,34.5 38.7,33.4 36,33", "7,43.8 7,45 6.8,46", "6.8,46 9,46.3 12,47 13.7,46.5",
        "-9,42 -7,41.5 -7,38 -7.4,37.2", "98,16 99,12 98.6,10", "101,17.5 105,15 105,14.4 102,12.4", "102,22.5 104,20 106,17.5 107.5,14.5 107.5,11.5"
    )
    // desert / mountain blobs: lon, lat, rx, ry
    private val DESERTS = floatArrayOf(15f,24f,28f,8f, 46f,24f,10f,7f, 58f,34f,8f,5f, 105f,42f,12f,5f, 71f,27f,4f,3f, 134f,-25f,14f,8f,
        22f,-24f,6f,4f, 15f,-22f,3f,5f, -70f,-22f,2f,6f, -69f,-44f,4f,6f, -112f,35f,7f,5f, -106f,29f,5f,4f, 46f,5f,4f,4f, 83f,39f,5f,3f, 10f,31f,6f,4f)
    private val MOUNTS = floatArrayOf(85f,32f,14f,5f, -110f,45f,4f,12f, -70f,-20f,3f,25f, 10f,46.5f,5f,2f, 60f,60f,2f,8f, 40f,9f,3f,3f, 75f,38f,6f,3f, 100f,30f,5f,5f, -5f,32f,3f,1.5f, 145f,-5f,6f,2f, 8f,25f,3f,2f)
    private val DEV = floatArrayOf(-80f,40f,10f,6f, 8f,49f,12f,6f, 80f,26f,8f,4f, 115f,32f,6f,6f, 137f,36f,3f,4f, 127f,37f,1.5f,2f, 110f,-7f,5f,1.5f, 31f,28f,1.2f,4f, 5f,8f,3f,2f,
        -46f,-22f,5f,4f, -60f,-34f,4f,3f, -100f,20f,4f,3f, -120f,36f,3f,3f, -85f,43f,5f,3f, -1f,52f,3f,3f, 53f,26f,3f,2f, 28f,-27f,3f,2f, 150f,-34f,3f,3f,
        32f,39f,5f,2f, 38f,56f,3f,2f, 72f,31f,4f,3f, 105f,22f,4f,3f, 101f,14f,3f,4f, -75f,5f,3f,3f, 30f,50f,5f,3f, 20f,52f,5f,3f, 120f,23.5f,1f,2f, 122f,14f,2f,3f)
    private val CITIES = "139.7,35.7,10;77.2,28.6,10;121.5,31.2,9;90.4,23.8,8;-46.6,-23.5,9;-99.1,19.4,8;31.2,30,8;72.9,19.1,9;116.4,39.9,9;135.5,34.7,7;-74,40.7,10;67,24.9,7;106.5,29.6,6;29,41,7;-58.4,-34.6,8;88.4,22.6,8;3.4,6.5,8;15.3,-4.3,6;121,14.6,8;-43.2,-22.9,7;117.2,39.1,6;113.3,23.1,8;-118.2,34,8;37.6,55.8,8;114.1,22.5,7;74.3,31.5,6;77.6,13,7;2.35,48.9,8;-74.1,4.7,6;106.8,-6.2,9;80.3,13.1,6;-77,-12,6;100.5,13.8,7;127,37.6,8;136.9,35.2,5;78.5,17.4,6;-0.1,51.5,8;51.4,35.7,7;-87.6,41.9,7;104.1,30.7,6;118.8,32.1,5;114.3,30.6,6;106.7,10.8,7;13.2,-8.8,5;72.6,23,5;101.7,3.1,6;108.9,34.3,5;114.2,22.3,8;120.2,30.3,5;123.4,41.8,5;46.7,24.7,6;44.4,33.3,6;-70.7,-33.5,6;-3.7,40.4,6;120.6,31.3,5;73.9,18.5,5;126.6,45.8,4;-95.4,29.8,6;-96.8,32.8,6;-79.4,43.7,6;39.3,-6.8,5;-80.2,25.8,6;103.8,1.35,7;-75.2,40,5;-84.4,33.7,5;130.4,33.6,4;32.5,15.6,5;2.2,41.4,5;28,-26.2,6;30.3,59.9,5;120.4,36.1,4;-77,38.9,5;96.2,16.8,5;29.9,31.2,5;-103.3,20.7,5;13.4,52.5,6;12.5,41.9,6;9.2,45.5,5;30.5,50.5,5;-7.6,33.6,5;36.8,-1.3,5;38.7,9,5;-0.2,5.6,5;-4,5.3,5;3,36.8,5;151.2,-33.9,6;145,-37.8,5;115.9,-32,3;153,-27.5,4;174.8,-36.8,4;-123.1,49.3,4;-122.4,37.8,6;-122.3,47.6,4;-105,39.7,4;-112,33.4,4;-71,42.4,5;-83,42.3,4;-73.6,45.5,5;-66.9,10.5,5;-75.6,6.2,4;-56.2,-34.9,4;-47.9,-15.8,5;-51.2,-30,4;-34.9,-8,4;-38.5,-3.7,4;55.3,25.2,6;34.8,32.1,5;32.9,39.9,5;121.5,25,7;105.8,21,6;79.9,6.9,4;85.3,27.7,4;69.2,34.5,4;69.3,41.3,5;76.9,43.2,4;21,52.2,5;16.4,48.2,5;23.7,38,4;-9.1,38.7,4;4.9,52.4,5;18.1,59.3,4;18.4,-33.9,4;31,-29.9,3;-17.5,14.7,4;8.5,12,4;10.2,36.8,3"

    private fun parse(s: String): FloatArray {
        val parts = s.split(" "); val out = FloatArray(parts.size * 2)
        for (i in parts.indices) { val a = parts[i].split(","); out[i * 2] = a[0].toFloat(); out[i * 2 + 1] = a[1].toFloat() }
        return out
    }
    private fun sub(ax: Float, ay: Float, bx: Float, by: Float, depth: Int, amp: Float, out: ArrayList<Float>, rnd: java.util.Random) {
        val dx = bx - ax; val dy = by - ay; val len = sqrt(dx * dx + dy * dy)
        if (depth >= 4 || len < 1.6f) return
        val mx = (ax + bx) / 2 + (-dy / len) * (rnd.nextFloat() - 0.5f) * len * amp
        val my = (ay + by) / 2 + (dx / len) * (rnd.nextFloat() - 0.5f) * len * amp
        sub(ax, ay, mx, my, depth + 1, amp, out, rnd); out.add(mx); out.add(my); sub(mx, my, bx, by, depth + 1, amp, out, rnd)
    }
    private fun fractal(p: FloatArray, closed: Boolean, amp: Float, rnd: java.util.Random): FloatArray {
        val out = ArrayList<Float>(); val n = p.size / 2
        val last = if (closed) n else n - 1
        for (i in 0 until n) {
            val ax = p[i * 2]; val ay = p[i * 2 + 1]
            out.add(ax); out.add(ay)
            if (i < last) {
                val j = (i + 1) % n; val bx = p[j * 2]; val by = p[j * 2 + 1]
                val seam = (abs(ax) == 180f && abs(bx) == 180f) || (ay <= -89f && by <= -89f)
                if (!seam) sub(ax, ay, bx, by, 0, amp, out, rnd)
            }
        }
        return out.toFloatArray()
    }
    private fun toPath(p: FloatArray, closed: Boolean): Path {
        val path = Path()
        for (i in 0 until p.size / 2) {
            val x = (p[i * 2] + 180f) * 4f; val y = (90f - p[i * 2 + 1]) * 4f
            if (i == 0) path.moveTo(x, y) else path.lineTo(x, y)
        }
        if (closed) path.close()
        return path
    }
    private fun boxBlur(src: ByteArray, w: Int, h: Int, r: Int): ByteArray {
        val tmp = IntArray(w * h); val out = ByteArray(w * h); val d = 2 * r + 1
        for (y in 0 until h) {
            val row = y * w; var sum = 0
            for (x in -r..r) sum += src[row + Math.floorMod(x, w)].toInt() and 255
            for (x in 0 until w) {
                tmp[row + x] = sum / d
                sum += (src[row + Math.floorMod(x + r + 1, w)].toInt() and 255) - (src[row + Math.floorMod(x - r, w)].toInt() and 255)
            }
        }
        for (x in 0 until w) {
            var sum = 0
            for (y in -r..r) sum += tmp[y.coerceIn(0, h - 1) * w + x]
            for (y in 0 until h) {
                out[y * w + x] = (sum / d).toByte()
                sum += tmp[(y + r + 1).coerceIn(0, h - 1) * w + x] - tmp[(y - r).coerceIn(0, h - 1) * w + x]
            }
        }
        return out
    }
    private fun sm(e0: Float, e1: Float, x: Float): Float { val t = ((x - e0) / (e1 - e0)).coerceIn(0f, 1f); return t * t * (3f - 2f * t) }
    private fun mixf(a: Float, b: Float, t: Float) = a + (b - a) * t
    private fun blob(arr: FloatArray, lon: Float, lat: Float): Float {
        var best = 0f; var i = 0
        while (i < arr.size) {
            val dx = (lon - arr[i]) / arr[i + 2]; val dy = (lat - arr[i + 1]) / arr[i + 3]
            if (abs(dx) < 3f && abs(dy) < 3f) { val v = exp(-(dx * dx + dy * dy)); if (v > best) best = v }
            i += 4
        }
        return best
    }

    private fun build() {
        val n = TW * TH
        val rnd = java.util.Random(7)
        val bmp = Bitmap.createBitmap(TW, TH, Bitmap.Config.ARGB_8888)
        val cv = Canvas(bmp)
        val paint = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.WHITE; style = Paint.Style.FILL }
        for (s in POLYS) cv.drawPath(toPath(fractal(parse(s), true, 0.34f, rnd), true), paint)
        paint.xfermode = PorterDuffXfermode(PorterDuff.Mode.CLEAR)
        for (s in WATER) cv.drawPath(toPath(fractal(parse(s), true, 0.2f, rnd), true), paint)
        val px = IntArray(n); bmp.getPixels(px, 0, TW, 0, 0, TW, TH)
        val lm = ByteArray(n); for (i in 0 until n) lm[i] = (px[i] ushr 24).toByte()
        // borders
        bmp.eraseColor(0)
        val bp = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.WHITE; style = Paint.Style.STROKE; strokeWidth = 1.7f; strokeCap = Paint.Cap.ROUND; strokeJoin = Paint.Join.ROUND }
        for (s in BORDERS) cv.drawPath(toPath(fractal(parse(s), false, 0.16f, rnd), false), bp)
        bmp.getPixels(px, 0, TW, 0, 0, TW, TH)
        val bd = ByteArray(n)
        for (i in 0 until n) bd[i] = if ((lm[i].toInt() and 255) > 110) (px[i] ushr 24).toByte() else 0
        bmp.recycle()
        val blur = boxBlur(lm, TW, TH, 7)
        val nz = Noise(11); val nz2 = Noise(23); val nz3 = Noise(37)

        // day colour map
        val dayArr = IntArray(n)
        for (y in 0 until TH) {
            val lat = 90f - (y + 0.5f) / TH * 180f; val v = (y + 0.5f) / TH; val la = abs(lat)
            for (x in 0 until TW) {
                val i = y * TW + x; val u = (x + 0.5f) / TW; val lon = u * 360f - 180f
                val land = (lm[i].toInt() and 255) / 255f
                var lr = 0f; var lg = 0f; var lb = 0f
                if (land > 0.01f) {
                    val nv = nz.fbm(u, v, 4, 16)
                    val detail = nz2.fbm(u, v, 5, 64)
                    val t1 = sm(10f, 30f, la); val t2 = sm(48f, 60f, la); val t3 = sm(62f, 72f, la)
                    val dry = sm(0.42f, 0.7f, nv)
                    val tr = mixf(24f, 122f, dry); val tg = mixf(88f, 134f, dry); val tb = mixf(42f, 68f, dry)
                    val mt = mixf(52f, 86f, nv); val mg = mixf(104f, 128f, nv); val mb = mixf(50f, 62f, nv)
                    var r = mixf(tr, mt, t1); var g = mixf(tg, mg, t1); var b = mixf(tb, mb, t1)
                    r = mixf(r, 36f, t2); g = mixf(g, 74f, t2); b = mixf(b, 54f, t2)
                    r = mixf(r, 130f, t3); g = mixf(g, 132f, t3); b = mixf(b, 114f, t3)
                    val dsr = (blob(DESERTS, lon, lat) * (0.55f + 0.9f * nv)).coerceIn(0f, 1f) * 1.5f
                    val dd = dsr.coerceIn(0f, 1f)
                    val sr = mixf(208f, 178f, detail); val sg = mixf(176f, 132f, detail); val sb = mixf(116f, 88f, detail)
                    r = mixf(r, sr, dd); g = mixf(g, sg, dd); b = mixf(b, sb, dd)
                    val mm = (blob(MOUNTS, lon, lat) * (0.5f + detail)).coerceIn(0f, 1f)
                    r = mixf(r, 126f, mm * 0.8f); g = mixf(g, 112f, mm * 0.8f); b = mixf(b, 100f, mm * 0.8f)
                    var ice = sm(72f, 80f, la)
                    val gl = exp(-(((lon + 42f) / 26f) * ((lon + 42f) / 26f) + ((lat - 73f) / 9f) * ((lat - 73f) / 9f)))
                    if (gl > ice) ice = sm(0.15f, 0.55f, gl)
                    if (lat < -66f) ice = 1f
                    val snowMt = sm(0.62f, 0.95f, mm) * 0.9f
                    if (snowMt > ice) ice = snowMt
                    r = mixf(r, 242f, ice); g = mixf(g, 247f, ice); b = mixf(b, 252f, ice)
                    val sh = 0.80f + 0.38f * detail
                    lr = r * sh; lg = g * sh; lb = b * sh
                }
                var orr = 0f; var og = 0f; var ob = 0f
                if (land < 0.99f) {
                    val ov = 0.86f + 0.3f * nz3.fbm(u, v, 3, 16)
                    val coast = sm(0.02f, 0.55f, (blur[i].toInt() and 255) / 255f)
                    var r = 5f * ov; var g = 38f * ov; var b = 88f * ov
                    r = mixf(r, 28f, coast * 0.85f); g = mixf(g, 138f, coast * 0.85f); b = mixf(b, 176f, coast * 0.85f)
                    val sea = sm(70f, 80f, la) * 0.9f
                    r = mixf(r, 226f, sea); g = mixf(g, 238f, sea); b = mixf(b, 246f, sea)
                    orr = r; og = g; ob = b
                }
                val fr = mixf(orr, lr, land).toInt().coerceIn(0, 255); val fg = mixf(og, lg, land).toInt().coerceIn(0, 255); val fb = mixf(ob, lb, land).toInt().coerceIn(0, 255)
                dayArr[i] = (255 shl 24) or (fr shl 16) or (fg shl 8) or fb
            }
        }

        // city lights
        val acc = IntArray(n)
        fun splat(lon: Float, lat: Float, sigmaTex: Float, peak: Float) {
            val cx = (lon + 180f) * 4f; val cy = (90f - lat) * 4f
            val rr = (sigmaTex * 3f).toInt() + 1
            for (dy in -rr..rr) {
                val yy = (cy + dy).toInt(); if (yy < 0 || yy >= TH) continue
                for (dx in -rr..rr) {
                    val xx = Math.floorMod((cx + dx).toInt(), TW)
                    val d2 = (dx * dx + dy * dy).toFloat()
                    acc[yy * TW + xx] += (peak * exp(-d2 / (2f * sigmaTex * sigmaTex))).toInt()
                }
            }
        }
        for (c in CITIES.split(";")) {
            val a = c.split(","); val lon = a[0].toFloat(); val lat = a[1].toFloat(); val w = a[2].toFloat()
            splat(lon, lat, 0.7f + 0.2f * w, 100f + 16f * w)
            splat(lon, lat, 2.6f + 0.6f * w, 26f + 3f * w)
            val sat = 5 + (w * 1.6f).toInt()
            for (k in 0 until sat) {
                val ang = rnd.nextFloat() * 6.2832f; val dist = (0.3f + rnd.nextFloat() * (1.2f + 0.25f * w)) * (1f + 0.5f * rnd.nextFloat())
                splat(lon + cos(ang) * dist, lat + sin(ang) * dist * 0.8f, 0.8f + rnd.nextFloat(), 40f + rnd.nextFloat() * 70f)
            }
        }
        var bi = 0
        while (bi < DEV.size) {
            val bl = DEV[bi]; val bt = DEV[bi + 1]; val rx = DEV[bi + 2]; val ry = DEV[bi + 3]
            val x0 = ((bl - rx * 2.6f + 180f) * 4f).toInt(); val x1 = ((bl + rx * 2.6f + 180f) * 4f).toInt()
            val y0 = max(0, ((90f - bt - ry * 2.6f) * 4f).toInt()); val y1 = min(TH - 1, ((90f - bt + ry * 2.6f) * 4f).toInt())
            for (yy in y0..y1) for (xx in x0..x1) {
                val xw = Math.floorMod(xx, TW); val lon = xx / 4f - 180f; val lat = 90f - yy / 4f
                val dx = (lon - bl) / rx; val dy = (lat - bt) / ry
                val dens = exp(-(dx * dx + dy * dy))
                val nn = nz2.fbm((xw + 0.5f) / TW, (yy + 0.5f) / TH, 4, 64)
                val q = dens * nn * nn * 2.6f
                if (q > 0.55f) acc[yy * TW + xw] += ((q - 0.5f) * 150f).toInt()
            }
            bi += 4
        }
        val lt = ByteArray(n)
        for (i in 0 until n) lt[i] = if ((lm[i].toInt() and 255) > 90) min(255, acc[i]).toByte() else 0

        // clouds
        val cl = ByteArray(n)
        for (y in 0 until TH) {
            val lat = 90f - (y + 0.5f) / TH * 180f; val v = (y + 0.5f) / TH; val la = abs(lat)
            val band = 0.95f + 0.30f * exp(-(lat / 9f) * (lat / 9f)) + 0.22f * exp(-((la - 55f) / 10f) * ((la - 55f) / 10f)) - 0.20f * exp(-((la - 25f) / 8f) * ((la - 25f) / 8f))
            for (x in 0 until TW) {
                val u = (x + 0.5f) / TW
                val warp = nz.fbm(u, v, 3, 16)
                val c = nz3.fbm((u + warp * 0.12f) % 1f, v, 5, 32) * band
                cl[y * TW + x] = (sm(0.50f, 0.78f, c) * 255f).toInt().toByte()
            }
        }
        landM = lm; day = dayArr; lights = lt; border = bd; cloud = cl
        ready = true
    }
}

class Lbl(val name: String, val lon: Float, val lat: Float)
private class Pin(val city: City, val x: Float, val y: Float)

class EarthView(ctx: Context) : View(ctx) {
    private val RES = 360
    private val R = 0.86f
    private val n = RES * RES
    private val vx = FloatArray(n); private val vy = FloatArray(n); private val vz = FloatArray(n); private val rr = FloatArray(n)
    private val pixels = IntArray(n)
    private var front = Bitmap.createBitmap(RES, RES, Bitmap.Config.ARGB_8888)
    private var back = Bitmap.createBitmap(RES, RES, Bitmap.Config.ARGB_8888)
    private val lock = Any()
    private val workers = (Runtime.getRuntime().availableProcessors() / 2).coerceIn(1, 3)
    private val pool = Executors.newFixedThreadPool(workers) { r -> Thread(r).also { it.isDaemon = true } }

    @Volatile var lon0 = 77.0
    @Volatile var lat0 = 18.0
    @Volatile private var lastTouch = 0L
    @Volatile private var tLon = Double.NaN
    @Volatile private var tLat = Double.NaN
    @Volatile private var running = false
    @Volatile private var vsx = 0.6f
    @Volatile private var vsy = 0.4f
    @Volatile private var vsz = 0.6f
    private var thread: Thread? = null
    var markers: List<City> = emptyList()
    var local: City? = null
    private var selected: City? = null
    private val pins = ArrayList<Pin>()
    private val is24 = android.text.format.DateFormat.is24HourFormat(ctx)

    private val bmpPaint = Paint(Paint.FILTER_BITMAP_FLAG or Paint.ANTI_ALIAS_FLAG)
    private val fill = fillPaint(); private val ring = strokePaint(Color.WHITE, dp(1.6f))
    private val lblP = textPaint(Color.WHITE, dp(9.5f), MED, Paint.Align.CENTER)
    private val pinP = textPaint(Color.WHITE, dp(11), MED, Paint.Align.LEFT)
    private val cardBig = textPaint(C.TEXT, dp(30), LIGHT); private val cardSm = textPaint(C.DIM, dp(12.5f), REG); private val cardTitle = textPaint(C.TEXT, dp(16), MED)
    private val sx = FloatArray(120); private val sy = FloatArray(120); private val ss = FloatArray(120); private val sph = FloatArray(120)
    private var lx = 0f; private var ly = 0f; private var downT = 0L; private var moved = 0f
    private var gcx = 0f; private var gcy = 0f; private var grad = 1f
    private val tmp = FloatArray(3)
    private val dst = RectF(); private val card = RectF()
    private val LABELS = listOf(
        Lbl("UNITED STATES", -98f, 39f), Lbl("CANADA", -100f, 58f), Lbl("MEXICO", -102f, 24f), Lbl("BRAZIL", -53f, -10f), Lbl("ARGENTINA", -65f, -36f),
        Lbl("COLOMBIA", -73f, 4f), Lbl("PERU", -75f, -9f), Lbl("RUSSIA", 95f, 62f), Lbl("CHINA", 103f, 35f), Lbl("INDIA", 79f, 22f), Lbl("AUSTRALIA", 134f, -25f),
        Lbl("KAZAKHSTAN", 67f, 48f), Lbl("IRAN", 54f, 32f), Lbl("SAUDI ARABIA", 45f, 24f), Lbl("EGYPT", 30f, 26f), Lbl("ALGERIA", 3f, 28f), Lbl("LIBYA", 17f, 27f),
        Lbl("NIGERIA", 8f, 9f), Lbl("DR CONGO", 23f, -3f), Lbl("ETHIOPIA", 40f, 8f), Lbl("SOUTH AFRICA", 25f, -29f), Lbl("INDONESIA", 115f, -2f), Lbl("JAPAN", 138f, 37f),
        Lbl("FRANCE", 2f, 46.5f), Lbl("GERMANY", 10f, 51f), Lbl("SPAIN", -3.5f, 40f), Lbl("TURKEY", 35f, 39f), Lbl("PAKISTAN", 70f, 30f), Lbl("MONGOLIA", 103f, 46.5f),
        Lbl("GREENLAND", -42f, 74f), Lbl("SUDAN", 30f, 15f), Lbl("TANZANIA", 35f, -6f), Lbl("ANGOLA", 17f, -12f), Lbl("AFGHANISTAN", 66f, 34f), Lbl("THAILAND", 101f, 15f),
        Lbl("ITALY", 12.5f, 42.5f), Lbl("UK", -2f, 54f), Lbl("MALI", -2f, 17f), Lbl("NIGER", 9f, 17f), Lbl("CHAD", 18f, 15f), Lbl("BOLIVIA", -64f, -17f), Lbl("CHILE", -71f, -33f),
        Lbl("MYANMAR", 96f, 21f), Lbl("VIETNAM", 106f, 16f), Lbl("PHILIPPINES", 122f, 12f), Lbl("POLAND", 19f, 52f), Lbl("UKRAINE", 31f, 49f), Lbl("NORWAY", 9f, 62f), Lbl("SWEDEN", 16f, 62f)
    )

    init {
        for (py in 0 until RES) for (px in 0 until RES) {
            val i = py * RES + px
            val x = ((px + 0.5f) * 2f / RES - 1f) / R; val y = (1f - (py + 0.5f) * 2f / RES) / R
            val d2 = x * x + y * y
            vx[i] = x; vy[i] = y; rr[i] = sqrt(d2)
            vz[i] = if (d2 <= 1f) sqrt(1f - d2) else -1f
        }
        val r = java.util.Random(3)
        for (i in sx.indices) { sx[i] = r.nextFloat(); sy[i] = r.nextFloat(); ss[i] = 0.6f + r.nextFloat() * 1.6f; sph[i] = r.nextFloat() * 6.28f }
    }

    fun locate(c: City) { tLon = c.lon; tLat = (c.lat * 0.55).coerceIn(-45.0, 45.0); lastTouch = SystemClock.uptimeMillis() }

    private class FP(val ex: Float, val ey: Float, val nx: Float, val ny: Float, val nz: Float, val cx: Float, val cy: Float, val cz: Float,
                     val sx: Float, val sy: Float, val sz: Float, val svx: Float, val svy: Float, val svl: Float,
                     val hx: Float, val hy: Float, val hz: Float, val hInv: Float, val cloudShift: Int)

    fun startLoop() {
        if (running) return
        running = true
        Planet.ensure()
        thread = Thread {
            var last = SystemClock.uptimeMillis()
            while (running) {
                val now = SystemClock.uptimeMillis(); val dt = (now - last) / 1000.0; last = now
                val tl = tLon; val tt = tLat
                if (!tl.isNaN()) {
                    val d = ((tl - lon0 + 540.0) % 360.0) - 180.0
                    lon0 += d * min(1.0, dt * 4.0)
                    if (!tt.isNaN()) lat0 += (tt - lat0) * min(1.0, dt * 4.0)
                    if (abs(d) < 0.25) { tLon = Double.NaN; tLat = Double.NaN }
                } else if (selected == null && now - lastTouch > 2500L) lon0 -= 5.0 * dt
                if (lon0 < -540.0) lon0 += 360.0
                if (Planet.ready) {
                    renderFrame()
                    back.setPixels(pixels, 0, RES, 0, 0, RES, RES)
                    synchronized(lock) { val t = front; front = back; back = t }
                    postInvalidateOnAnimation()
                } else { postInvalidateOnAnimation(); try { Thread.sleep(80) } catch (e: InterruptedException) { } }
                val spent = SystemClock.uptimeMillis() - now
                if (spent < 30) try { Thread.sleep(30 - spent) } catch (e: InterruptedException) { }
            }
        }.also { it.priority = Thread.NORM_PRIORITY - 1; it.start() }
    }
    fun stopLoop() { running = false; thread?.interrupt(); thread = null }
    override fun onDetachedFromWindow() { stopLoop(); super.onDetachedFromWindow() }

    private fun renderFrame() {
        val now = Tt.now()
        val s = Sun.position(now)
        val d2r = (PI / 180).toFloat()
        val pl = lat0.toFloat() * d2r; val pL = lon0.toFloat() * d2r
        val cl = cos(pl); val sl = sin(pl); val cL = cos(pL); val sL = sin(pL)
        val cx = cl * cL; val cy = cl * sL; val cz = sl
        val ex = -sL; val ey = cL
        val nx = -sl * cL; val ny = -sl * sL; val nz = cl
        val sp = s[1].toFloat() * d2r; val sq = s[0].toFloat() * d2r
        val sxx = cos(sp) * cos(sq); val syy = cos(sp) * sin(sq); val szz = sin(sp)
        val svx = sxx * ex + syy * ey; val svy = sxx * nx + syy * ny + szz * nz; val svz = sxx * cx + syy * cy + szz * cz
        vsx = svx; vsy = svy; vsz = svz
        val hx = svx; val hy = svy; val hz = svz + 1f
        val hn = max(1e-6f, sqrt(hx * hx + hy * hy + hz * hz))
        val drift = ((now / 1000.0) * 0.35).toInt()
        val fp = FP(ex, ey, nx, ny, nz, cx, cy, cz, sxx, syy, szz, svx, svy, max(1e-6f, hypot(svx, svy)), hx, hy, hz, 1f / hn, drift)
        val tasks = ArrayList<Callable<Unit>>()
        for (k in 0 until workers) { val y0 = k * RES / workers; val y1 = (k + 1) * RES / workers; tasks.add(Callable { renderRows(y0, y1, fp) }) }
        pool.invokeAll(tasks)
    }

    private fun sm3(e0: Float, e1: Float, x: Float): Float { val t = ((x - e0) / (e1 - e0)).coerceIn(0f, 1f); return t * t * (3f - 2f * t) }

    private fun renderRows(y0: Int, y1: Int, f: FP) {
        val landM = Planet.landM; val day = Planet.day; val lights = Planet.lights; val border = Planet.border; val cloud = Planet.cloud
        val TW = Planet.TW; val TH = Planet.TH
        val inv255 = 1f / 255f
        for (py in y0 until y1) for (px in 0 until RES) {
            val i = py * RES + px
            val z = vz[i]; val x = vx[i]; val y = vy[i]
            if (z < 0f) {
                val d = rr[i]
                if (d >= 1.17f) { pixels[i] = 0; continue }
                val t = (1.17f - d) / 0.17f
                val lit = (0.5f + 0.5f * ((x / d) * f.svx + (y / d) * f.svy) / f.svl).coerceIn(0f, 1f)
                val a = (t * t * t * 0.7f * (0.12f + 0.88f * lit) * 255f).toInt().coerceIn(0, 255)
                val warm = (1f - abs(lit - 0.5f) * 3f).coerceIn(0f, 1f)
                val hr = (70f + 170f * warm).toInt(); val hg = (150f - 40f * warm).toInt(); val hb = (255f - 190f * warm).toInt()
                pixels[i] = (a shl 24) or (hr shl 16) or (hg shl 8) or hb
                continue
            }
            val wx = x * f.ex + y * f.nx + z * f.cx
            val wy = x * f.ey + y * f.ny + z * f.cy
            val wz = y * f.nz + z * f.cz
            val lat = fastAtan2(wz, sqrt(max(0f, 1f - wz * wz)))
            val lon = fastAtan2(wy, wx)
            var ui = ((lon * 0.15915494f + 0.5f) * TW).toInt(); if (ui >= TW) ui = TW - 1 else if (ui < 0) ui = 0
            var vi = ((0.5f - lat * 0.31830987f) * TH).toInt(); if (vi >= TH) vi = TH - 1 else if (vi < 0) vi = 0
            val ti = vi * TW + ui
            val landv = (landM[ti].toInt() and 255) * inv255
            val dc = day[ti]
            var r = ((dc shr 16) and 255).toFloat(); var g = ((dc shr 8) and 255).toFloat(); var b = (dc and 255).toFloat()
            val dl = wx * f.sx + wy * f.sy + wz * f.sz
            val lam = if (dl > 0f) dl else 0f
            val tw = sm3(-0.10f, 0.14f, dl)
            val ci = vi * TW + Math.floorMod(ui + f.cloudShift, TW)
            val cl = (cloud[ci].toInt() and 255) * inv255 * 0.92f
            val bd = (border[ti].toInt() and 255) * inv255
            val li = (lights[ti].toInt() and 255) * inv255
            // ---- day side
            val lit = 0.08f + 1.28f * lam
            var dr = r * lit; var dg = g * lit; var db = b * lit
            dr = dr + (236f - dr) * bd * 0.22f * lam; dg = dg + (226f - dg) * bd * 0.22f * lam; db = db + (200f - db) * bd * 0.22f * lam
            if (landv < 0.6f) {
                val nd = (x * f.hx + y * f.hy + z * f.hz) * f.hInv
                if (nd > 0f) {
                    val n2 = nd * nd; val n4 = n2 * n2; val n8 = n4 * n4; val n16 = n8 * n8; val n32 = n16 * n16; val n64 = n32 * n32
                    val spec = (n64 * n32 * 1.1f + n8 * 0.10f) * (1f - cl) * (1f - landv)
                    dr += 255f * spec; dg += 245f * spec; db += 225f * spec
                }
                val fres = (1f - z); val fr3 = fres * fres * fres * 0.45f * lam
                dr += 60f * fr3; dg += 100f * fr3; db += 150f * fr3
            }
            val cb = 0.12f + 1.02f * lam
            val warm = exp(-dl * dl * 60f)
            val cr = min(255f, 250f * cb + 120f * warm); val cg = min(255f, 252f * cb + 50f * warm); val cbb = min(255f, 255f * cb)
            dr = dr + (cr - dr) * cl; dg = dg + (cg - dg) * cl; db = db + (cbb - db) * cl
            // ---- night side
            var nr = 3f + 9f * landv; var ng = 6f + 13f * landv; var nb = 17f + 22f * landv
            nr += 45f * bd; ng += 135f * bd; nb += 235f * bd
            val lv = li * (1f - 0.85f * cl)
            nr += 255f * lv * 1.15f; ng += 188f * lv * 1.1f; nb += 92f * lv
            nr += 12f * cl; ng += 16f * cl; nb += 28f * cl
            r = nr + (dr - nr) * tw; g = ng + (dg - ng) * tw; b = nb + (db - nb) * tw
            // ---- atmosphere
            val fr = 1f - z; val f3 = fr * fr * fr; val f6 = f3 * f3
            val dayAtm = f3 * 1.05f * tw
            r += 60f * dayAtm; g += 135f * dayAtm; b += 255f * dayAtm
            val sunset = exp(-dl * dl * 35f) * f3
            r += 255f * 0.95f * sunset; g += 100f * sunset; b += 35f * sunset
            val nightAtm = f3 * 0.4f * (1f - tw)
            r += 12f * nightAtm; g += 32f * nightAtm; b += 90f * nightAtm
            val limb = f6 * tw * 0.8f
            r += 110f * limb; g += 170f * limb; b += 255f * limb
            val rim = rr[i]
            val a = if (rim > 0.985f) ((1f - rim) / 0.015f * 255f).toInt().coerceIn(0, 255) else 255
            pixels[i] = (a shl 24) or (r.toInt().coerceIn(0, 255) shl 16) or (g.toInt().coerceIn(0, 255) shl 8) or b.toInt().coerceIn(0, 255)
        }
    }

    private fun proj(lat: Double, lon: Double, out: FloatArray): Boolean {
        val d2r = PI / 180
        val pl = lat0 * d2r; val pL = lon0 * d2r
        val cl = cos(pl); val sl = sin(pl); val cL = cos(pL); val sL = sin(pL)
        val la = lat * d2r; val lo = lon * d2r
        val wx = cos(la) * cos(lo); val wy = cos(la) * sin(lo); val wz = sin(la)
        val z = wx * cl * cL + wy * cl * sL + wz * sl
        val x = wx * -sL + wy * cL
        val y = wx * (-sl * cL) + wy * (-sl * sL) + wz * cl
        out[0] = gcx + (x * grad).toFloat(); out[1] = gcy - (y * grad).toFloat(); out[2] = z.toFloat()
        return z > 0.04
    }

    private fun fmtT(ms: Long, tz: TimeZone): String {
        val p = partsFor(tz, ms)
        return hm(p[0], p[1], is24) + (if (is24) "" else " " + ampmOf(p[0]))
    }

    override fun onDraw(c: Canvas) {
        val w = width.toFloat(); val h = height.toFloat()
        val s = min(w, h); val l = (w - s) / 2f; val t = (h - s) / 2f
        gcx = w / 2f; gcy = h / 2f; grad = s / 2f * R
        val tt = SystemClock.uptimeMillis() / 1000f
        // stars
        for (i in sx.indices) {
            fill.color = alphaColor(Color.WHITE, 0.25f + 0.6f * (0.5f + 0.5f * sin(tt * (0.6f + ss[i] * 0.5f) + sph[i])) * 0.8f)
            c.drawCircle(sx[i] * w, sy[i] * h, dp(ss[i] * 0.7f), fill)
        }
        // sun glare in the sun's direction
        val svx = vsx; val svy = vsy; val svz = vsz
        val sl2 = max(1e-4f, hypot(svx, svy))
        val gx = gcx + svx / sl2 * grad * 1.28f; val gy = gcy - svy / sl2 * grad * 1.28f
        val ga = (0.55f * (1f - abs(svz) * 0.8f)).coerceIn(0.12f, 0.6f)
        fill.shader = RadialGradient(gx, gy, grad * 0.9f, intArrayOf(alphaColor(0xFFFFE2A8.toInt(), ga), alphaColor(0xFFFF9F43.toInt(), ga * 0.25f), 0), floatArrayOf(0f, 0.35f, 1f), Shader.TileMode.CLAMP)
        c.drawCircle(gx, gy, grad * 0.9f, fill); fill.shader = null
        // moon
        val ma = tt * 0.12f
        val mx = gcx + cos(ma) * grad * 1.06f; val my = gcy + sin(ma) * grad * 1.06f * 0.92f
        fill.shader = RadialGradient(mx - dp(3), my - dp(3), dp(12), intArrayOf(0xFFF4F1EA.toInt(), 0xFFB8B4AC.toInt(), 0xFF6F6C68.toInt()), floatArrayOf(0f, 0.6f, 1f), Shader.TileMode.CLAMP)
        c.drawCircle(mx, my, dp(8.5f), fill); fill.shader = null
        if (!Planet.ready) {
            ring.color = alphaColor(C.CYAN, 0.25f + 0.2f * sin(tt * 4f)); ring.strokeWidth = dp(2)
            c.drawCircle(gcx, gcy, grad, ring)
            lblP.textSize = dp(12); lblP.color = C.DIM; c.drawText("Preparing planet\u2026", gcx, gcy, lblP); lblP.textSize = dp(9.5f)
            return
        }
        dst.set(l, t, l + s, t + s)
        synchronized(lock) { c.drawBitmap(front, null, dst, bmpPaint) }
        pins.clear()
        // country labels
        for (lb in LABELS) {
            if (!proj(lb.lat.toDouble(), lb.lon.toDouble(), tmp)) continue
            val z = tmp[2]; if (z < 0.3f) continue
            val a = ((z - 0.3f) / 0.4f).coerceIn(0f, 1f)
            lblP.color = alphaColor(0xFFEAF3FF.toInt(), 0.62f * a); lblP.letterSpacing = 0.12f
            c.drawText(lb.name, tmp[0], tmp[1], lblP)
        }
        // pins
        val pulse = (SystemClock.uptimeMillis() % 1800L) / 1800f
        fun mark(city: City, col: Int, big: Boolean) {
            if (!proj(city.lat, city.lon, tmp)) return
            val a = ((tmp[2] - 0.04f) / 0.2f).coerceIn(0f, 1f); val px = tmp[0]; val py = tmp[1]
            ring.color = alphaColor(col, (1f - pulse) * a); ring.strokeWidth = dp(1.6f)
            c.drawCircle(px, py, dp(3) + pulse * dp(if (big) 15 else 10), ring)
            fill.color = alphaColor(Color.WHITE, a); c.drawCircle(px, py, dp(if (big) 4.8f else 3.6f), fill)
            fill.color = alphaColor(col, a); c.drawCircle(px, py, dp(if (big) 3.3f else 2.4f), fill)
            if (city === selected) { ring.color = alphaColor(Color.WHITE, 0.9f); ring.strokeWidth = dp(1.4f); c.drawCircle(px, py, dp(10), ring) }
            pinP.color = alphaColor(Color.WHITE, 0.9f * a)
            if (a > 0.6f) c.drawText(if (city.name == "Local") "You" else city.name, px + dp(8), py + dp(4), pinP)
            pins.add(Pin(city, px, py))
        }
        for (m in markers) mark(m, C.ORANGE, false)
        local?.let { mark(it, C.CYAN, true) }
        // info card
        selected?.let { drawCard(c, it) }
    }

    private fun drawCard(c: Canvas, city: City) {
        val tz = TimeZone.getTimeZone(city.tz); val now = Tt.now()
        val cw = min(width - dp(20), dp(310)); val ch = dp(118)
        card.set(dp(10), height - ch - dp(8), dp(10) + cw, height - dp(8))
        fill.color = 0xE60B1022.toInt(); c.drawRoundRect(card, dp(24), dp(24), fill)
        ring.color = 0x33FFFFFF; ring.strokeWidth = dp(1); c.drawRoundRect(card, dp(24), dp(24), ring)
        val s = Sun.position(now); val el = Sun.elevation(city.lat, city.lon, s[0], s[1])
        val x = card.left + dp(18)
        c.drawText((if (city.name == "Local") "Your location" else city.name) + "  \u00B7  " + city.country, x, card.top + dp(28), cardTitle)
        val p = partsFor(tz, now)
        cardBig.textSize = dp(32); c.drawText(hm(p[0], p[1], is24) + (if (is24) "" else " " + ampmOf(p[0])), x, card.top + dp(66), cardBig)
        val st = Sun.times(city.lat, city.lon, now)
        val line1 = if (st != null) "\u2191 " + fmtT(st[0], tz) + "    \u2193 " + fmtT(st[1], tz) else (if (el > 0) "Polar day \u2013 sun never sets" else "Polar night \u2013 sun stays down")
        c.drawText(line1, x, card.top + dp(88), cardSm)
        val phase = when { el > 18 -> "Daytime"; el > 0 -> "Golden hour"; el > -6 -> "Twilight"; else -> "Night" }
        c.drawText(phase + "  \u00B7  sun " + (if (el >= 0) "+" else "") + el.toInt() + "\u00B0", x, card.top + dp(107), cardSm)
        fill.color = if (el > 0) C.ORANGE else 0xFFB9B4FF.toInt(); c.drawCircle(card.right - dp(30), card.top + dp(32), dp(10), fill)
        if (el <= 0) { fill.color = 0xFF0B1022.toInt(); c.drawCircle(card.right - dp(25), card.top + dp(28), dp(8.5f), fill) }
    }

    override fun onTouchEvent(e: MotionEvent): Boolean {
        when (e.actionMasked) {
            MotionEvent.ACTION_DOWN -> { parent?.requestDisallowInterceptTouchEvent(true); lx = e.x; ly = e.y; moved = 0f; downT = SystemClock.uptimeMillis(); lastTouch = downT; tLon = Double.NaN; tLat = Double.NaN }
            MotionEvent.ACTION_MOVE -> {
                val k = 160f / (min(width, height) * 0.43f)
                moved += abs(e.x - lx) + abs(e.y - ly)
                lon0 -= (e.x - lx) * k * 0.55; lat0 = (lat0 + (e.y - ly) * k * 0.55).coerceIn(-75.0, 75.0)
                lx = e.x; ly = e.y; lastTouch = SystemClock.uptimeMillis()
            }
            MotionEvent.ACTION_UP -> {
                lastTouch = SystemClock.uptimeMillis()
                if (moved < dp(12) && lastTouch - downT < 350L) {
                    var best: Pin? = null; var bd = dp(30)
                    for (p in pins) { val d = hypot(p.x - e.x, p.y - e.y); if (d < bd) { bd = d; best = p } }
                    if (best != null) { selected = best.city; locate(best.city); thud() } else selected = null
                }
            }
            MotionEvent.ACTION_CANCEL -> lastTouch = SystemClock.uptimeMillis()
        }
        return true
    }
}
