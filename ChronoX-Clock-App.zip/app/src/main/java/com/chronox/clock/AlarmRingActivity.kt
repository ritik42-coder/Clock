package com.chronox.clock

import android.app.Activity
import android.content.*
import android.graphics.*
import android.os.Build
import android.os.Bundle
import android.os.SystemClock
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import androidx.core.content.ContextCompat
import kotlin.math.*

class RingView(ctx: Context, private val type: String, private val label: String, themeIdx: Int, private val hour: Int, private val minute: Int, private val snoozeMin: Int,
               private val onDismiss: () -> Unit, private val onSnooze: () -> Unit) : View(ctx) {
    private val th = themeFor(themeIdx, hour)
    private val fill = fillPaint(); private val ripple = strokePaint(Color.WHITE, dp(2)); private val bellP = fillPaint()
    private val timeP = textPaint(Color.WHITE, dp(96), THIN, Paint.Align.CENTER); private val labP = textPaint(C.TEXT, dp(22), LIGHT, Paint.Align.CENTER)
    private val subP = textPaint(0xCCFFFFFF.toInt(), dp(14), MED, Paint.Align.CENTER)
    private val blobs = Array(3) { fillPaint() }
    private var knob = 0f; private var dragging = false; private var dragDX = 0f; private var done = false
    private var snoozeDown = false
    private val rect = RectF(); private val path = Path()
    private val rr = java.util.Random(5)
    private val pxA = FloatArray(40) { rr.nextFloat() }; private val pyA = FloatArray(40) { rr.nextFloat() }
    private val is24 = android.text.format.DateFormat.is24HourFormat(ctx)

    private fun sliderRect(): RectF { val h = dp(76); val t = height - dp(70) - h; return RectF(dp(28), t, width - dp(28), t + h) }
    private fun snoozeRect(): RectF { val t = sliderRect().top - dp(100); return RectF(width * 0.2f, t, width * 0.8f, t + dp(58)) }
    private fun maxKnob() = sliderRect().width() - dp(76)

    override fun onSizeChanged(w: Int, h: Int, ow: Int, oh: Int) {
        val r = max(w, h) * 0.6f; val cols = intArrayOf(th.c1, th.c2, th.c3)
        for (i in 0 until 3) blobs[i].shader = RadialGradient(0f, 0f, r, intArrayOf(alphaColor(cols[i], 0.55f), alphaColor(cols[i], 0f)), null, Shader.TileMode.CLAMP)
    }

    override fun onDraw(c: Canvas) {
        val w = width.toFloat(); val h = height.toFloat()
        val tt = SystemClock.uptimeMillis() / 1000f
        fill.shader = LinearGradient(0f, 0f, 0f, h, intArrayOf(th.bg, mixColor(th.bg, th.c2, 0.40f + 0.1f * sin(tt * 0.7f)), mixColor(th.bg, th.c1, 0.45f)), floatArrayOf(0f, 0.6f, 1f), Shader.TileMode.CLAMP)
        c.drawRect(0f, 0f, w, h, fill); fill.shader = null
        for (i in 0 until 3) {
            val x = w * (0.5f + 0.45f * sin(tt * (0.35f + i * 0.12f) + i * 2f)); val y = h * (0.45f + 0.4f * cos(tt * (0.3f + i * 0.1f) + i * 1.3f))
            c.save(); c.translate(x, y); c.drawCircle(0f, 0f, max(w, h) * 0.6f, blobs[i]); c.restore()
        }
        val bx = w / 2f; val by = h * 0.20f
        // ripples
        for (k in 0 until 4) {
            val p = ((tt * 0.7f + k / 4f) % 1f)
            ripple.color = alphaColor(th.c1, (1f - p) * 0.55f); ripple.strokeWidth = dp(2.5f) * (1f - p) + 1f
            c.drawCircle(bx, by, dp(40) + p * w * 0.75f, ripple)
        }
        // floating particles
        for (i in 0 until 40) {
            val yy = h - ((tt * (0.025f + (i % 7) * 0.012f) * h + pyA[i] * h) % h)
            val xx = w * pxA[i] + sin(tt * 0.8f + i) * dp(14)
            fill.color = alphaColor(Color.WHITE, 0.08f + 0.22f * ((i % 5) / 5f)); c.drawCircle(xx, yy, dp(1.2f + (i % 4)), fill)
        }
        // live second ring around the time
        val rcy = h * 0.40f; val rR = w * 0.40f
        val secNow = (System.currentTimeMillis() % 60000L) / 60000f
        for (i in 0 until 60) {
            val a = Math.toRadians(i * 6.0 - 90.0); val lit = (i / 60f) <= secNow; val big = i % 5 == 0
            ripple.color = if (lit) alphaColor(th.c1, 0.95f) else 0x22FFFFFF; ripple.strokeWidth = dp(if (big) 3f else 1.8f)
            val r1 = rR - dp(if (big) 14 else 9); val r2 = rR
            c.drawLine(bx + cos(a).toFloat() * r1, rcy + sin(a).toFloat() * r1, bx + cos(a).toFloat() * r2, rcy + sin(a).toFloat() * r2, ripple)
        }
        val ha = Math.toRadians(secNow * 360.0 - 90.0)
        fill.color = alphaColor(th.c1, 0.35f); c.drawCircle(bx + cos(ha).toFloat() * rR, rcy + sin(ha).toFloat() * rR, dp(11), fill)
        fill.color = Color.WHITE; c.drawCircle(bx + cos(ha).toFloat() * rR, rcy + sin(ha).toFloat() * rR, dp(4.5f), fill)
        fill.color = alphaColor(Color.WHITE, 0.10f + 0.04f * sin(tt * 6f)); c.drawCircle(bx, by, dp(66), fill)
        fill.color = alphaColor(Color.WHITE, 0.14f); c.drawCircle(bx, by, dp(52), fill)
        // bell shake (burst then rest)
        val cyc = (tt % 1.4f); val env = if (cyc < 0.8f) 1f - cyc / 0.8f * 0.35f else 0f
        val ang = sin(tt * 38f) * 16f * env
        if (type == "timer") {
            ripple.color = Color.WHITE; ripple.strokeWidth = dp(4f); c.drawCircle(bx, by + dp(4), dp(24), ripple)
            c.drawLine(bx, by - dp(34), bx, by - dp(26), ripple); c.drawLine(bx, by + dp(4), bx + dp(10) * cos(tt * 4f), by + dp(4) - dp(10) * sin(tt * 4f), ripple)
        } else drawBell(c, bx, by + dp(6), dp(86), Color.WHITE, ang, bellP)
        // time
        val now = java.util.Calendar.getInstance()
        val hh = now.get(java.util.Calendar.HOUR_OF_DAY); val mm = now.get(java.util.Calendar.MINUTE)
        val pulse = 1f + 0.015f * sin(tt * 3f)
        c.save(); c.scale(pulse, pulse, bx, h * 0.40f)
        timeP.textSize = min(w * 0.30f, dp(120)); c.drawText(hm(hh, mm, is24), bx, h * 0.43f, timeP)
        c.restore()
        subP.textSize = dp(15)
        c.drawText((if (is24) "" else ampmOf(hh) + "  \u00B7  ") + two(now.get(java.util.Calendar.SECOND)) + " s", bx, h * 0.43f + dp(28), subP)
        c.drawText(if (type == "timer") "Time's up" else label, bx, h * 0.43f + dp(78), labP)
        // snooze pill
        val sr = snoozeRect()
        fill.color = if (snoozeDown) 0x40FFFFFF else 0x26FFFFFF; c.drawRoundRect(sr, dp(29), dp(29), fill)
        ripple.color = 0x55FFFFFF; ripple.strokeWidth = dp(1); c.drawRoundRect(sr, dp(29), dp(29), ripple)
        subP.textSize = dp(17); subP.color = Color.WHITE
        c.drawText(if (type == "timer") "+1 min" else if (snoozeMin > 0) "Snooze $snoozeMin min" else "", sr.centerX(), sr.centerY() + dp(6), subP)
        subP.color = 0xCCFFFFFF.toInt()
        // slider
        val s = sliderRect(); val p = if (maxKnob() > 0) knob / maxKnob() else 0f
        fill.color = 0x26FFFFFF; c.drawRoundRect(s, dp(38), dp(38), fill)
        fill.color = alphaColor(Color.WHITE, 0.25f * p); c.drawRoundRect(s.left, s.top, s.left + dp(76) + knob, s.bottom, dp(38), dp(38), fill)
        val shim = ((tt * 0.8f) % 1.6f) - 0.3f
        labP.textSize = dp(18); labP.color = alphaColor(Color.WHITE, (1f - p * 1.6f).coerceIn(0f, 1f) * 0.9f)
        fill.shader = null
        c.drawText(if (type == "timer") "Slide to stop" else "Slide to dismiss", s.centerX() + dp(34), s.centerY() + dp(6), labP)
        for (k in 0 until 3) {
            val a = (0.2f + 0.8f * max(0f, sin((tt * 3f) - k * 0.7f))) * (1f - p)
            ripple.color = alphaColor(Color.WHITE, a * 0.8f); ripple.strokeWidth = dp(2.4f)
            val x = s.left + dp(96) + knob + k * dp(12) + dp(30); path.reset(); path.moveTo(x, s.centerY() - dp(8)); path.lineTo(x + dp(8), s.centerY()); path.lineTo(x, s.centerY() + dp(8)); c.drawPath(path, ripple)
        }
        labP.textSize = dp(22); labP.color = C.TEXT
        val kx = s.left + dp(4) + knob; fill.color = Color.WHITE
        c.drawCircle(kx + dp(34), s.centerY(), dp(34), fill)
        ripple.color = 0xFF05060D.toInt(); ripple.strokeWidth = dp(3.2f)
        path.reset(); path.moveTo(kx + dp(26), s.centerY() - dp(10)); path.lineTo(kx + dp(40), s.centerY()); path.lineTo(kx + dp(26), s.centerY() + dp(10)); c.drawPath(path, ripple)
        postInvalidateOnAnimation()
    }

    override fun onTouchEvent(e: MotionEvent): Boolean {
        if (done) return true
        val s = sliderRect()
        when (e.actionMasked) {
            MotionEvent.ACTION_DOWN -> {
                if (RectF(s.left + knob, s.top, s.left + knob + dp(80), s.bottom).contains(e.x, e.y)) { dragging = true; dragDX = e.x - knob }
                else if (snoozeRect().contains(e.x, e.y)) snoozeDown = true
            }
            MotionEvent.ACTION_MOVE -> if (dragging) { knob = (e.x - dragDX).coerceIn(0f, maxKnob()); if ((knob / maxKnob() * 10).toInt() != ((knob - 4f) / maxKnob() * 10).toInt()) tick() }
            MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> {
                if (dragging) {
                    dragging = false
                    if (knob > maxKnob() * 0.85f && e.actionMasked == MotionEvent.ACTION_UP) { done = true; animF(knob, maxKnob(), 150L, null, 0L, { onDismiss() }) { knob = it } }
                    else animF(knob, 0f, 350L, android.view.animation.OvershootInterpolator(1.5f)) { knob = it }
                }
                if (snoozeDown) { snoozeDown = false; if (e.actionMasked == MotionEvent.ACTION_UP && snoozeRect().contains(e.x, e.y) && (type == "timer" || snoozeMin > 0)) { done = true; thud(); onSnooze() } }
            }
        }
        return true
    }
}

class AlarmRingActivity : Activity() {
    private val endRcv = object : BroadcastReceiver() { override fun onReceive(c: Context, i: Intent) { finishAndRemoveTask() } }

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        DENSITY = resources.displayMetrics.density
        if (Build.VERSION.SDK_INT >= 27) { setShowWhenLocked(true); setTurnScreenOn(true) }
        else window.addFlags(WindowManager.LayoutParams.FLAG_SHOW_WHEN_LOCKED or WindowManager.LayoutParams.FLAG_TURN_SCREEN_ON or WindowManager.LayoutParams.FLAG_DISMISS_KEYGUARD)
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        androidx.core.view.WindowCompat.setDecorFitsSystemWindows(window, false)
        ContextCompat.registerReceiver(this, endRcv, IntentFilter(AlarmService.ACTION_RING_END), ContextCompat.RECEIVER_NOT_EXPORTED)
        build(intent)
    }
    override fun onNewIntent(i: Intent) { super.onNewIntent(i); setIntent(i); build(i) }

    private fun build(i: Intent) {
        val type = i.getStringExtra("type") ?: "alarm"
        val v = RingView(this, type, i.getStringExtra("label") ?: "Alarm", i.getIntExtra("theme", 6), i.getIntExtra("hour", 7), i.getIntExtra("minute", 0), i.getIntExtra("snooze", 5),
            { startService(Intent(this, AlarmService::class.java).setAction(AlarmService.ACTION_STOP)); finishAndRemoveTask() },
            { startService(Intent(this, AlarmService::class.java).setAction(AlarmService.ACTION_SNOOZE)); finishAndRemoveTask() })
        setContentView(v)
        v.alpha = 0f; v.scaleX = 1.08f; v.scaleY = 1.08f; v.animate().alpha(1f).scaleX(1f).scaleY(1f).setDuration(600).start()
    }
    override fun onDestroy() { try { unregisterReceiver(endRcv) } catch (e: Exception) { }; super.onDestroy() }
    @Suppress("OVERRIDE_DEPRECATION") override fun onBackPressed() { /* must slide to dismiss */ }
}
