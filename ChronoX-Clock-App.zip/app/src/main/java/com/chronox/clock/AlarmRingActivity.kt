package com.chronox.clock

import android.Manifest
import android.app.Activity
import android.content.*
import android.content.pm.PackageManager
import android.graphics.*
import android.os.Build
import android.os.Bundle
import android.os.SystemClock
import android.view.MotionEvent
import android.view.View
import android.view.ViewGroup
import android.view.WindowManager
import android.widget.FrameLayout
import android.widget.Toast
import androidx.core.content.ContextCompat
import java.util.Calendar
import java.util.TimeZone
import kotlin.math.*

class RingCfg(var type: String = "alarm", var label: String = "Alarm", var theme: Int = 6, var hour: Int = 7, var minute: Int = 0,
              var snooze: Int = 5, var style: Int = 0, var stop: Int = 0, var level: Int = 1, var qr: String = "", var preview: Boolean = false)

fun launchRingPreview(ctx: Context, cfg: RingCfg) {
    ctx.startActivity(Intent(ctx, AlarmRingActivity::class.java).putExtra("preview", true)
        .putExtra("type", cfg.type).putExtra("label", cfg.label).putExtra("theme", cfg.theme).putExtra("hour", cfg.hour).putExtra("minute", cfg.minute)
        .putExtra("snooze", cfg.snooze).putExtra("style", cfg.style).putExtra("stop", cfg.stop).putExtra("level", cfg.level).putExtra("qr", cfg.qr))
}

class RingView(ctx: Context, var cfg: RingCfg, private val onDismiss: () -> Unit, private val onSnooze: () -> Unit, private val onChallenge: (Int) -> Unit) : View(ctx) {
    private var th = themeFor(cfg.theme, cfg.hour)
    private val fill = fillPaint(); private val ripple = strokePaint(Color.WHITE, dp(2)).apply { strokeCap = Paint.Cap.ROUND }; private val bellP = fillPaint()
    private val timeP = textPaint(Color.WHITE, dp(96), THIN, Paint.Align.CENTER); private val labP = textPaint(C.TEXT, dp(22), LIGHT, Paint.Align.CENTER)
    private val subP = textPaint(0xCCFFFFFF.toInt(), dp(14), MED, Paint.Align.CENTER)
    private val rainP = textPaint(C.CYAN, dp(14), REG, Paint.Align.CENTER)
    private val rect = RectF(); private val path = Path()
    private var knob = 0f; private var dragging = false; private var dragDX = 0f; private var done = false
    private var snoozeDown = false; private var pillDown = false
    private var holding = false; private var holdP = 0f; private var lastT = 0L
    private var vw = 0f; private var vh = 0f
    private val is24 = android.text.format.DateFormat.is24HourFormat(ctx)
    private val rr = java.util.Random(5)
    private val pxA = FloatArray(60) { rr.nextFloat() }; private val pyA = FloatArray(60) { rr.nextFloat() }
    private val glyphs = "01ABCDEF<>/|+*#".map { it.toString() }
    private val tz = TimeZone.getDefault()

    private fun stopM(): Int = if (cfg.type == "timer") 0 else cfg.stop.coerceIn(0, 5)
    private fun sliderRect() = RectF(dp(28), vh - dp(70) - dp(76), vw - dp(28), vh - dp(70))
    private fun snoozeRect(): RectF { val t = vh - dp(70) - dp(76) - dp(100); return RectF(vw * 0.2f, t, vw * 0.8f, t + dp(58)) }
    private fun maxKnob() = sliderRect().width() - dp(76)
    private fun holdSec() = floatArrayOf(2f, 3.5f, 5f)[cfg.level.coerceIn(0, 2)]
    private fun bellEnv(tt: Float): Float { val cyc = tt % 1.4f; return if (cyc < 0.8f) 1f - cyc / 0.8f * 0.35f else 0f }

    override fun onDraw(c: Canvas) {
        val pv = cfg.preview
        vw = if (pv) 360f * DENSITY else width.toFloat(); vh = if (pv) 760f * DENSITY else height.toFloat()
        val now = SystemClock.uptimeMillis()
        val dt = if (lastT == 0L) 0f else ((now - lastT) / 1000f).coerceAtMost(0.1f); lastT = now
        val tt = now / 1000f
        th = themeFor(cfg.theme, cfg.hour)
        c.save()
        if (pv) { val sc = min(width / vw, height / vh); c.translate((width - vw * sc) / 2f, (height - vh * sc) / 2f); c.scale(sc, sc); c.clipRect(0f, 0f, vw, vh) }
        when (cfg.style) { 1 -> orbit(c, tt); 2 -> pulse(c, tt); 3 -> sunrise(c, tt); 4 -> cyber(c, tt); 5 -> minimal(c, tt); else -> aurora(c, tt) }
        timeBlock(c, tt)
        controls(c, tt, dt)
        c.restore()
        postInvalidateOnAnimation()
    }

    // ------------------------------------------------------------------ backgrounds
    private fun gradientBg(c: Canvas, k: Float) {
        fill.shader = LinearGradient(0f, 0f, 0f, vh, intArrayOf(th.bg, mixColor(th.bg, th.c2, k), mixColor(th.bg, th.c1, k * 0.7f)), floatArrayOf(0f, 0.6f, 1f), Shader.TileMode.CLAMP)
        c.drawRect(0f, 0f, vw, vh, fill); fill.shader = null
    }

    private fun aurora(c: Canvas, tt: Float) {
        fill.shader = LinearGradient(0f, 0f, 0f, vh, intArrayOf(th.bg, mixColor(th.bg, th.c2, 0.40f + 0.1f * sin(tt * 0.7f)), mixColor(th.bg, th.c1, 0.45f)), floatArrayOf(0f, 0.6f, 1f), Shader.TileMode.CLAMP)
        c.drawRect(0f, 0f, vw, vh, fill); fill.shader = null
        val cols = intArrayOf(th.c1, th.c2, th.c3); val rad = max(vw, vh) * 0.6f
        for (i in 0 until 3) {
            val x = vw * (0.5f + 0.45f * sin(tt * (0.35f + i * 0.12f) + i * 2f)); val y = vh * (0.45f + 0.4f * cos(tt * (0.3f + i * 0.1f) + i * 1.3f))
            fill.shader = RadialGradient(x, y, rad, intArrayOf(alphaColor(cols[i], 0.5f), 0), null, Shader.TileMode.CLAMP)
            c.drawCircle(x, y, rad, fill)
        }
        fill.shader = null
        val bx = vw / 2f; val by = vh * 0.20f
        for (k in 0 until 4) {
            val p = ((tt * 0.7f + k / 4f) % 1f)
            ripple.color = alphaColor(th.c1, (1f - p) * 0.55f); ripple.strokeWidth = dp(2.5f) * (1f - p) + 1f
            c.drawCircle(bx, by, dp(40) + p * vw * 0.75f, ripple)
        }
        for (i in 0 until 40) {
            val yy = vh - ((tt * (0.025f + (i % 7) * 0.012f) * vh + pyA[i] * vh) % vh)
            val xx = vw * pxA[i] + sin(tt * 0.8f + i) * dp(14)
            fill.color = alphaColor(Color.WHITE, 0.08f + 0.22f * ((i % 5) / 5f)); c.drawCircle(xx, yy, dp(1.2f + (i % 4)), fill)
        }
        val rcy = vh * 0.40f; val rR = vw * 0.40f
        val secNow = (System.currentTimeMillis() % 60000L) / 60000f
        for (i in 0 until 60) {
            val a = Math.toRadians(i * 6.0 - 90.0); val lit = (i / 60f) <= secNow; val big = i % 5 == 0
            ripple.color = if (lit) alphaColor(th.c1, 0.95f) else 0x22FFFFFF; ripple.strokeWidth = dp(if (big) 3f else 1.8f)
            val r1 = rR - dp(if (big) 14 else 9)
            c.drawLine(bx + cos(a).toFloat() * r1, rcy + sin(a).toFloat() * r1, bx + cos(a).toFloat() * rR, rcy + sin(a).toFloat() * rR, ripple)
        }
        val ha = Math.toRadians(secNow * 360.0 - 90.0)
        fill.color = alphaColor(th.c1, 0.35f); c.drawCircle(bx + cos(ha).toFloat() * rR, rcy + sin(ha).toFloat() * rR, dp(11), fill)
        fill.color = Color.WHITE; c.drawCircle(bx + cos(ha).toFloat() * rR, rcy + sin(ha).toFloat() * rR, dp(4.5f), fill)
        fill.color = alphaColor(Color.WHITE, 0.10f + 0.04f * sin(tt * 6f)); c.drawCircle(bx, by, dp(66), fill)
        fill.color = alphaColor(Color.WHITE, 0.14f); c.drawCircle(bx, by, dp(52), fill)
        val ang = sin(tt * 38f) * 16f * bellEnv(tt)
        if (cfg.type == "timer") {
            ripple.color = Color.WHITE; ripple.strokeWidth = dp(4f); c.drawCircle(bx, by + dp(4), dp(24), ripple)
            c.drawLine(bx, by - dp(34), bx, by - dp(26), ripple); c.drawLine(bx, by + dp(4), bx + dp(10) * cos(tt * 4f), by + dp(4) - dp(10) * sin(tt * 4f), ripple)
        } else drawBell(c, bx, by + dp(6), dp(86), Color.WHITE, ang, bellP)
    }

    private fun orbit(c: Canvas, tt: Float) {
        gradientBg(c, 0.30f)
        for (i in 0 until 50) { fill.color = alphaColor(Color.WHITE, 0.15f + 0.5f * (0.5f + 0.5f * sin(tt * 1.6f + i))); c.drawCircle(pxA[i] * vw, pyA[i] * vh, dp(1.2f), fill) }
        val cx = vw / 2f; val cy = vh * 0.28f; val R = vw * 0.27f
        fill.shader = RadialGradient(cx, cy, R * 1.9f, intArrayOf(alphaColor(th.c1, 0.30f), alphaColor(th.c2, 0.10f), 0), floatArrayOf(0f, 0.5f, 1f), Shader.TileMode.CLAMP)
        c.drawCircle(cx, cy, R * 1.9f, fill); fill.shader = null
        val rads = floatArrayOf(1.28f, 1.55f, 1.85f); val spd = floatArrayOf(0.55f, -0.38f, 0.26f); val cols = intArrayOf(th.c1, th.c2, th.c3)
        for (k in 0..2) {
            ripple.color = 0x22FFFFFF; ripple.strokeWidth = dp(1.2f); c.drawCircle(cx, cy, R * rads[k], ripple)
            for (j in 0 until 9) {
                val a = tt * spd[k] + k * 2.1f - j * 0.07f * sign(spd[k])
                fill.color = alphaColor(cols[k], (1f - j / 9f) * 0.8f)
                c.drawCircle(cx + cos(a) * R * rads[k], cy + sin(a) * R * rads[k], dp(5f - j * 0.4f), fill)
            }
        }
        drawAnalog(c, cx, cy, R, tz, th.c1, true)
    }

    private fun pulse(c: Canvas, tt: Float) {
        gradientBg(c, 0.4f)
        val cx = vw / 2f; val cy = vh * 0.32f; val r0 = vw * 0.19f; val n = 56
        for (i in 0 until n) {
            val a = i * 6.2832f / n - 1.5708f
            val amp = abs(sin(tt * 2.2f + i * 0.45f) * cos(tt * 1.3f + i * 0.21f))
            val len = dp(10) + dp(46) * amp
            ripple.color = mixColor(th.c1, th.c3, i / (n - 1f)); ripple.strokeWidth = dp(4.5f)
            c.drawLine(cx + cos(a) * (r0 + dp(8)), cy + sin(a) * (r0 + dp(8)), cx + cos(a) * (r0 + dp(8) + len), cy + sin(a) * (r0 + dp(8) + len), ripple)
        }
        fill.color = alphaColor(Color.WHITE, 0.10f + 0.05f * sin(tt * 5f)); c.drawCircle(cx, cy, r0, fill)
        if (cfg.type == "timer") { ripple.color = Color.WHITE; ripple.strokeWidth = dp(4f); c.drawCircle(cx, cy, dp(22), ripple) }
        else drawBell(c, cx, cy + dp(4), dp(52), Color.WHITE, sin(tt * 38f) * 10f * bellEnv(tt), bellP)
    }

    private fun hills(c: Canvas, baseY: Float, amp: Float, freq: Float, color: Int, ph: Float) {
        path.reset(); path.moveTo(0f, vh); path.lineTo(0f, baseY)
        var x = 0f
        while (x <= vw) { path.lineTo(x, baseY + sin(x / vw * 6.2832f * freq + ph) * amp + sin(x / vw * 17f + ph) * amp * 0.25f); x += dp(8) }
        path.lineTo(vw, baseY); path.lineTo(vw, vh); path.close(); fill.color = color; c.drawPath(path, fill)
    }
    private fun sunrise(c: Canvas, tt: Float) {
        val sp = 0.5f + 0.5f * sin(tt * 0.22f - 1.2f); val hz = vh * 0.52f
        val top = mixColor(0xFF070B22.toInt(), mixColor(th.bg, th.c2, 0.5f), sp)
        val mid = mixColor(th.bg, th.c2, 0.4f + 0.4f * sp); val bot = mixColor(th.c2, th.c1, sp)
        fill.shader = LinearGradient(0f, 0f, 0f, hz, intArrayOf(top, mid, bot), floatArrayOf(0f, 0.55f, 1f), Shader.TileMode.CLAMP)
        c.drawRect(0f, 0f, vw, vh, fill); fill.shader = null
        for (i in 0 until 50) { fill.color = alphaColor(Color.WHITE, (1f - sp) * (0.2f + 0.6f * (0.5f + 0.5f * sin(tt * 2f + i)))); c.drawCircle(pxA[i] * vw, pyA[i] * hz * 0.8f, dp(1.3f), fill) }
        val sx = vw / 2f; val sy = hz + dp(40) - sp * (vh * 0.27f); val sr = dp(48)
        fill.shader = RadialGradient(sx, sy, sr * 4.2f, intArrayOf(alphaColor(th.c3, 0.55f), alphaColor(th.c1, 0.15f), 0), floatArrayOf(0f, 0.4f, 1f), Shader.TileMode.CLAMP)
        c.drawCircle(sx, sy, sr * 4.2f, fill); fill.shader = null
        for (k in 0 until 14) {
            val a = tt * 0.2f + k * 0.449f; val e = sr * (2.3f + 0.4f * sin(tt * 2f + k))
            ripple.color = alphaColor(th.c3, 0.25f); ripple.strokeWidth = dp(2)
            c.drawLine(sx + cos(a) * sr * 1.4f, sy + sin(a) * sr * 1.4f, sx + cos(a) * e, sy + sin(a) * e, ripple)
        }
        fill.color = 0xFFFFF1C2.toInt(); c.drawCircle(sx, sy, sr, fill)
        hills(c, hz + dp(10), dp(26), 0.9f, mixColor(th.bg, th.c2, 0.18f), 0f)
        hills(c, hz + dp(70), dp(34), 1.4f, mixColor(th.bg, 0xFF000000.toInt(), 0.45f), 1.7f)
    }

    private fun cyber(c: Canvas, tt: Float) {
        c.drawColor(mixColor(0xFF02030A.toInt(), th.bg, 0.6f))
        val cw = dp(17); val cols = (vw / cw).toInt() + 1
        for (i in 0 until cols) {
            val sp = dp(60) + ((i * 37) % 70) * dp(2); val len = 12 + (i * 13) % 10
            val head = (tt * sp + i * 131f) % (vh + len * dp(16))
            for (k in 0 until len) {
                val y = head - k * dp(16); if (y < -dp(16) || y > vh) continue
                val idx = ((tt * 7f).toInt() + i * 5 + k * 3) % glyphs.size
                rainP.color = if (k == 0) Color.WHITE else alphaColor(th.c1, (1f - k / len.toFloat()) * 0.8f)
                c.drawText(glyphs[idx], i * cw + cw / 2f, y, rainP)
            }
        }
        val gy = vh * 0.80f
        for (r in 0 until 8) { val p = ((r + (tt * 0.8f) % 1f) / 8f); val y = gy + (vh - gy) * p * p; ripple.color = alphaColor(th.c2, 0.5f * p); ripple.strokeWidth = dp(1.4f); c.drawLine(0f, y, vw, y, ripple) }
        for (k in -8..8) { ripple.color = alphaColor(th.c2, 0.35f); ripple.strokeWidth = dp(1.2f); c.drawLine(vw / 2f + k * dp(8), gy, vw / 2f + k * dp(90), vh, ripple) }
    }

    private fun minimal(c: Canvas, tt: Float) {
        c.drawColor(0xFF000000.toInt())
        val cx = vw / 2f; val cy = vh * 0.40f
        fill.shader = RadialGradient(cx, cy, vw * 0.8f, intArrayOf(alphaColor(th.c1, 0.10f + 0.07f * sin(tt * 1.6f)), 0), null, Shader.TileMode.CLAMP)
        c.drawCircle(cx, cy, vw * 0.8f, fill); fill.shader = null
        val secNow = (System.currentTimeMillis() % 60000L) / 60000f
        for (i in 0 until 60) {
            val a = Math.toRadians(i * 6.0 - 90.0); val lit = i / 60f <= secNow
            fill.color = if (lit) th.c1 else 0x26FFFFFF
            c.drawCircle(cx + cos(a).toFloat() * vw * 0.42f, cy + sin(a).toFloat() * vw * 0.42f, dp(if (i % 5 == 0) 3.2f else 1.8f), fill)
        }
    }

    // ------------------------------------------------------------------ time + label
    private fun timeBlock(c: Canvas, tt: Float) {
        val cx = vw / 2f; val st = cfg.style
        val y = when (st) { 1 -> 0.60f; 2 -> 0.60f; 3 -> 0.66f; 4 -> 0.50f; 5 -> 0.45f; else -> 0.43f } * vh
        val size = when (st) { 1 -> dp(84); 2 -> dp(90); 3 -> dp(88); 4 -> dp(92); 5 -> dp(128); else -> min(vw * 0.30f, dp(120)) }
        val cal = Calendar.getInstance()
        val hh = cal.get(Calendar.HOUR_OF_DAY); val mm = cal.get(Calendar.MINUTE)
        val ts = hm(hh, mm, is24)
        timeP.textSize = size
        if (st == 4) { rect.set(cx - size * 1.45f, y - size * 0.95f, cx + size * 1.45f, y + size * 1.35f); fill.color = 0x99000000.toInt(); c.drawRoundRect(rect, dp(24), dp(24), fill) }
        val pulseK = 1f + (if (st == 5) 0.03f else 0.015f) * sin(tt * 3f)
        c.save(); c.scale(pulseK, pulseK, cx, y - size * 0.35f)
        if (st == 4) {
            val jit = if (((tt * 10f).toInt() % 17) == 0) dp(4) else dp(1)
            timeP.color = alphaColor(th.c3, 0.9f); c.drawText(ts, cx - jit, y, timeP)
            timeP.color = alphaColor(th.c1, 0.9f); c.drawText(ts, cx + jit, y, timeP)
        }
        timeP.color = Color.WHITE; c.drawText(ts, cx, y, timeP)
        c.restore()
        subP.textSize = dp(15)
        c.drawText((if (is24) "" else ampmOf(hh) + "  \u00B7  ") + two(cal.get(Calendar.SECOND)) + " s", cx, y + dp(30), subP)
        labP.textSize = dp(22); labP.color = C.TEXT
        c.drawText(if (cfg.type == "timer") "Time's up" else (if (cfg.label.isBlank()) "Alarm" else cfg.label), cx, y + dp(80), labP)
    }

    // ------------------------------------------------------------------ controls
    private fun controls(c: Canvas, tt: Float, dt: Float) {
        if (cfg.type == "timer" || cfg.snooze > 0) {
            val sr = snoozeRect()
            fill.color = if (snoozeDown) 0x40FFFFFF else 0x26FFFFFF; c.drawRoundRect(sr, dp(29), dp(29), fill)
            ripple.color = 0x55FFFFFF; ripple.strokeWidth = dp(1); c.drawRoundRect(sr, dp(29), dp(29), ripple)
            subP.textSize = dp(17); subP.color = Color.WHITE
            c.drawText(if (cfg.type == "timer") "+1 min" else "Snooze ${cfg.snooze} min", sr.centerX(), sr.centerY() + dp(6), subP)
            subP.color = 0xCCFFFFFF.toInt()
        }
        val sm = stopM(); val s = sliderRect()
        when (sm) {
            0 -> {
                if (cfg.preview) knob = (0.5f + 0.5f * sin(tt * 1.4f)) * maxKnob() * 0.55f
                val p = if (maxKnob() > 0) knob / maxKnob() else 0f
                fill.color = 0x26FFFFFF; c.drawRoundRect(s, dp(38), dp(38), fill)
                fill.color = alphaColor(Color.WHITE, 0.25f * p); c.drawRoundRect(s.left, s.top, s.left + dp(76) + knob, s.bottom, dp(38), dp(38), fill)
                labP.textSize = dp(18); labP.color = alphaColor(Color.WHITE, (1f - p * 1.6f).coerceIn(0f, 1f) * 0.9f)
                c.drawText(if (cfg.type == "timer") "Slide to stop" else "Slide to dismiss", s.centerX() + dp(34), s.centerY() + dp(6), labP)
                for (k in 0 until 3) {
                    val a = (0.2f + 0.8f * max(0f, sin((tt * 3f) - k * 0.7f))) * (1f - p)
                    ripple.color = alphaColor(Color.WHITE, a * 0.8f); ripple.strokeWidth = dp(2.4f)
                    val x = s.left + dp(96) + knob + k * dp(12) + dp(30); path.reset(); path.moveTo(x, s.centerY() - dp(8)); path.lineTo(x + dp(8), s.centerY()); path.lineTo(x, s.centerY() + dp(8)); c.drawPath(path, ripple)
                }
                val kx = s.left + dp(4) + knob; fill.color = Color.WHITE
                c.drawCircle(kx + dp(34), s.centerY(), dp(34), fill)
                ripple.color = 0xFF05060D.toInt(); ripple.strokeWidth = dp(3.2f)
                path.reset(); path.moveTo(kx + dp(26), s.centerY() - dp(10)); path.lineTo(kx + dp(40), s.centerY()); path.lineTo(kx + dp(26), s.centerY() + dp(10)); c.drawPath(path, ripple)
            }
            1 -> {
                if (!cfg.preview) {
                    if (holding) holdP += dt / holdSec() else holdP = max(0f, holdP - dt * 1.6f)
                    if (holdP >= 1f && !done) { done = true; onDismiss() }
                } else holdP = 0.5f + 0.5f * sin(tt * 1.2f)
                val cx = vw / 2f; val cy = s.centerY(); val r = dp(46)
                if (holding) for (k in 0 until 3) { val p = ((tt * 1.2f + k / 3f) % 1f); ripple.color = alphaColor(Color.WHITE, (1f - p) * 0.4f); ripple.strokeWidth = dp(2); c.drawCircle(cx, cy, r + p * dp(46), ripple) }
                fill.color = if (holding) 0x40FFFFFF else 0x26FFFFFF; c.drawCircle(cx, cy, r * (if (holding) 1.06f else 1f), fill)
                ripple.color = 0x33FFFFFF; ripple.strokeWidth = dp(7); c.drawCircle(cx, cy, r, ripple)
                rect.set(cx - r, cy - r, cx + r, cy + r)
                ripple.shader = SweepGradient(cx, cy, intArrayOf(th.c1, th.c3, th.c1), null).also { sg -> val mm = Matrix(); mm.postRotate(-90f, cx, cy); sg.setLocalMatrix(mm) }
                ripple.strokeWidth = dp(7); c.drawArc(rect, -90f, 360f * holdP.coerceIn(0f, 1f), false, ripple); ripple.shader = null
                subP.textSize = dp(15); subP.color = Color.WHITE
                c.drawText("HOLD", cx, cy + dp(5), subP); subP.color = 0xCCFFFFFF.toInt()
                c.drawText("Hold to stop", cx, s.top - dp(8), subP)
            }
            else -> {
                val k = 1f + 0.025f * sin(tt * 4f)
                c.save(); c.scale(k, k, s.centerX(), s.centerY())
                fill.shader = LinearGradient(s.left, 0f, s.right, 0f, intArrayOf(alphaColor(th.c1, 0.55f), alphaColor(th.c2, 0.55f)), null, Shader.TileMode.CLAMP)
                c.drawRoundRect(s, dp(38), dp(38), fill); fill.shader = null
                ripple.color = 0x66FFFFFF; ripple.strokeWidth = dp(1.4f); c.drawRoundRect(s, dp(38), dp(38), ripple)
                labP.textSize = dp(19); labP.color = Color.WHITE
                c.drawText(STOP_PROMPTS[sm], s.centerX(), s.centerY() + dp(7), labP)
                c.restore()
            }
        }
        labP.textSize = dp(22); labP.color = C.TEXT
    }

    override fun onTouchEvent(e: MotionEvent): Boolean {
        if (cfg.preview) return super.onTouchEvent(e)
        if (done) return true
        val sm = stopM(); val s = sliderRect()
        when (e.actionMasked) {
            MotionEvent.ACTION_DOWN -> {
                if (snoozeRect().contains(e.x, e.y) && (cfg.type == "timer" || cfg.snooze > 0)) snoozeDown = true
                else when (sm) {
                    0 -> if (RectF(s.left + knob, s.top, s.left + knob + dp(80), s.bottom).contains(e.x, e.y)) { dragging = true; dragDX = e.x - knob }
                    1 -> if (hypot(e.x - vw / 2f, e.y - s.centerY()) < dp(64)) { holding = true; hold() }
                    else -> if (s.contains(e.x, e.y)) pillDown = true
                }
            }
            MotionEvent.ACTION_MOVE -> if (dragging) { knob = (e.x - dragDX).coerceIn(0f, maxKnob()); if ((knob / maxKnob() * 10).toInt() != ((knob - 4f) / maxKnob() * 10).toInt()) tick() }
            MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> {
                holding = false
                if (dragging) {
                    dragging = false
                    if (knob > maxKnob() * 0.85f && e.actionMasked == MotionEvent.ACTION_UP) { done = true; animF(knob, maxKnob(), 150L, null, 0L, { onDismiss() }) { knob = it } }
                    else animF(knob, 0f, 350L, android.view.animation.OvershootInterpolator(1.5f)) { knob = it }
                }
                if (pillDown) { pillDown = false; if (e.actionMasked == MotionEvent.ACTION_UP && s.contains(e.x, e.y)) { thud(); onChallenge(sm) } }
                if (snoozeDown) { snoozeDown = false; if (e.actionMasked == MotionEvent.ACTION_UP && snoozeRect().contains(e.x, e.y)) { done = true; thud(); onSnooze() } }
            }
        }
        return true
    }
}

class AlarmRingActivity : Activity() {
    private lateinit var root: FrameLayout
    private var overlay: View? = null
    private var preview = false
    private var registered = false
    private val endRcv = object : BroadcastReceiver() { override fun onReceive(c: Context, i: Intent) { finishAndRemoveTask() } }

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        DENSITY = resources.displayMetrics.density
        if (Build.VERSION.SDK_INT >= 27) { setShowWhenLocked(true); setTurnScreenOn(true) }
        else window.addFlags(WindowManager.LayoutParams.FLAG_SHOW_WHEN_LOCKED or WindowManager.LayoutParams.FLAG_TURN_SCREEN_ON or WindowManager.LayoutParams.FLAG_DISMISS_KEYGUARD)
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        androidx.core.view.WindowCompat.setDecorFitsSystemWindows(window, false)
        root = FrameLayout(this); setContentView(root)
        preview = intent.getBooleanExtra("preview", false)
        if (!preview) { ContextCompat.registerReceiver(this, endRcv, IntentFilter(AlarmService.ACTION_RING_END), ContextCompat.RECEIVER_NOT_EXPORTED); registered = true }
        build(intent)
    }
    override fun onNewIntent(i: Intent) { super.onNewIntent(i); setIntent(i); preview = i.getBooleanExtra("preview", false); build(i) }

    private fun build(i: Intent) {
        val cfg = RingCfg(i.getStringExtra("type") ?: "alarm", i.getStringExtra("label") ?: "Alarm", i.getIntExtra("theme", 6), i.getIntExtra("hour", 7), i.getIntExtra("minute", 0),
            i.getIntExtra("snooze", 5), i.getIntExtra("style", 0), i.getIntExtra("stop", 0), i.getIntExtra("level", 1), i.getStringExtra("qr") ?: "", false)
        // safety: a QR challenge needs a saved code and camera access, otherwise fall back to sliding
        if (!preview && cfg.stop == 5 && (cfg.qr.isEmpty() || checkSelfPermission(Manifest.permission.CAMERA) != PackageManager.PERMISSION_GRANTED)) cfg.stop = 0
        overlay = null; root.removeAllViews()
        val v = RingView(this, cfg, { stopRing() }, { snoozeRing() }, { k -> openChallenge(k, cfg) })
        root.addView(v, ViewGroup.LayoutParams(-1, -1))
        v.alpha = 0f; v.scaleX = 1.08f; v.scaleY = 1.08f; v.animate().alpha(1f).scaleX(1f).scaleY(1f).setDuration(600).start()
    }

    private fun stopRing() {
        if (!preview) startService(Intent(this, AlarmService::class.java).setAction(AlarmService.ACTION_STOP))
        finishAndRemoveTask()
    }
    private fun snoozeRing() {
        if (!preview) startService(Intent(this, AlarmService::class.java).setAction(AlarmService.ACTION_SNOOZE))
        finishAndRemoveTask()
    }
    private fun solved() {
        if (preview) { closeChallenge(); Toast.makeText(this, "Challenge complete \u2713", Toast.LENGTH_SHORT).show() } else stopRing()
    }
    private fun openChallenge(k: Int, cfg: RingCfg) {
        if (overlay != null) return
        val th = themeFor(cfg.theme, cfg.hour)
        val ov: View = when (k) {
            2 -> MathView(this, th, cfg.level, { solved() }, { closeChallenge() })
            3 -> ShakeView(this, th, cfg.level, { solved() }, { closeChallenge() })
            4 -> StepsView(this, th, cfg.level, { solved() }, { closeChallenge() })
            5 -> QrView(this, th, cfg.qr, "Scan your code to stop", { solved() }, { closeChallenge() })
            else -> return
        }
        overlay = ov; root.addView(ov, ViewGroup.LayoutParams(-1, -1))
        ov.alpha = 0f; ov.translationY = dp(60); ov.animate().alpha(1f).translationY(0f).setDuration(320).start()
    }
    private fun closeChallenge() {
        val v = overlay ?: return; overlay = null
        v.animate().alpha(0f).translationY(dp(60)).setDuration(240).withEndAction { root.removeView(v) }.start()
    }
    override fun onDestroy() { if (registered) { try { unregisterReceiver(endRcv) } catch (e: Exception) { } }; super.onDestroy() }
    @Suppress("OVERRIDE_DEPRECATION") override fun onBackPressed() {
        if (overlay != null) closeChallenge() else if (preview) finish()
    }
}

/** Bedside / always-on clock. Tap to switch between night-red and cyan; drifts slowly to avoid burn-in. */
class AmbientView(ctx: Context, private val onExit: () -> Unit) : View(ctx) {
    private var red = false
    private val timeP = textPaint(C.CYAN, dp(120), THIN, Paint.Align.CENTER)
    private val sm = textPaint(C.DIM, dp(18), MED, Paint.Align.CENTER)
    private val fill = fillPaint(); private val stroke = strokePaint(Color.WHITE, dp(2))
    private val is24 = android.text.format.DateFormat.is24HourFormat(ctx)
    private val df = java.text.SimpleDateFormat("EEEE, d MMMM", java.util.Locale.getDefault())
    private var downT = 0L
    override fun onDraw(c: Canvas) {
        val w = width.toFloat(); val h = height.toFloat()
        c.drawColor(Color.BLACK)
        val col = if (red) 0xFFFF3B2F.toInt() else C.CYAN
        val now = System.currentTimeMillis(); val p = partsFor(TimeZone.getDefault(), now)
        val mi = (now / 60000L)
        val ox = (sin(mi * 0.7) * dp(24)).toFloat(); val oy = (cos(mi * 0.9) * dp(30)).toFloat()
        val cx = w / 2f + ox; val cy = h * 0.42f + oy
        fill.shader = RadialGradient(cx, cy, w * 0.7f, intArrayOf(alphaColor(col, 0.10f), 0), null, Shader.TileMode.CLAMP)
        c.drawCircle(cx, cy, w * 0.7f, fill); fill.shader = null
        timeP.color = col; timeP.textSize = min(w * 0.34f, dp(150)); c.drawText(hm(p[0], p[1], is24), cx, cy, timeP)
        sm.color = alphaColor(col, 0.8f); c.drawText((if (is24) "" else ampmOf(p[0]) + "   ") + two(p[2]), cx, cy + dp(44), sm)
        sm.color = alphaColor(col, 0.55f); c.drawText(df.format(java.util.Date(now)), cx, cy + dp(84), sm)
        val n = Scheduler.nextEnabled(context)
        c.drawText(if (n == null) "No alarm set" else "Next alarm in " + untilText(n - now), cx, cy + dp(120), sm)
        val sec = p[2] / 60f
        for (i in 0 until 60) {
            val a = Math.toRadians(i * 6.0 - 90.0); fill.color = if (i / 60f <= sec) alphaColor(col, 0.9f) else 0x22FFFFFF
            c.drawCircle(cx + cos(a).toFloat() * w * 0.44f, cy - dp(34) + sin(a).toFloat() * w * 0.44f, dp(if (i % 5 == 0) 2.8f else 1.6f), fill)
        }
        sm.color = 0x55FFFFFF; sm.textSize = dp(13); c.drawText("Tap to change colour  \u00B7  hold to exit", w / 2f, h - dp(40), sm); sm.textSize = dp(18)
        postInvalidateOnAnimation()
    }
    override fun onTouchEvent(e: MotionEvent): Boolean {
        when (e.actionMasked) {
            MotionEvent.ACTION_DOWN -> downT = SystemClock.uptimeMillis()
            MotionEvent.ACTION_UP -> { if (SystemClock.uptimeMillis() - downT > 700L) onExit() else { red = !red; thud() } }
        }
        return true
    }
}

class AmbientActivity : Activity() {
    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        DENSITY = resources.displayMetrics.density
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        val lp = window.attributes; lp.screenBrightness = 0.12f; window.attributes = lp
        androidx.core.view.WindowCompat.setDecorFitsSystemWindows(window, false)
        androidx.core.view.WindowInsetsControllerCompat(window, window.decorView).hide(androidx.core.view.WindowInsetsCompat.Type.systemBars())
        setContentView(AmbientView(this) { finish() })
    }
}
