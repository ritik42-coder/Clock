package com.chronox.clock

import android.animation.ValueAnimator
import android.content.Context
import android.graphics.*
import android.graphics.drawable.GradientDrawable
import android.view.*
import android.view.animation.AccelerateInterpolator
import android.view.animation.DecelerateInterpolator
import android.view.animation.OvershootInterpolator
import android.widget.FrameLayout
import android.widget.TextView
import java.util.TimeZone
import kotlin.math.*

fun tv(ctx: Context, text: String, sp: Float, color: Int, face: Typeface = REG): TextView =
    TextView(ctx).apply { this.text = text; textSize = sp; setTextColor(color); typeface = face; includeFontPadding = false }

fun glassBg(r: Float = dp(24), fill: Int = C.GLASS): GradientDrawable =
    GradientDrawable().apply { cornerRadius = r; setColor(fill); setStroke(dpi(1), 0x22FFFFFF) }

private val aStroke = strokePaint(Color.WHITE, dp(2f))
private val aFill = fillPaint()

fun drawAnalog(c: Canvas, cx: Float, cy: Float, r: Float, tz: TimeZone, accent: Int, ticks: Boolean) {
    val now = System.currentTimeMillis()
    val p = partsFor(tz, now)
    val sec = p[2] + p[3] / 1000f
    val min = p[1] + sec / 60f
    val hr = (p[0] % 12) + min / 60f
    aFill.color = 0x18FFFFFF; c.drawCircle(cx, cy, r, aFill)
    aStroke.color = 0x33FFFFFF; aStroke.strokeWidth = max(1f, r * 0.03f); c.drawCircle(cx, cy, r, aStroke)
    if (ticks) {
        for (i in 0 until 60) {
            val a = Math.toRadians(i * 6.0 - 90.0); val big = i % 5 == 0
            val r1 = r * (if (big) 0.82f else 0.9f); val r2 = r * 0.95f
            aStroke.color = if (big) 0xCCFFFFFF.toInt() else 0x44FFFFFF; aStroke.strokeWidth = if (big) r * 0.035f else r * 0.018f
            c.drawLine(cx + cos(a).toFloat() * r1, cy + sin(a).toFloat() * r1, cx + cos(a).toFloat() * r2, cy + sin(a).toFloat() * r2, aStroke)
        }
    }
    fun hand(frac: Float, len: Float, w: Float, col: Int) {
        val a = Math.toRadians(frac * 360.0 - 90.0)
        aStroke.color = col; aStroke.strokeWidth = w
        c.drawLine(cx - cos(a).toFloat() * r * 0.1f, cy - sin(a).toFloat() * r * 0.1f, cx + cos(a).toFloat() * r * len, cy + sin(a).toFloat() * r * len, aStroke)
    }
    hand(hr / 12f, 0.5f, r * 0.07f, C.TEXT)
    hand(min / 60f, 0.75f, r * 0.05f, C.TEXT)
    hand(sec / 60f, 0.85f, r * 0.025f, accent)
    aFill.color = accent; c.drawCircle(cx, cy, r * 0.06f, aFill)
    aFill.color = C.BG; c.drawCircle(cx, cy, r * 0.025f, aFill)
}

class AnalogView(ctx: Context, private val tz: TimeZone, private val accent: Int = C.CYAN, private val ticks: Boolean = true) : View(ctx) {
    override fun onDraw(c: Canvas) {
        val r = min(width, height) / 2f - dp(2)
        drawAnalog(c, width / 2f, height / 2f, r, tz, accent, ticks)
        postInvalidateOnAnimation()
    }
}

/** Foreground card slides sideways to reveal a red trash zone; past the threshold the row collapses and is deleted. */
class SwipeRow(ctx: Context, private val card: View, private val rowH: Int, private val onDelete: () -> Unit) : FrameLayout(ctx) {
    private val slop = ViewConfiguration.get(ctx).scaledTouchSlop
    private var dx0 = 0f; private var dy0 = 0f; private var drag = false; private var tx = 0f
    private var dead = false
    private val bgPaint = fillPaint(); private val ip = strokePaint(Color.WHITE, dp(2.4f))
    private val bg = object : View(ctx) {
        override fun onDraw(c: Canvas) {
            val p = clamp01(abs(tx) / (this@SwipeRow.width * 0.38f))
            val r = RectF(dp(6), dp(6), width - dp(6), height - dp(6))
            bgPaint.color = mixColor(0x40FF4D6D, 0xFFFF4D6D.toInt(), p); c.drawRoundRect(r, dp(28), dp(28), bgPaint)
            val ix = if (tx > 0) dp(44) else width - dp(44); val iy = height / 2f; val s = dp(11) * (0.7f + 0.5f * p)
            ip.color = Color.WHITE; ip.alpha = (255 * min(1f, p * 1.6f + 0.25f)).toInt()
            c.save(); c.translate(ix, iy); c.rotate(-18f * p * sign(tx))
            c.drawLine(-s, -s * 0.55f, s, -s * 0.55f, ip); c.drawLine(-s * 0.35f, -s * 0.85f, s * 0.35f, -s * 0.85f, ip)
            c.drawLine(-s * 0.75f, -s * 0.55f, -s * 0.6f, s, ip); c.drawLine(s * 0.75f, -s * 0.55f, s * 0.6f, s, ip)
            c.drawLine(-s * 0.6f, s, s * 0.6f, s, ip)
            c.restore()
        }
    }
    init {
        layoutParams = android.widget.LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, rowH)
        addView(bg, LayoutParams(-1, -1)); bg.alpha = 0f
        addView(card, LayoutParams(-1, -1))
    }
    override fun onInterceptTouchEvent(e: MotionEvent): Boolean {
        if (dead) return true
        when (e.actionMasked) {
            MotionEvent.ACTION_DOWN -> { dx0 = e.x; dy0 = e.y; drag = false }
            MotionEvent.ACTION_MOVE -> {
                val dx = e.x - dx0; val dy = e.y - dy0
                if (!drag && abs(dx) > slop * 1.5f && abs(dx) > abs(dy) * 1.6f) { drag = true; parent?.requestDisallowInterceptTouchEvent(true); return true }
            }
        }
        return false
    }
    override fun onTouchEvent(e: MotionEvent): Boolean {
        if (dead) return true
        when (e.actionMasked) {
            MotionEvent.ACTION_MOVE -> if (drag) {
                tx = (e.x - dx0); card.translationX = tx; card.rotation = tx / width * 3f; bg.alpha = 1f; bg.invalidate()
            }
            MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> if (drag) {
                drag = false
                if (abs(tx) > width * 0.38f && e.actionMasked == MotionEvent.ACTION_UP) remove(if (tx > 0) 1 else -1)
                else animF(tx, 0f, 380L, OvershootInterpolator(1.6f)) { tx = it; card.translationX = it; card.rotation = it / width * 3f; bg.invalidate() }
            }
        }
        return true
    }
    fun remove(dir: Int) {
        if (dead) return; dead = true; hold()
        animF(tx, dir * width * 1.1f, 240L, AccelerateInterpolator()) { tx = it; card.translationX = it; card.rotation = it / width * 6f; bg.invalidate() }
        val h0 = height
        animF(1f, 0f, 280L, DecelerateInterpolator(), 220L, { onDelete() }) { t ->
            val lp = layoutParams; lp.height = (h0 * t).toInt().coerceAtLeast(0); layoutParams = lp; alpha = t
        }
    }
}

fun bigButton(ctx: Context, text: String, c1: Int, c2: Int, onClick: () -> Unit): TextView = TextView(ctx).apply {
    this.text = text; textSize = 16f; typeface = BOLD; setTextColor(0xFF05060D.toInt()); gravity = Gravity.CENTER
    background = GradientDrawable(GradientDrawable.Orientation.LEFT_RIGHT, intArrayOf(c1, c2)).apply { cornerRadius = dp(28) }
    setOnClickListener { thud(); onClick() }; pressable()
}
fun ghostButton(ctx: Context, text: String, col: Int, onClick: () -> Unit): TextView = TextView(ctx).apply {
    this.text = text; textSize = 16f; typeface = MED; setTextColor(col); gravity = Gravity.CENTER
    background = glassBg(dp(28)); setOnClickListener { thud(); onClick() }; pressable()
}
