package com.chronox.clock

import android.content.Context
import android.graphics.*
import android.text.format.DateFormat
import android.view.*
import android.view.animation.DecelerateInterpolator
import android.widget.*
import java.util.Calendar
import kotlin.math.*

class TimerDial(ctx: Context) : View(ctx) {
    var frac = 1f; var remaining = 0L; var running = false; var paused = false; var mode = 0f
    private val track = strokePaint(0x1AFFFFFF, dp(10)); private val arc = strokePaint(Color.WHITE, dp(10))
    private val glow = strokePaint(Color.WHITE, dp(24)); private val tick = strokePaint(Color.WHITE, dp(2))
    private val dotP = fillPaint(); private val big = textPaint(C.TEXT, dp(64), THIN, Paint.Align.CENTER)
    private val small = textPaint(C.DIM, dp(14), MED, Paint.Align.CENTER)
    private val oval = RectF(); private val m = Matrix()

    override fun onDraw(c: Canvas) {
        val cx = width / 2f; val cy = height / 2f; val R = min(width, height) * 0.40f
        val urgent = (running && remaining < 10000L)
        val pulse = if (urgent) 1f + 0.03f * sin(SystemClock_ms() / 120f) else 1f
        c.save(); c.scale(pulse, pulse, cx, cy)
        // ticks
        val a = mode
        for (i in 0 until 60) {
            val ang = Math.toRadians(i * 6.0 - 90.0); val lit = (i / 60f) < frac && a > 0.01f
            val big5 = i % 5 == 0
            val r1 = R + dp(if (big5) 22 else 24); val r2 = R + dp(30)
            tick.color = if (lit) alphaColor(mixColor(C.MAGENTA, C.CYAN, i / 60f), a) else 0x22FFFFFF
            tick.strokeWidth = dp(if (big5) 2.6f else 1.6f)
            c.drawLine(cx + cos(ang).toFloat() * r1, cy + sin(ang).toFloat() * r1, cx + cos(ang).toFloat() * r2, cy + sin(ang).toFloat() * r2, tick)
        }
        oval.set(cx - R, cy - R, cx + R, cy + R)
        c.drawCircle(cx, cy, R, track)
        if (a > 0.01f) {
            val sweep = 360f * frac
            val colors = intArrayOf(C.CYAN, C.VIOLET, C.MAGENTA, C.CYAN)
            val sh = SweepGradient(cx, cy, colors, floatArrayOf(0f, 0.4f, 0.8f, 1f)); m.reset(); m.postRotate(-90f, cx, cy); sh.setLocalMatrix(m)
            arc.shader = sh; arc.alpha = (255 * a).toInt(); glow.shader = sh; glow.alpha = (60 * a).toInt()
            if (sweep > 0.5f) { c.drawArc(oval, -90f, sweep, false, glow); c.drawArc(oval, -90f, sweep, false, arc) }
            val ang = Math.toRadians(-90.0 + sweep)
            val hx = cx + cos(ang).toFloat() * R; val hy = cy + sin(ang).toFloat() * R
            dotP.color = alphaColor(Color.WHITE, 0.25f * a); c.drawCircle(hx, hy, dp(14), dotP)
            dotP.color = alphaColor(Color.WHITE, a); c.drawCircle(hx, hy, dp(6), dotP)
            // digits
            val s = (remaining + 999L) / 1000L; val h = s / 3600; val mm = (s % 3600) / 60; val ss = s % 60
            val txt = if (h > 0) "$h:${two(mm.toInt())}:${two(ss.toInt())}" else "${two(mm.toInt())}:${two(ss.toInt())}"
            big.textSize = if (h > 0) R * 0.40f else R * 0.52f
            val blink = if (paused) (0.5f + 0.5f * cos(SystemClock_ms() / 300f)) * 0.6f + 0.4f else 1f
            big.color = alphaColor(if (urgent) C.RED else C.TEXT, a * blink)
            c.drawText(txt, cx, cy + R * 0.12f, big)
            val end = Calendar.getInstance().apply { timeInMillis = System.currentTimeMillis() + remaining }
            small.color = alphaColor(C.DIM, a)
            c.drawText(if (paused) "Paused" else "Ends at " + hm(end.get(Calendar.HOUR_OF_DAY), end.get(Calendar.MINUTE), DateFormat.is24HourFormat(context)) +
                (if (DateFormat.is24HourFormat(context)) "" else " " + ampmOf(end.get(Calendar.HOUR_OF_DAY))), cx, cy + R * 0.42f, small)
        }
        c.restore()
        if (running || paused) postInvalidateOnAnimation()
    }
    private fun SystemClock_ms() = android.os.SystemClock.uptimeMillis().toFloat()
}

class TimerPage(ctx: Context) : Page(ctx) {
    private val dial = TimerDial(ctx)
    private val wh = WheelView(ctx, (0..23).map { "$it" }, true)
    private val wm = WheelView(ctx, (0..59).map { two(it) }, true)
    private val ws = WheelView(ctx, (0..59).map { two(it) }, true)
    private val wheelRow = LinearLayout(ctx)
    private val title = tv(ctx, "Timer", 34f, C.TEXT, THIN)
    private val startBtn = CircleBtn(ctx, dp(92), true)
    private val resetBtn = CircleBtn(ctx, dp(68), false)
    private val addBtn = CircleBtn(ctx, dp(68), false)
    private val presets: ChipRow
    private val box = FrameLayout(ctx)
    private val btnRow = LinearLayout(ctx)
    private var lastState = -1
    private var mode = 0f
    private val loop = FrameLoop { tickFrame() }
    private val presetMs = listOf(60000L, 180000L, 300000L, 600000L, 900000L, 1800000L)

    init {
        addView(title, LayoutParams(-2, -2).apply { leftMargin = dpi(24) })
        presets = ChipRow(ctx, listOf("1 min", "3 min", "5 min", "10 min", "15 min", "30 min"), -1, C.MAGENTA) { setWheels(presetMs[it]) }
        addView(box, LayoutParams(-1, dpi(330), Gravity.TOP))
        box.addView(dial, FrameLayout.LayoutParams(-1, -1))
        wheelRow.orientation = LinearLayout.HORIZONTAL; wheelRow.gravity = Gravity.CENTER
        listOf(Triple(wh, "h", 70), Triple(wm, "min", 78), Triple(ws, "sec", 78)).forEach { (w, l, wd) ->
            val colv = LinearLayout(ctx).apply { orientation = LinearLayout.VERTICAL; gravity = Gravity.CENTER_HORIZONTAL }
            colv.addView(w, LinearLayout.LayoutParams(dpi(wd), dpi(190)))
            colv.addView(tv(ctx, l, 13f, C.DIM, MED), LinearLayout.LayoutParams(-2, -2).apply { topMargin = dpi(4) })
            wheelRow.addView(colv)
        }
        box.addView(wheelRow, FrameLayout.LayoutParams(-2, -2, Gravity.CENTER))
        setWheels(TimerStore.lastSet(ctx))
        resetBtn.type = CircleBtn.RESET; addBtn.type = CircleBtn.TEXT; addBtn.label = "+1:00"; startBtn.accent = C.MAGENTA; startBtn.accent2 = C.VIOLET
        btnRow.orientation = LinearLayout.HORIZONTAL; btnRow.gravity = Gravity.CENTER
        btnRow.addView(resetBtn, LinearLayout.LayoutParams(dpi(68), dpi(68)).apply { rightMargin = dpi(26) })
        btnRow.addView(startBtn, LinearLayout.LayoutParams(dpi(92), dpi(92)))
        btnRow.addView(addBtn, LinearLayout.LayoutParams(dpi(68), dpi(68)).apply { leftMargin = dpi(26) })
        addView(btnRow, LayoutParams(-1, -2, Gravity.TOP))
        addView(presets, LayoutParams(-1, -2, Gravity.TOP))
        startBtn.setOnClickListener {
            hold()
            when (TimerStore.state(context)) {
                TimerStore.RUNNING -> TimerStore.pause(context)
                TimerStore.PAUSED -> TimerStore.resume(context)
                else -> {
                    val ms = ((wh.selectedIndex * 3600L) + wm.selectedIndex * 60L + ws.selectedIndex) * 1000L
                    if (ms <= 0L) { wheelRow.animate().translationX(dp(10)).setDuration(60).withEndAction { wheelRow.animate().translationX(0f).setDuration(200).start() }.start() }
                    else { TimerStore.setLast(context, ms); TimerStore.start(context, ms) }
                }
            }
        }
        resetBtn.setOnClickListener { thud(); TimerStore.reset(context) }
        addBtn.setOnClickListener { thud(); TimerStore.addMs(context, 60000L) }
    }

    private fun setWheels(ms: Long) {
        val s = ms / 1000L
        wh.setSelected(((s / 3600) % 24).toInt(), false); wm.setSelected(((s % 3600) / 60).toInt(), false); ws.setSelected((s % 60).toInt(), false)
    }

    override fun applyInsets() {
        (title.layoutParams as LayoutParams).topMargin = topInset + dpi(18)
        val top = topInset + dpi(70)
        (box.layoutParams as LayoutParams).topMargin = top
        (btnRow.layoutParams as LayoutParams).topMargin = top + dpi(340)
        (presets.layoutParams as LayoutParams).apply { topMargin = top + dpi(470); leftMargin = dpi(20) }
        requestLayout()
    }
    override fun onShow() { loop.start() }
    override fun onHide() { loop.stop() }
    override fun onAttachedToWindow() { super.onAttachedToWindow(); loop.start() }
    override fun onDetachedFromWindow() { loop.stop(); super.onDetachedFromWindow() }
    override fun playEntrance() {
        val views = listOf<View>(box, btnRow, presets)
        views.forEachIndexed { i, v -> v.alpha = 0f; v.translationY = dp(50); v.animate().alpha(1f).translationY(0f).setStartDelay(i * 90L).setDuration(500).setInterpolator(DecelerateInterpolator(2f)).start() }
    }

    private fun tickFrame() {
        val st = TimerStore.state(context)
        val rem = if (st == TimerStore.IDLE) 0L else TimerStore.remaining(context)
        if (st == TimerStore.RUNNING && rem <= 0L) { TimerStore.finish(context) }
        if (st != lastState) {
            lastState = st
            val active = st != TimerStore.IDLE
            startBtn.setIcon(if (st == TimerStore.RUNNING) CircleBtn.PAUSE else CircleBtn.PLAY)
            resetBtn.dimmed = !active; addBtn.dimmed = !active
            animF(mode, if (active) 1f else 0f, 520L, DecelerateInterpolator(2f)) { mode = it; dial.mode = it; wheelRow.alpha = 1f - it; wheelRow.scaleX = 1f - 0.2f * it; wheelRow.scaleY = wheelRow.scaleX; wheelRow.visibility = if (it > 0.98f) View.INVISIBLE else View.VISIBLE
                presets.alpha = 1f - it; presets.visibility = if (it > 0.98f) View.INVISIBLE else View.VISIBLE; dial.invalidate() }
        }
        val tot = max(1L, TimerStore.total(context))
        dial.frac = if (st == TimerStore.IDLE) 1f else clamp01(rem.toFloat() / tot); dial.remaining = rem
        dial.running = st == TimerStore.RUNNING; dial.paused = st == TimerStore.PAUSED
        dial.invalidate()
    }
}
