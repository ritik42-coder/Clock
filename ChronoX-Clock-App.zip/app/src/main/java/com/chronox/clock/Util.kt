package com.chronox.clock

import android.animation.Animator
import android.animation.AnimatorListenerAdapter
import android.animation.TimeInterpolator
import android.animation.ValueAnimator
import android.graphics.*
import android.view.HapticFeedbackConstants
import android.view.MotionEvent
import android.view.View
import android.widget.FrameLayout
import android.view.Choreographer
import java.util.TimeZone
import kotlin.math.*

var DENSITY = 1f
fun dp(v: Number): Float = v.toFloat() * DENSITY
fun dpi(v: Number): Int = (v.toFloat() * DENSITY).roundToInt()

object C {
    const val BG = 0xFF05060D.toInt()
    const val CYAN = 0xFF3DE0FF.toInt()
    const val VIOLET = 0xFF8B5CFF.toInt()
    const val MAGENTA = 0xFFFF4FD8.toInt()
    const val ORANGE = 0xFFFF9F43.toInt()
    const val GREEN = 0xFF34F5A5.toInt()
    const val RED = 0xFFFF4D6D.toInt()
    const val TEXT = 0xFFF4F6FF.toInt()
    const val DIM = 0xFF8D93B3.toInt()
    const val CARD = 0xFF11152A.toInt()
    const val GLASS = 0x14FFFFFF
    const val GLASS2 = 0x26FFFFFF
}

val String.c: Int get() = Color.parseColor(this)

val THIN: Typeface = Typeface.create("sans-serif-thin", Typeface.NORMAL)
val LIGHT: Typeface = Typeface.create("sans-serif-light", Typeface.NORMAL)
val REG: Typeface = Typeface.create("sans-serif", Typeface.NORMAL)
val MED: Typeface = Typeface.create("sans-serif-medium", Typeface.NORMAL)
val BOLD: Typeface = Typeface.create("sans-serif", Typeface.BOLD)

fun clamp01(v: Float) = if (v < 0f) 0f else if (v > 1f) 1f else v
fun lerp(a: Float, b: Float, t: Float) = a + (b - a) * t
fun seg(t: Float, a: Float, b: Float) = clamp01((t - a) / (b - a))
fun smooth(t: Float): Float { val k = clamp01(t); return k * k * (3f - 2f * k) }
fun easeOutCubic(t: Float): Float { val u = 1f - clamp01(t); return 1f - u * u * u }
fun easeOutBack(t: Float): Float { val k = clamp01(t); val c1 = 1.70158f; val c3 = c1 + 1f; val u = k - 1f; return 1f + c3 * u * u * u + c1 * u * u }
fun fmod(a: Int, n: Int) = ((a % n) + n) % n

fun mixColor(a: Int, b: Int, t: Float): Int {
    val k = clamp01(t)
    return Color.argb(
        (Color.alpha(a) + (Color.alpha(b) - Color.alpha(a)) * k).toInt(),
        (Color.red(a) + (Color.red(b) - Color.red(a)) * k).toInt(),
        (Color.green(a) + (Color.green(b) - Color.green(a)) * k).toInt(),
        (Color.blue(a) + (Color.blue(b) - Color.blue(a)) * k).toInt()
    )
}
fun alphaColor(c: Int, a: Float): Int = (c and 0x00FFFFFF) or ((clamp01(a) * 255f).toInt() shl 24)

fun fillPaint(color: Int = Color.WHITE) = Paint(Paint.ANTI_ALIAS_FLAG).apply { this.color = color; style = Paint.Style.FILL }
fun strokePaint(color: Int, w: Float) = Paint(Paint.ANTI_ALIAS_FLAG).apply {
    this.color = color; style = Paint.Style.STROKE; strokeWidth = w; strokeCap = Paint.Cap.ROUND; strokeJoin = Paint.Join.ROUND
}
fun textPaint(color: Int, size: Float, face: Typeface = REG, align: Paint.Align = Paint.Align.LEFT) = Paint(Paint.ANTI_ALIAS_FLAG).apply {
    this.color = color; textSize = size; typeface = face; textAlign = align; fontFeatureSettings = "tnum"
}

fun animF(from: Float, to: Float, dur: Long, interp: TimeInterpolator? = null, delay: Long = 0L, end: (() -> Unit)? = null, upd: (Float) -> Unit): ValueAnimator {
    val a = ValueAnimator.ofFloat(from, to)
    a.duration = dur; a.startDelay = delay
    if (interp != null) a.interpolator = interp
    a.addUpdateListener { upd(it.animatedValue as Float) }
    if (end != null) a.addListener(object : AnimatorListenerAdapter() {
        override fun onAnimationEnd(animation: Animator) { end() }
    })
    a.start()
    return a
}

fun View.tick() { performHapticFeedback(HapticFeedbackConstants.CLOCK_TICK) }
fun View.thud() { performHapticFeedback(HapticFeedbackConstants.CONTEXT_CLICK) }
fun View.hold() { performHapticFeedback(HapticFeedbackConstants.LONG_PRESS) }

fun View.pressable() {
    setOnTouchListener { v, e ->
        when (e.actionMasked) {
            MotionEvent.ACTION_DOWN -> v.animate().scaleX(0.95f).scaleY(0.95f).setDuration(90).start()
            MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> v.animate().scaleX(1f).scaleY(1f).setDuration(180).start()
        }
        false
    }
}

class FrameLoop(private val cb: () -> Unit) : Choreographer.FrameCallback {
    private var on = false
    fun start() { if (!on) { on = true; Choreographer.getInstance().postFrameCallback(this) } }
    fun stop() { on = false; Choreographer.getInstance().removeFrameCallback(this) }
    override fun doFrame(frameTimeNanos: Long) { if (!on) return; cb(); Choreographer.getInstance().postFrameCallback(this) }
}

open class Page(ctx: android.content.Context) : FrameLayout(ctx) {
    var topInset = 0
    var bottomInset = 0   // bottom area reserved for the nav bar
    open fun applyInsets() {}
    fun setInsets(t: Int, b: Int) { topInset = t; bottomInset = b; applyInsets() }
    open fun onShow() {}
    open fun onHide() {}
    open fun playEntrance() {}
}

class AlarmTheme(val name: String, val c1: Int, val c2: Int, val c3: Int, val bg: Int)

val THEMES = listOf(
    AlarmTheme("Aurora", "#3DE0FF".c, "#8B5CFF".c, "#34F5A5".c, "#050B1A".c),
    AlarmTheme("Sunrise", "#FF9F43".c, "#FF4D6D".c, "#FFD166".c, "#1A0B12".c),
    AlarmTheme("Ocean", "#2DD4FF".c, "#2563EB".c, "#22D3EE".c, "#03101F".c),
    AlarmTheme("Neon", "#FF4FD8".c, "#8B5CFF".c, "#3DE0FF".c, "#0B0518".c),
    AlarmTheme("Forest", "#34F5A5".c, "#10B981".c, "#A3E635".c, "#04130D".c),
    AlarmTheme("Dusk", "#FF7A59".c, "#9B5CFF".c, "#FFB86B".c, "#120A1F".c)
)
fun themeFor(idx: Int, hour: Int): AlarmTheme {
    if (idx in 0..5) return THEMES[idx]
    return THEMES[when { hour in 5..8 -> 1; hour in 9..16 -> 2; hour in 17..19 -> 5; else -> 3 }]
}

fun two(n: Int) = if (n < 10) "0$n" else "$n"
fun hm(h: Int, m: Int, is24: Boolean): String =
    if (is24) "${two(h)}:${two(m)}" else "${if (h % 12 == 0) 12 else h % 12}:${two(m)}"
fun ampmOf(h: Int) = if (h < 12) "AM" else "PM"

val DAY_LETTERS = arrayOf("M", "T", "W", "T", "F", "S", "S")
val DAY_NAMES = arrayOf("Mon", "Tue", "Wed", "Thu", "Fri", "Sat", "Sun")
fun daysSummary(mask: Int): String = when (mask) {
    0 -> "Once"
    127 -> "Every day"
    31 -> "Weekdays"
    96 -> "Weekends"
    else -> (0..6).filter { (mask and (1 shl it)) != 0 }.joinToString(", ") { DAY_NAMES[it] }
}

fun untilText(ms: Long): String {
    val m = (ms + 59999L) / 60000L
    val d = m / 1440L; val h = (m % 1440L) / 60L; val mm = m % 60L
    return when {
        d > 0 -> "${d}d ${h}h ${mm}m"
        h > 0 -> "${h}h ${mm}m"
        mm > 0 -> "${mm}m"
        else -> "less than a minute"
    }
}

/** [hour, minute, second, millis] of "now" in the given zone, allocation-light. */
fun partsFor(tz: TimeZone, now: Long): IntArray {
    val l = now + tz.getOffset(now)
    val msDay = Math.floorMod(l, 86400000L).toInt()
    return intArrayOf(msDay / 3600000, (msDay / 60000) % 60, (msDay / 1000) % 60, msDay % 1000)
}
fun dayIndex(tz: TimeZone, now: Long): Long = Math.floorDiv(now + tz.getOffset(now), 86400000L)

fun fastAtan2(y: Float, x: Float): Float {
    val ax = abs(x); val ay = abs(y)
    val mx = max(ax, ay); val mn = min(ax, ay)
    if (mx == 0f) return 0f
    val a = mn / mx
    val s = a * a
    var r = ((-0.0464964749f * s + 0.15931422f) * s - 0.327622764f) * s * a + a
    if (ay > ax) r = 1.57079637f - r
    if (x < 0f) r = 3.14159274f - r
    if (y < 0f) r = -r
    return r
}

fun drawSwitch(c: Canvas, l: Float, t: Float, w: Float, h: Float, p: Float, accent: Int, paint: Paint) {
    paint.style = Paint.Style.FILL; paint.shader = null
    paint.color = mixColor(0xFF2A2F4A.toInt(), accent, p)
    c.drawRoundRect(l, t, l + w, t + h, h / 2, h / 2, paint)
    val r = h / 2 - dp(3)
    val cx = l + h / 2 + (w - h) * p
    if (p > 0.01f) { paint.color = alphaColor(accent, 0.28f * p); c.drawCircle(cx, t + h / 2, r * 1.8f, paint) }
    paint.color = mixColor(0xFFAAB0CC.toInt(), Color.WHITE, p)
    c.drawCircle(cx, t + h / 2, r, paint)
}

private val bellPath = Path()
fun drawBell(c: Canvas, cx: Float, cy: Float, s: Float, color: Int, angle: Float, p: Paint) {
    c.save(); c.rotate(angle, cx, cy - s * 0.6f)
    p.style = Paint.Style.FILL; p.shader = null; p.color = color
    val b = bellPath; b.reset()
    b.moveTo(cx - 0.55f * s, cy + 0.30f * s)
    b.cubicTo(cx - 0.40f * s, cy + 0.20f * s, cx - 0.40f * s, cy - 0.05f * s, cx - 0.34f * s, cy - 0.25f * s)
    b.cubicTo(cx - 0.28f * s, cy - 0.50f * s, cx - 0.12f * s, cy - 0.55f * s, cx, cy - 0.55f * s)
    b.cubicTo(cx + 0.12f * s, cy - 0.55f * s, cx + 0.28f * s, cy - 0.50f * s, cx + 0.34f * s, cy - 0.25f * s)
    b.cubicTo(cx + 0.40f * s, cy - 0.05f * s, cx + 0.40f * s, cy + 0.20f * s, cx + 0.55f * s, cy + 0.30f * s)
    b.close()
    c.drawPath(b, p)
    c.drawCircle(cx, cy - 0.60f * s, 0.07f * s, p)
    c.rotate(-angle * 0.6f, cx, cy + 0.30f * s)
    c.drawCircle(cx, cy + 0.43f * s, 0.12f * s, p)
    c.restore()
}
