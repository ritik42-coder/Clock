package com.chronox.clock

import android.Manifest
import android.content.Context
import android.content.pm.PackageManager
import android.graphics.*
import android.hardware.Camera
import android.hardware.Sensor
import android.hardware.SensorEvent
import android.hardware.SensorEventListener
import android.hardware.SensorManager
import android.os.SystemClock
import android.view.MotionEvent
import android.view.TextureView
import android.view.View
import android.widget.FrameLayout
import com.google.zxing.BarcodeFormat
import com.google.zxing.BinaryBitmap
import com.google.zxing.DecodeHintType
import com.google.zxing.MultiFormatReader
import com.google.zxing.PlanarYUVLuminanceSource
import com.google.zxing.common.HybridBinarizer
import java.util.concurrent.Executors
import kotlin.math.*

val STOP_NAMES = listOf("Slide", "Hold", "Math", "Shake", "Walk", "QR scan")
val STOP_PROMPTS = listOf("Slide to stop", "Hold to stop", "Solve to stop", "Shake to stop", "Walk to stop", "Scan to stop")
val STYLE_NAMES = listOf("Aurora", "Orbit", "Pulse", "Sunrise", "Cyber", "Minimal")
val LEVEL_NAMES = listOf("Easy", "Medium", "Hard")

abstract class ChView(ctx: Context, protected val th: AlarmTheme, private val title: String, private val onClose: () -> Unit) : View(ctx) {
    protected val fill = fillPaint()
    protected val str = strokePaint(Color.WHITE, dp(2))
    protected val tp = textPaint(Color.WHITE, dp(16), MED, Paint.Align.CENTER)
    protected var tt = 0f
    protected var dt = 0f
    protected var w = 0f
    protected var h = 0f
    private var lastT = 0f
    private val closeR = RectF()
    init { isClickable = true }
    protected abstract fun drawBody(c: Canvas)
    protected open fun onTouch(e: MotionEvent) {}
    override fun onDraw(c: Canvas) {
        w = width.toFloat(); h = height.toFloat(); tt = SystemClock.uptimeMillis() / 1000f
        dt = if (lastT == 0f) 0f else (tt - lastT).coerceIn(0f, 0.1f); lastT = tt
        fill.shader = LinearGradient(0f, 0f, 0f, h, intArrayOf(th.bg, mixColor(th.bg, th.c2, 0.32f), mixColor(th.bg, th.c1, 0.22f)), floatArrayOf(0f, 0.6f, 1f), Shader.TileMode.CLAMP)
        c.drawRect(0f, 0f, w, h, fill)
        for (i in 0 until 2) {
            val x = w * (0.5f + 0.4f * sin(tt * 0.4f + i * 2.4f)); val y = h * (0.4f + 0.3f * cos(tt * 0.33f + i * 1.7f)); val r = max(w, h) * 0.55f
            fill.shader = RadialGradient(x, y, r, intArrayOf(alphaColor(if (i == 0) th.c1 else th.c2, 0.35f), 0), null, Shader.TileMode.CLAMP)
            c.drawCircle(x, y, r, fill)
        }
        fill.shader = null
        drawBody(c)
        closeR.set(dp(16), dp(44), dp(104), dp(84)); fill.color = 0x30FFFFFF; c.drawRoundRect(closeR, dp(20), dp(20), fill)
        tp.textSize = dp(14); tp.color = Color.WHITE; c.drawText("\u2039 Back", closeR.centerX(), closeR.centerY() + dp(5), tp)
        tp.textSize = dp(15); tp.color = 0xCCFFFFFF.toInt(); c.drawText(title, w / 2f + dp(40), dp(70), tp)
        postInvalidateOnAnimation()
    }
    override fun onTouchEvent(e: MotionEvent): Boolean {
        if (e.actionMasked == MotionEvent.ACTION_UP && closeR.contains(e.x, e.y)) { onClose(); return true }
        onTouch(e); return true
    }
}

/** Solve a few arithmetic problems on an animated keypad. */
class MathView(ctx: Context, th: AlarmTheme, private val level: Int, private val onSolved: () -> Unit, onClose: () -> Unit) : ChView(ctx, th, "Solve to stop", onClose) {
    private val rnd = java.util.Random()
    private val total = 2 + level.coerceIn(0, 2)
    private var idx = 0
    private var qText = ""
    private var ans = 0
    private var input = ""
    private var shake = 0f; private var flash = 0f; private var good = 0f
    private var done = false
    private val keys = arrayOf("1", "2", "3", "4", "5", "6", "7", "8", "9", "\u232B", "0", "OK")
    private val keyR = Array(12) { RectF() }
    private var pressed = -1; private var pressT = 0L
    private val big = textPaint(Color.WHITE, dp(54), THIN, Paint.Align.CENTER)
    private val box = RectF()
    init { next() }

    private fun next() {
        when (level) {
            0 -> { val a = 10 + rnd.nextInt(50); val b = 10 + rnd.nextInt(40); qText = "$a + $b"; ans = a + b }
            1 -> { val a = 6 + rnd.nextInt(14); val b = 3 + rnd.nextInt(7); val c = 5 + rnd.nextInt(40); qText = "$a \u00D7 $b + $c"; ans = a * b + c }
            else -> { val a = 12 + rnd.nextInt(18); val b = 6 + rnd.nextInt(7); val c = 5 + rnd.nextInt(a * b / 2); qText = "$a \u00D7 $b \u2212 $c"; ans = a * b - c }
        }
    }
    private fun submit() {
        val v = input.toIntOrNull()
        if (v == ans) {
            good = 1f; thud(); idx++
            if (idx >= total) { done = true; postDelayed({ onSolved() }, 500) } else { input = ""; next() }
        } else { shake = 1f; flash = 1f; input = "" }
    }
    private fun press(i: Int) {
        if (done) return
        tick()
        when (i) { 9 -> input = input.dropLast(1); 11 -> submit(); else -> if (input.length < 5) input += keys[i] }
    }
    override fun drawBody(c: Canvas) {
        shake = max(0f, shake - dt * 2.2f); flash = max(0f, flash - dt * 2f); good = max(0f, good - dt * 2.5f)
        // progress dots
        for (i in 0 until total) {
            val x = w / 2f + (i - (total - 1) / 2f) * dp(26); val y = h * 0.17f
            fill.color = if (i < idx) th.c3 else 0x33FFFFFF; c.drawCircle(x, y, dp(7) + (if (i == idx) dp(2) * (0.5f + 0.5f * sin(tt * 5f)) else 0f), fill)
        }
        big.textSize = dp(54); c.drawText(qText, w / 2f, h * 0.285f, big)
        tp.textSize = dp(15); tp.color = th.c1; c.drawText("Problem ${min(idx + 1, total)} of $total", w / 2f, h * 0.315f, tp)
        // answer box
        val dx = sin(tt * 60f) * shake * dp(10)
        box.set(w * 0.2f + dx, h * 0.34f, w * 0.8f + dx, h * 0.34f + dp(72))
        fill.color = mixColor(mixColor(0x26FFFFFF, alphaColor(C.GREEN, 0.35f), good), alphaColor(C.RED, 0.4f), flash); c.drawRoundRect(box, dp(22), dp(22), fill)
        str.color = mixColor(mixColor(0x55FFFFFF, C.GREEN, good), C.RED, flash); str.strokeWidth = dp(2); c.drawRoundRect(box, dp(22), dp(22), str)
        big.textSize = dp(40); big.color = Color.WHITE
        val shown = input + (if (((tt * 2f).toInt() % 2) == 0) "|" else "")
        c.drawText(if (input.isEmpty() && shown == "") "?" else shown, box.centerX(), box.centerY() + dp(14), big)
        // keypad
        val top = h * 0.50f; val kw = (w - dp(72)) / 3f; val kh = min(dp(66), (h - top - dp(40)) / 4f)
        val now = SystemClock.uptimeMillis()
        for (i in 0 until 12) {
            val r = i / 3; val cc = i % 3
            val l = dp(24) + cc * (kw + dp(12)); val t = top + r * (kh + dp(10))
            keyR[i].set(l, t, l + kw, t + kh)
            val pr = if (pressed == i) clamp01(1f - (now - pressT) / 260f).let { if (it < 0.25f) 0.25f else it } else 0f
            val sc = 1f - 0.06f * (if (pressed == i) 1f else 0f)
            c.save(); c.scale(sc, sc, keyR[i].centerX(), keyR[i].centerY())
            fill.color = if (i == 11) mixColor(alphaColor(th.c1, 0.5f), alphaColor(th.c1, 0.85f), pr) else mixColor(0x22FFFFFF, 0x55FFFFFF, pr)
            c.drawRoundRect(keyR[i], dp(20), dp(20), fill)
            tp.textSize = dp(if (i == 11) 20 else 26); tp.color = if (i == 9) 0xFFFF9DB0.toInt() else Color.WHITE
            c.drawText(keys[i], keyR[i].centerX(), keyR[i].centerY() + dp(9), tp)
            c.restore()
        }
        if (done) { fill.color = alphaColor(C.GREEN, 0.18f); c.drawRect(0f, 0f, w, h, fill) }
    }
    override fun onTouch(e: MotionEvent) {
        when (e.actionMasked) {
            MotionEvent.ACTION_DOWN -> { pressed = -1; for (i in 0 until 12) if (keyR[i].contains(e.x, e.y)) { pressed = i; pressT = SystemClock.uptimeMillis() } }
            MotionEvent.ACTION_UP -> { if (pressed >= 0 && keyR[pressed].contains(e.x, e.y)) press(pressed); pressed = -1 }
            MotionEvent.ACTION_CANCEL -> pressed = -1
        }
    }
}

private class Spark(var x: Float, var y: Float, var vx: Float, var vy: Float, var life: Float, var col: Int)

/** Shake the phone N times. Falls back to taps when there is no accelerometer. */
class ShakeView(ctx: Context, th: AlarmTheme, private val level: Int, private val onSolved: () -> Unit, onClose: () -> Unit) : ChView(ctx, th, "Shake to stop", onClose), SensorEventListener {
    private val target = intArrayOf(15, 25, 40)[level.coerceIn(0, 2)]
    private var count = 0; private var energy = 0f; private var last = 0L; private var done = false; private var pulse = 0f
    private val sm = ctx.getSystemService(Context.SENSOR_SERVICE) as SensorManager
    private val acc: Sensor? = sm.getDefaultSensor(Sensor.TYPE_ACCELEROMETER)
    private val parts = ArrayList<Spark>()
    private val rnd = java.util.Random()
    private val rect = RectF(); private val m = Matrix()
    private val big = textPaint(Color.WHITE, dp(44), THIN, Paint.Align.CENTER)

    override fun onAttachedToWindow() { super.onAttachedToWindow(); acc?.let { sm.registerListener(this, it, SensorManager.SENSOR_DELAY_GAME) } }
    override fun onDetachedFromWindow() { sm.unregisterListener(this); super.onDetachedFromWindow() }
    override fun onAccuracyChanged(s: Sensor?, a: Int) {}
    override fun onSensorChanged(e: SensorEvent) {
        val g = sqrt(e.values[0] * e.values[0] + e.values[1] * e.values[1] + e.values[2] * e.values[2]) / 9.81f
        energy = max(energy, (g - 1f).coerceIn(0f, 3f))
        val now = SystemClock.uptimeMillis()
        if (g > 2.3f && now - last > 280L) { last = now; hit() }
    }
    private fun hit() {
        if (done) return
        count++; pulse = 1f; thud()
        for (i in 0 until 16) { val a = rnd.nextFloat() * 6.2832f; val v = dp(120) + rnd.nextFloat() * dp(220); parts.add(Spark(w / 2f, h * 0.38f, cos(a) * v, sin(a) * v, 1f, if (i % 2 == 0) th.c1 else th.c3)) }
        if (count >= target) { done = true; postDelayed({ onSolved() }, 600) }
    }
    override fun onTouch(e: MotionEvent) { if (acc == null && e.actionMasked == MotionEvent.ACTION_UP) hit() }
    override fun drawBody(c: Canvas) {
        energy *= (1f - dt * 3f).coerceAtLeast(0f); pulse = max(0f, pulse - dt * 3f)
        val cx = w / 2f; val cy = h * 0.38f; val R = w * 0.30f
        fill.color = alphaColor(th.c1, 0.10f + 0.18f * pulse); c.drawCircle(cx, cy, R * (1.25f + 0.2f * pulse), fill)
        str.color = 0x22FFFFFF; str.strokeWidth = dp(10); c.drawCircle(cx, cy, R, str)
        rect.set(cx - R, cy - R, cx + R, cy + R)
        val sh = SweepGradient(cx, cy, intArrayOf(th.c1, th.c2, th.c3, th.c1), null); m.reset(); m.postRotate(-90f, cx, cy); sh.setLocalMatrix(m)
        str.shader = sh; str.strokeCap = Paint.Cap.ROUND
        c.drawArc(rect, -90f, 360f * count / target, false, str); str.shader = null
        // phone
        c.save(); c.translate(cx + sin(tt * 45f) * energy * dp(6), cy); c.rotate(sin(tt * 38f) * energy * 12f)
        val pw = R * 0.52f; val ph = R * 0.95f
        fill.color = 0xFF0B1022.toInt(); rect.set(-pw, -ph, pw, ph); c.drawRoundRect(rect, dp(18), dp(18), fill)
        str.color = Color.WHITE; str.strokeWidth = dp(3); str.strokeCap = Paint.Cap.BUTT; c.drawRoundRect(rect, dp(18), dp(18), str)
        fill.color = alphaColor(th.c1, 0.35f + 0.4f * pulse); rect.set(-pw + dp(8), -ph + dp(16), pw - dp(8), ph - dp(16)); c.drawRoundRect(rect, dp(10), dp(10), fill)
        c.restore()
        // sparks
        val it = parts.iterator()
        while (it.hasNext()) {
            val p = it.next(); p.life -= dt * 1.6f
            if (p.life <= 0f) { it.remove(); continue }
            p.x += p.vx * dt; p.y += p.vy * dt; p.vx *= 0.96f; p.vy *= 0.96f
            fill.color = alphaColor(p.col, p.life); c.drawCircle(p.x, p.y, dp(4) * p.life, fill)
        }
        big.textSize = dp(46); c.drawText("$count / $target", cx, h * 0.38f + R + dp(80), big)
        tp.textSize = dp(15); tp.color = 0xCCFFFFFF.toInt(); c.drawText(if (acc == null) "No motion sensor \u2013 tap the screen" else "Shake your phone hard", cx, h * 0.38f + R + dp(116), tp)
        if (done) { fill.color = alphaColor(C.GREEN, 0.18f); c.drawRect(0f, 0f, w, h, fill) }
    }
}

/** Take N real steps (detected from the accelerometer, no permission needed). */
class StepsView(ctx: Context, th: AlarmTheme, private val level: Int, private val onSolved: () -> Unit, onClose: () -> Unit) : ChView(ctx, th, "Walk to stop", onClose), SensorEventListener {
    private val target = intArrayOf(10, 20, 35)[level.coerceIn(0, 2)]
    private var count = 0; private var avg = 9.81f; private var prevD = 0f; private var lastStep = 0L; private var pop = 0f; private var done = false
    private val sm = ctx.getSystemService(Context.SENSOR_SERVICE) as SensorManager
    private val acc: Sensor? = sm.getDefaultSensor(Sensor.TYPE_ACCELEROMETER)
    private val big = textPaint(Color.WHITE, dp(48), THIN, Paint.Align.CENTER)
    override fun onAttachedToWindow() { super.onAttachedToWindow(); acc?.let { sm.registerListener(this, it, SensorManager.SENSOR_DELAY_GAME) } }
    override fun onDetachedFromWindow() { sm.unregisterListener(this); super.onDetachedFromWindow() }
    override fun onAccuracyChanged(s: Sensor?, a: Int) {}
    override fun onSensorChanged(e: SensorEvent) {
        val m = sqrt(e.values[0] * e.values[0] + e.values[1] * e.values[1] + e.values[2] * e.values[2])
        avg = avg * 0.92f + m * 0.08f
        val d = m - avg; val now = SystemClock.uptimeMillis()
        if (prevD <= 1.3f && d > 1.3f && now - lastStep > 320L) { lastStep = now; step() }
        prevD = d
    }
    private fun step() { if (done) return; count++; pop = 1f; tick(); if (count >= target) { done = true; postDelayed({ onSolved() }, 600) } }
    override fun onTouch(e: MotionEvent) { if (acc == null && e.actionMasked == MotionEvent.ACTION_UP) step() }
    private fun foot(c: Canvas, cx: Float, cy: Float, s: Float, left: Boolean, col: Int) {
        c.save(); c.translate(cx, cy); c.rotate(if (left) -12f else 12f)
        fill.color = col
        c.drawOval(-s * 0.34f, -s * 0.05f, s * 0.34f, s * 0.66f, fill)
        c.drawOval(-s * 0.32f, -s * 0.62f, s * 0.32f, s * 0.08f, fill)
        for (k in 0 until 5) c.drawCircle(-s * 0.26f + k * s * 0.13f, -s * 0.80f + abs(k - 2) * s * 0.06f, s * 0.065f, fill)
        c.restore()
    }
    override fun drawBody(c: Canvas) {
        pop = max(0f, pop - dt * 3f)
        val cx = w / 2f; val cy = h * 0.36f; val R = w * 0.30f
        for (i in 0 until target) {
            val a = i * 6.2832f / target - 1.5708f; val lit = i < count
            fill.color = if (lit) mixColor(th.c1, th.c3, i / target.toFloat()) else 0x2AFFFFFF
            c.drawCircle(cx + cos(a) * R * 1.2f, cy + sin(a) * R * 1.2f, dp(if (lit) 6.5f else 4f), fill)
        }
        fill.color = alphaColor(th.c1, 0.10f + 0.15f * pop); c.drawCircle(cx, cy, R * (0.95f + 0.2f * pop), fill)
        val s = R * (1.1f + 0.2f * pop)
        foot(c, cx, cy + s * 0.1f, s, count % 2 == 0, alphaColor(Color.WHITE, 0.92f))
        big.textSize = dp(48); c.drawText("$count / $target", cx, h * 0.36f + R * 1.2f + dp(80), big)
        tp.textSize = dp(15); tp.color = 0xCCFFFFFF.toInt()
        c.drawText(if (acc == null) "No motion sensor \u2013 tap to step" else "Get up and walk \u2013 hold the phone", cx, h * 0.36f + R * 1.2f + dp(116), tp)
        if (done) { fill.color = alphaColor(C.GREEN, 0.18f); c.drawRect(0f, 0f, w, h, fill) }
    }
}

/** Scan a registered barcode / QR code with the camera (ZXing). Empty [expected] accepts any code. */
class QrView(ctx: Context, private val th: AlarmTheme, private val expected: String, private val title: String,
             private val onFound: (String) -> Unit, private val onClose: () -> Unit) : FrameLayout(ctx), TextureView.SurfaceTextureListener {
    private val tex = TextureView(ctx)
    private var cam: Camera? = null
    private var pw = 1280; private var ph = 720
    private val exec = Executors.newSingleThreadExecutor()
    @Volatile private var busy = false
    private var lastDecode = 0L
    private var msg = ""
    private var wrong = 0f; private var ok = 0f
    private var found = false
    private val hasCam = ctx.checkSelfPermission(Manifest.permission.CAMERA) == PackageManager.PERMISSION_GRANTED
    private val fill = fillPaint(); private val str = strokePaint(Color.WHITE, dp(5)); private val tp = textPaint(Color.WHITE, dp(15), MED, Paint.Align.CENTER)
    private val closeR = RectF(); private val rc = RectF()
    private var lastT = 0f
    private val reader = MultiFormatReader().apply {
        setHints(mapOf<DecodeHintType, Any>(
            DecodeHintType.POSSIBLE_FORMATS to listOf(BarcodeFormat.QR_CODE, BarcodeFormat.CODE_128, BarcodeFormat.EAN_13, BarcodeFormat.EAN_8, BarcodeFormat.UPC_A, BarcodeFormat.CODE_39, BarcodeFormat.DATA_MATRIX),
            DecodeHintType.TRY_HARDER to true))
    }
    init {
        setWillNotDraw(false); setBackgroundColor(Color.BLACK); isClickable = true
        addView(tex); tex.surfaceTextureListener = this
        if (!hasCam) msg = "Camera permission is needed"
    }
    override fun onLayout(changed: Boolean, l: Int, t: Int, r: Int, b: Int) {
        val W = r - l; val H = b - t
        val ar = ph.toFloat() / pw.toFloat()
        var tw = W; var tH = (W / ar).toInt()
        if (tH < H) { tH = H; tw = (H * ar).toInt() }
        val x0 = (W - tw) / 2; val y0 = (H - tH) / 2
        tex.layout(x0, y0, x0 + tw, y0 + tH)
    }
    override fun onSurfaceTextureAvailable(st: SurfaceTexture, w: Int, h: Int) { openCam(st) }
    override fun onSurfaceTextureSizeChanged(st: SurfaceTexture, w: Int, h: Int) {}
    override fun onSurfaceTextureDestroyed(st: SurfaceTexture): Boolean { releaseCam(); return true }
    override fun onSurfaceTextureUpdated(st: SurfaceTexture) {}
    override fun onDetachedFromWindow() { releaseCam(); exec.shutdown(); super.onDetachedFromWindow() }

    private fun openCam(st: SurfaceTexture) {
        if (!hasCam) return
        try {
            val c = Camera.open()
            val p = c.parameters
            var best: Camera.Size? = null
            for (s in p.supportedPreviewSizes) { if (s.width <= 1280 && (best == null || s.width * s.height > best.width * best.height)) best = s }
            if (best != null) { p.setPreviewSize(best.width, best.height); pw = best.width; ph = best.height }
            if (p.supportedFocusModes.contains(Camera.Parameters.FOCUS_MODE_CONTINUOUS_PICTURE)) p.focusMode = Camera.Parameters.FOCUS_MODE_CONTINUOUS_PICTURE
            c.parameters = p
            c.setDisplayOrientation(90)
            c.setPreviewTexture(st)
            c.setPreviewCallback { data, _ -> onFrame(data) }
            c.startPreview()
            cam = c; requestLayout()
        } catch (e: Exception) { msg = "Camera unavailable" }
    }
    private fun releaseCam() {
        val c = cam ?: return; cam = null
        try { c.setPreviewCallback(null); c.stopPreview(); c.release() } catch (e: Exception) { }
    }
    private fun onFrame(data: ByteArray) {
        val now = SystemClock.uptimeMillis()
        if (busy || found || now - lastDecode < 220L) return
        busy = true; lastDecode = now
        val copy = data.copyOf(); val fw = pw; val fh = ph
        exec.execute {
            var text: String? = null
            try {
                val src = PlanarYUVLuminanceSource(copy, fw, fh, 0, 0, fw, fh, false)
                text = reader.decodeWithState(BinaryBitmap(HybridBinarizer(src))).text
            } catch (e: Exception) { } finally { reader.reset() }
            busy = false
            val t = text
            if (t != null) post { handle(t) }
        }
    }
    private fun handle(t: String) {
        if (found) return
        if (expected.isEmpty() || t == expected) { found = true; ok = 1f; msg = "Code recognised"; releaseCam(); postDelayed({ onFound(t) }, 700) }
        else { msg = "That's not the right code"; wrong = 1f }
    }
    override fun onTouchEvent(e: MotionEvent): Boolean {
        if (e.actionMasked == MotionEvent.ACTION_UP && closeR.contains(e.x, e.y)) { releaseCam(); onClose() }
        return true
    }
    override fun dispatchDraw(c: Canvas) {
        super.dispatchDraw(c)
        val w = width.toFloat(); val h = height.toFloat(); val tt = SystemClock.uptimeMillis() / 1000f
        val dt = if (lastT == 0f) 0f else (tt - lastT).coerceIn(0f, 0.1f); lastT = tt
        wrong = max(0f, wrong - dt * 1.5f)
        val fs = w * 0.68f; val cx = w / 2f; val cy = h * 0.42f
        rc.set(cx - fs / 2f, cy - fs / 2f, cx + fs / 2f, cy + fs / 2f)
        val path = Path(); path.addRect(0f, 0f, w, h, Path.Direction.CW); path.addRoundRect(rc, dp(30), dp(30), Path.Direction.CCW)
        fill.color = 0xB0000814.toInt(); c.drawPath(path, fill)
        val col = if (found) C.GREEN else if (wrong > 0.05f) C.RED else th.c1
        str.color = col; str.strokeCap = Paint.Cap.ROUND; str.strokeWidth = dp(5)
        val L = dp(40)
        for (sx in 0..1) for (sy in 0..1) {
            val x = if (sx == 0) rc.left else rc.right; val y = if (sy == 0) rc.top else rc.bottom
            val dx = if (sx == 0) 1f else -1f; val dy = if (sy == 0) 1f else -1f
            c.drawLine(x, y + dy * dp(14), x, y + dy * L, str); c.drawLine(x + dx * dp(14), y, x + dx * L, y, str)
        }
        if (!found) {
            val y = rc.top + (0.5f + 0.5f * sin(tt * 2.6f)) * rc.height()
            fill.shader = LinearGradient(rc.left, y, rc.right, y, intArrayOf(0, alphaColor(col, 0.9f), 0), floatArrayOf(0f, 0.5f, 1f), Shader.TileMode.CLAMP)
            c.drawRect(rc.left + dp(12), y - dp(2), rc.right - dp(12), y + dp(2), fill); fill.shader = null
        } else { fill.color = alphaColor(C.GREEN, 0.25f); c.drawRoundRect(rc, dp(30), dp(30), fill) }
        closeR.set(dp(16), dp(44), dp(104), dp(84)); fill.color = 0x40000000; c.drawRoundRect(closeR, dp(20), dp(20), fill)
        tp.textSize = dp(14); tp.color = Color.WHITE; c.drawText("\u2039 Back", closeR.centerX(), closeR.centerY() + dp(5), tp)
        tp.textSize = dp(17); tp.color = Color.WHITE; c.drawText(title, cx, rc.bottom + dp(56), tp)
        tp.textSize = dp(14); tp.color = if (wrong > 0.05f) C.RED else 0xCCFFFFFF.toInt()
        c.drawText(if (msg.isNotEmpty()) msg else "Point the camera at your code", cx, rc.bottom + dp(86), tp)
        postInvalidateOnAnimation()
    }
}
