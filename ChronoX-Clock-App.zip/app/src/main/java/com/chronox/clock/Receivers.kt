package com.chronox.clock

import android.app.*
import android.content.*
import android.os.*
import java.util.Calendar

class AlarmReceiver : BroadcastReceiver() {
    override fun onReceive(c: Context, i: Intent) {
        val svc = Intent(c, AlarmService::class.java).setAction(AlarmService.ACTION_RING).putExtras(i)
        c.startForegroundService(svc)
    }
}

class BootReceiver : BroadcastReceiver() {
    override fun onReceive(c: Context, i: Intent) { Scheduler.rescheduleAll(c) }
}

class AlarmService : Service() {
    companion object {
        const val ACTION_RING = "com.chronox.clock.RING"
        const val ACTION_STOP = "com.chronox.clock.STOP"
        const val ACTION_SNOOZE = "com.chronox.clock.SNOOZE"
        const val ACTION_RING_START = "com.chronox.clock.RING_START"
        const val ACTION_RING_END = "com.chronox.clock.RING_END"
        const val CHANNEL = "chronox_alarm"
        const val NOTIF_ID = 4242
    }

    private var player: AlarmPlayer? = null
    private val handler = Handler(Looper.getMainLooper())
    private var type = "alarm"
    private var alarmId = 0
    private var snoozeMin = 5
    private val autoStop = Runnable {
        if (type == "alarm" && snoozeMin > 0) Scheduler.scheduleSnooze(this, alarmId, snoozeMin)
        endRing()
    }

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        when (intent?.action) {
            ACTION_STOP -> endRing()
            ACTION_SNOOZE -> snooze()
            else -> if (intent != null) ring(intent) else stopSelf()
        }
        return START_NOT_STICKY
    }

    private fun ensureChannel() {
        val nm = getSystemService(NotificationManager::class.java)
        if (nm.getNotificationChannel(CHANNEL) == null) {
            val ch = NotificationChannel(CHANNEL, "Alarms & timers", NotificationManager.IMPORTANCE_HIGH)
            ch.setSound(null, null); ch.enableVibration(false); ch.lockscreenVisibility = Notification.VISIBILITY_PUBLIC
            nm.createNotificationChannel(ch)
        }
    }

    private fun ring(i: Intent) {
        ensureChannel()
        type = i.getStringExtra("type") ?: "alarm"
        alarmId = i.getIntExtra("id", 0)
        val isSnooze = i.getBooleanExtra("snooze", false)
        player?.stop()
        val cal = Calendar.getInstance()
        var hour = cal.get(Calendar.HOUR_OF_DAY); var minute = cal.get(Calendar.MINUTE)
        var label = if (type == "timer") "Timer" else "Alarm"
        var sound = 1; var uri: String? = null; var vibe = 1; var gradual = false; var theme = 6

        var a: Alarm? = null
        if (type == "alarm") {
            a = AlarmStore.find(this, alarmId)
            if (a == null) { startForeground(NOTIF_ID, buildNotif(label, "", Intent(this, MainActivity::class.java), 6)); endRing(); return }
            hour = a.hour; minute = a.minute
            if (a.label.isNotBlank()) label = a.label
            sound = a.sound; uri = a.soundUri; vibe = a.vibe; gradual = a.gradual; theme = a.theme; snoozeMin = a.snooze
            if (!isSnooze) {
                if (a.days == 0) { a.enabled = false; AlarmStore.upsert(this, a) } else Scheduler.schedule(this, a)
            }
        } else {
            TimerStore.finish(this)
        }
        val timeText = hm(hour, minute, android.text.format.DateFormat.is24HourFormat(this)) +
            (if (android.text.format.DateFormat.is24HourFormat(this)) "" else " " + ampmOf(hour))
        val ringIntent = Intent(this, AlarmRingActivity::class.java)
            .putExtra("type", type).putExtra("id", alarmId).putExtra("label", label)
            .putExtra("theme", theme).putExtra("snooze", if (type == "timer") 1 else snoozeMin)
            .putExtra("hour", hour).putExtra("minute", minute)
            .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP)
        val n = buildNotif(label, if (type == "timer") "Time is up" else timeText, ringIntent, snoozeMin)
        if (Build.VERSION.SDK_INT >= 29) startForeground(NOTIF_ID, n, android.content.pm.ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PLAYBACK)
        else startForeground(NOTIF_ID, n)

        try { startActivity(ringIntent) } catch (e: Exception) { }
        player = AlarmPlayer(this).also { it.start(sound, uri, gradual, vibe) }
        handler.removeCallbacks(autoStop); handler.postDelayed(autoStop, 5 * 60 * 1000L)
        sendBroadcast(Intent(ACTION_RING_START).setPackage(packageName).putExtras(ringIntent))
    }

    private fun buildNotif(title: String, text: String, ringIntent: Intent, snoozeMinutes: Int): Notification {
        val flags = PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        val full = PendingIntent.getActivity(this, 1, if (ringIntent.component != null) ringIntent else Intent(this, MainActivity::class.java), flags)
        val stop = PendingIntent.getService(this, 2, Intent(this, AlarmService::class.java).setAction(ACTION_STOP), flags)
        val snz = PendingIntent.getService(this, 3, Intent(this, AlarmService::class.java).setAction(ACTION_SNOOZE), flags)
        val b = Notification.Builder(this, CHANNEL)
            .setSmallIcon(R.drawable.ic_notif).setContentTitle(title).setContentText(text)
            .setCategory(Notification.CATEGORY_ALARM).setOngoing(true)
            .setContentIntent(full).setFullScreenIntent(full, true)
            .setVisibility(Notification.VISIBILITY_PUBLIC)
        if (snoozeMinutes > 0 || type == "timer") b.addAction(R.drawable.ic_notif, if (type == "timer") "+1 min" else "Snooze", snz)
        b.addAction(R.drawable.ic_notif, "Dismiss", stop)
        return b.build()
    }

    private fun snooze() {
        if (type == "timer") Scheduler.scheduleTimerAt(this, System.currentTimeMillis() + 60000L)
        else if (snoozeMin > 0) Scheduler.scheduleSnooze(this, alarmId, snoozeMin)
        endRing()
    }

    private fun endRing() {
        handler.removeCallbacks(autoStop)
        player?.stop(); player = null
        sendBroadcast(Intent(ACTION_RING_END).setPackage(packageName))
        stopForeground(STOP_FOREGROUND_REMOVE)
        stopSelf()
    }

    override fun onDestroy() { player?.stop(); super.onDestroy() }
}
