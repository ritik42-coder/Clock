package com.chronox.clock

import android.animation.ValueAnimator
import android.content.Context
import android.graphics.*
import android.os.SystemClock
import android.view.MotionEvent
import android.view.View
import android.view.animation.DecelerateInterpolator
import kotlin.math.*

/** Time-travel slider: drag to move the Earth's day/night (and all world clocks) up to 24 h either side. */
class TimeScrub(ctx: Context, private val onChange: () -> Unit) : View(ctx) {
    private val range = 24L * 3600000L
    var playing = false
    private var dragging = false
    private var lastFrame = 0L
    private var anim: ValueAnimator? = null
    private var lastHour = 0
    private val fill = fillPaint(); private val line = strokePaint(Color.WHITE, dp(2))
    private val tp = textPaint(C.DIM, dp(10.5f), MED, Paint.Align.CENTER); private val lab = textPaint(C.CYAN, dp(13), MED, Paint.Align.CENTER)
    private val pill = textPaint(C.GREEN, dp(12), BOLD, Paint.Align.CENTER)
    private val rect = RectF()

    private fun tl() = dp(74); private fun tr() = width - dp(100)
    private fun thumbX(): Float = tl() + ((Tt.offset + range).toFloat() / (2f * range)) * (tr() - tl())

    override fun onDraw(c: Canvas) {
        val now = SystemClock.uptimeMillis()
        if (playing && !dragging) {
            val dt = if (lastFrame == 0L) 0L else now - lastFrame
            var o = Tt.offset + dt * 3600L; if (o > range) o = -range
            Tt.offset = o; onChange()
        }
        lastFrame = now
        val cy = height / 2f + dp(4)
        // play / pause
        fill.color = C.GLASS2; c.drawCircle(dp(36), cy, dp(22), fill)
        fill.color = C.CYAN
        if (playing) { c.drawRoundRect(dp(29), cy - dp(8), dp(34), cy + dp(8), dp(2), dp(2), fill); c.drawRoundRect(dp(39), cy - dp(8), dp(44), cy + dp(8), dp(2), dp(2), fill) }
        else { val p = Path(); p.moveTo(dp(31), cy - dp(9)); p.lineTo(dp(45), cy); p.lineTo(dp(31), cy + dp(9)); p.close(); c.drawPath(p, fill) }
        // track
        val l = tl(); val r = tr()
        rect.set(l, cy - dp(4), r, cy + dp(4)); fill.color = 0x26FFFFFF; c.drawRoundRect(rect, dp(4), dp(4), fill)
        val mid = (l + r) / 2f; val tx = thumbX()
        rect.set(min(mid, tx), cy - dp(4), max(mid, tx), cy + dp(4))
        fill.shader = LinearGradient(l, 0f, r, 0f, intArrayOf(C.VIOLET, C.CYAN, C.ORANGE), null, Shader.TileMode.CLAMP)
        c.drawRoundRect(rect, dp(4), dp(4), fill); fill.shader = null
        val marks = intArrayOf(-24, -12, 0, 12, 24)
        for (m in marks) {
            val x = l + (m + 24) / 48f * (r - l)
            line.color = 0x44FFFFFF; line.strokeWidth = dp(1.4f); c.drawLine(x, cy + dp(9), x, cy + dp(14), line)
            c.drawText(if (m == 0) "Now" else (if (m > 0) "+${m}h" else "${m}h"), x, cy + dp(28), tp)
        }
        // thumb + label
        fill.color = alphaColor(C.CYAN, 0.28f); c.drawCircle(tx, cy, dp(17), fill)
        fill.color = Color.WHITE; c.drawCircle(tx, cy, dp(9.5f), fill)
        fill.color = C.CYAN; c.drawCircle(tx, cy, dp(5), fill)
        val off = Tt.offset; val am = abs(off) / 60000L
        val txt = if (abs(off) < 30000L) "LIVE" else (if (off > 0) "+" else "-") + (am / 60) + "h " + two((am % 60).toInt()) + "m"
        lab.color = if (abs(off) < 30000L) C.GREEN else C.CYAN
        c.drawText(txt, tx.coerceIn(l + dp(24), r - dp(24)), cy - dp(20), lab)
        // LIVE pill
        rect.set(width - dp(88), cy - dp(17), width - dp(8), cy + dp(17))
        val live = abs(off) < 30000L
        fill.color = if (live) 0x2234F5A5 else 0x14FFFFFF; c.drawRoundRect(rect, dp(17), dp(17), fill)
        line.color = if (live) C.GREEN else 0x55FFFFFF; line.strokeWidth = dp(1.2f); c.drawRoundRect(rect, dp(17), dp(17), line)
        fill.color = if (live) C.GREEN else C.DIM; c.drawCircle(rect.left + dp(16), cy, dp(4.5f) * (if (live) 1f + 0.2f * sin(now / 220f) else 1f), fill)
        pill.color = if (live) C.GREEN else C.DIM; c.drawText("LIVE", rect.centerX() + dp(8), cy + dp(4.5f), pill)
        val hr = (off / 3600000L).toInt(); if (hr != lastHour) { lastHour = hr; if (dragging) tick() }
        if (playing || dragging) postInvalidateOnAnimation()
    }

    private fun setFromX(x: Float) {
        val frac = ((x - tl()) / (tr() - tl())).coerceIn(0f, 1f)
        var o = ((frac * 2f - 1f) * range).toLong()
        if (abs(o) < 15 * 60000L) o = 0L
        Tt.offset = o; onChange(); invalidate()
    }

    override fun onTouchEvent(e: MotionEvent): Boolean {
        when (e.actionMasked) {
            MotionEvent.ACTION_DOWN -> {
                parent?.requestDisallowInterceptTouchEvent(true)
                if (e.x < dp(66)) { playing = !playing; lastFrame = 0L; thud(); invalidate() }
                else if (e.x > width - dp(92)) goLive()
                else { anim?.cancel(); playing = false; dragging = true; setFromX(e.x); invalidate() }
            }
            MotionEvent.ACTION_MOVE -> if (dragging) setFromX(e.x)
            MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> { dragging = false; invalidate() }
        }
        return true
    }

    fun goLive() {
        playing = false; thud(); anim?.cancel()
        anim = animF(Tt.offset.toFloat(), 0f, 600L, DecelerateInterpolator(2f)) { Tt.offset = it.toLong(); onChange(); invalidate() }
    }
}
