package com.chronox.clock

import android.app.AlarmManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import org.json.JSONArray
import org.json.JSONObject
import java.util.Calendar

data class Alarm(
    var id: Int, var hour: Int, var minute: Int, var label: String = "",
    var days: Int = 0, var enabled: Boolean = true,
    var sound: Int = 0, var soundUri: String? = null,
    var vibe: Int = 1, var snooze: Int = 5, var theme: Int = 6, var gradual: Boolean = true,
    var style: Int = 0, var stop: Int = 0, var level: Int = 1, var qr: String = ""
) {
    fun toJson(): JSONObject = JSONObject().put("id", id).put("h", hour).put("m", minute).put("label", label)
        .put("days", days).put("on", enabled).put("sound", sound).put("uri", soundUri ?: "")
        .put("vibe", vibe).put("snooze", snooze).put("theme", theme).put("gradual", gradual)
        .put("style", style).put("stop", stop).put("level", level).put("qr", qr)
    companion object {
        fun fromJson(o: JSONObject) = Alarm(
            o.getInt("id"), o.getInt("h"), o.getInt("m"), o.optString("label", ""),
            o.optInt("days", 0), o.optBoolean("on", true), o.optInt("sound", 0),
            o.optString("uri", "").ifEmpty { null }, o.optInt("vibe", 1), o.optInt("snooze", 5),
            o.optInt("theme", 6), o.optBoolean("gradual", true),
            o.optInt("style", 0), o.optInt("stop", 0), o.optInt("level", 1), o.optString("qr", "")
        )
    }
}

object AlarmStore {
    private fun sp(c: Context) = c.getSharedPreferences("alarms", Context.MODE_PRIVATE)
    fun load(c: Context): MutableList<Alarm> {
        val out = ArrayList<Alarm>()
        try {
            val arr = JSONArray(sp(c).getString("list", "[]") ?: "[]")
            for (i in 0 until arr.length()) out.add(Alarm.fromJson(arr.getJSONObject(i)))
        } catch (e: Exception) { }
        return out
    }
    fun save(c: Context, list: List<Alarm>) {
        val arr = JSONArray(); list.forEach { arr.put(it.toJson()) }
        sp(c).edit().putString("list", arr.toString()).apply()
    }
    fun nextId(c: Context): Int { val n = sp(c).getInt("nid", 1); sp(c).edit().putInt("nid", n + 1).apply(); return n }
    fun find(c: Context, id: Int): Alarm? = load(c).firstOrNull { it.id == id }
    fun upsert(c: Context, a: Alarm) {
        val l = load(c); val i = l.indexOfFirst { it.id == a.id }
        if (i >= 0) l[i] = a else l.add(a)
        save(c, l)
    }
    fun remove(c: Context, id: Int) { save(c, load(c).filter { it.id != id }) }
}

object Scheduler {
    fun nextTrigger(a: Alarm, from: Long = System.currentTimeMillis()): Long {
        val cal = Calendar.getInstance()
        for (add in 0..7) {
            cal.timeInMillis = from
            cal.add(Calendar.DAY_OF_YEAR, add)
            cal.set(Calendar.HOUR_OF_DAY, a.hour); cal.set(Calendar.MINUTE, a.minute)
            cal.set(Calendar.SECOND, 0); cal.set(Calendar.MILLISECOND, 0)
            if (cal.timeInMillis <= from) continue
            if (a.days == 0) return cal.timeInMillis
            val bit = (cal.get(Calendar.DAY_OF_WEEK) + 5) % 7
            if ((a.days and (1 shl bit)) != 0) return cal.timeInMillis
        }
        return from + 86400000L
    }

    private fun pi(ctx: Context, code: Int, type: String, id: Int, snooze: Boolean): PendingIntent {
        val i = Intent(ctx, AlarmReceiver::class.java).setAction("com.chronox.clock.FIRE")
            .putExtra("type", type).putExtra("id", id).putExtra("snooze", snooze)
        return PendingIntent.getBroadcast(ctx, code, i, PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
    }
    private fun showPi(ctx: Context): PendingIntent =
        PendingIntent.getActivity(ctx, 0, Intent(ctx, MainActivity::class.java), PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
    private fun am(ctx: Context) = ctx.getSystemService(Context.ALARM_SERVICE) as AlarmManager
    private fun setClock(ctx: Context, whenMs: Long, p: PendingIntent) {
        val m = am(ctx)
        try { m.setAlarmClock(AlarmManager.AlarmClockInfo(whenMs, showPi(ctx)), p) }
        catch (e: SecurityException) {
            try { m.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, whenMs, p) } catch (e2: Exception) { }
        } catch (e: Exception) { }
    }

    fun schedule(ctx: Context, a: Alarm) {
        if (!a.enabled) { cancel(ctx, a); return }
        setClock(ctx, nextTrigger(a), pi(ctx, a.id, "alarm", a.id, false))
    }
    fun cancel(ctx: Context, a: Alarm) {
        am(ctx).cancel(pi(ctx, a.id, "alarm", a.id, false))
        am(ctx).cancel(pi(ctx, 1_000_000 + a.id, "alarm", a.id, true))
    }
    fun scheduleSnooze(ctx: Context, id: Int, minutes: Int) {
        val t = System.currentTimeMillis() + minutes * 60000L
        setClock(ctx, t, pi(ctx, 1_000_000 + id, "alarm", id, true))
    }
    fun scheduleTimerAt(ctx: Context, whenMs: Long) {
        setClock(ctx, whenMs, pi(ctx, 2_000_000, "timer", 0, false))
    }
    fun cancelTimer(ctx: Context) { am(ctx).cancel(pi(ctx, 2_000_000, "timer", 0, false)) }
    fun rescheduleAll(ctx: Context) {
        AlarmStore.load(ctx).filter { it.enabled }.forEach { schedule(ctx, it) }
        if (TimerStore.state(ctx) == TimerStore.RUNNING) {
            val end = TimerStore.end(ctx)
            if (end > System.currentTimeMillis()) scheduleTimerAt(ctx, end)
        }
    }
    fun nextEnabled(ctx: Context): Long? =
        AlarmStore.load(ctx).filter { it.enabled }.map { nextTrigger(it) }.minOrNull()
}

object TimerStore {
    const val IDLE = 0; const val RUNNING = 1; const val PAUSED = 2
    private fun sp(c: Context) = c.getSharedPreferences("timer", Context.MODE_PRIVATE)
    fun state(c: Context) = sp(c).getInt("state", IDLE)
    fun total(c: Context) = sp(c).getLong("total", 0L)
    fun end(c: Context) = sp(c).getLong("end", 0L)
    fun lastSet(c: Context) = sp(c).getLong("last", 300000L)
    fun setLast(c: Context, ms: Long) { sp(c).edit().putLong("last", ms).apply() }
    fun remaining(c: Context): Long = when (state(c)) {
        RUNNING -> maxOf(0L, end(c) - System.currentTimeMillis())
        PAUSED -> sp(c).getLong("rem", 0L)
        else -> 0L
    }
    fun start(c: Context, ms: Long) {
        val now = System.currentTimeMillis()
        sp(c).edit().putInt("state", RUNNING).putLong("total", ms).putLong("end", now + ms).apply()
        Scheduler.scheduleTimerAt(c, now + ms)
    }
    fun pause(c: Context) {
        val r = remaining(c)
        sp(c).edit().putInt("state", PAUSED).putLong("rem", r).apply()
        Scheduler.cancelTimer(c)
    }
    fun resume(c: Context) {
        val now = System.currentTimeMillis(); val r = sp(c).getLong("rem", 0L)
        sp(c).edit().putInt("state", RUNNING).putLong("end", now + r).apply()
        Scheduler.scheduleTimerAt(c, now + r)
    }
    fun reset(c: Context) { sp(c).edit().putInt("state", IDLE).apply(); Scheduler.cancelTimer(c) }
    fun addMs(c: Context, ms: Long) {
        when (state(c)) {
            RUNNING -> { val e = end(c) + ms; sp(c).edit().putLong("end", e).putLong("total", total(c) + ms).apply(); Scheduler.scheduleTimerAt(c, e) }
            PAUSED -> sp(c).edit().putLong("rem", sp(c).getLong("rem", 0L) + ms).putLong("total", total(c) + ms).apply()
        }
    }
    fun finish(c: Context) { sp(c).edit().putInt("state", IDLE).apply() }
}

object StopwatchStore {
    private fun sp(c: Context) = c.getSharedPreferences("stopwatch", Context.MODE_PRIVATE)
    fun running(c: Context) = sp(c).getBoolean("run", false)
    fun elapsed(c: Context): Long {
        val s = sp(c)
        return s.getLong("acc", 0L) + if (s.getBoolean("run", false)) System.currentTimeMillis() - s.getLong("start", 0L) else 0L
    }
    fun toggle(c: Context): Boolean {
        val s = sp(c)
        if (s.getBoolean("run", false)) {
            s.edit().putLong("acc", elapsed(c)).putBoolean("run", false).apply(); return false
        }
        s.edit().putLong("start", System.currentTimeMillis()).putBoolean("run", true).apply(); return true
    }
    fun reset(c: Context) { sp(c).edit().putLong("acc", 0L).putBoolean("run", false).putString("laps", "").apply() }
    fun laps(c: Context): MutableList<Long> =
        (sp(c).getString("laps", "") ?: "").split(",").filter { it.isNotEmpty() }.map { it.toLong() }.toMutableList()
    fun addLap(c: Context): Long {
        val l = laps(c); val e = elapsed(c); l.add(e)
        sp(c).edit().putString("laps", l.joinToString(",")).apply(); return e
    }
}

data class City(val name: String, val country: String, val tz: String, val lat: Double, val lon: Double)

object Cities {
    val ALL = listOf(
        City("New York", "United States", "America/New_York", 40.71, -74.01),
        City("Los Angeles", "United States", "America/Los_Angeles", 34.05, -118.24),
        City("Chicago", "United States", "America/Chicago", 41.88, -87.63),
        City("Denver", "United States", "America/Denver", 39.74, -104.99),
        City("Toronto", "Canada", "America/Toronto", 43.65, -79.38),
        City("Vancouver", "Canada", "America/Vancouver", 49.28, -123.12),
        City("Mexico City", "Mexico", "America/Mexico_City", 19.43, -99.13),
        City("Anchorage", "United States", "America/Anchorage", 61.22, -149.90),
        City("Honolulu", "United States", "Pacific/Honolulu", 21.31, -157.86),
        City("S\u00e3o Paulo", "Brazil", "America/Sao_Paulo", -23.55, -46.63),
        City("Buenos Aires", "Argentina", "America/Argentina/Buenos_Aires", -34.60, -58.38),
        City("Bogot\u00e1", "Colombia", "America/Bogota", 4.71, -74.07),
        City("Lima", "Peru", "America/Lima", -12.05, -77.04),
        City("Santiago", "Chile", "America/Santiago", -33.45, -70.67),
        City("Reykjav\u00edk", "Iceland", "Atlantic/Reykjavik", 64.15, -21.94),
        City("London", "United Kingdom", "Europe/London", 51.51, -0.13),
        City("Paris", "France", "Europe/Paris", 48.86, 2.35),
        City("Berlin", "Germany", "Europe/Berlin", 52.52, 13.40),
        City("Madrid", "Spain", "Europe/Madrid", 40.42, -3.70),
        City("Rome", "Italy", "Europe/Rome", 41.90, 12.50),
        City("Moscow", "Russia", "Europe/Moscow", 55.76, 37.62),
        City("Istanbul", "Turkey", "Europe/Istanbul", 41.01, 28.98),
        City("Cairo", "Egypt", "Africa/Cairo", 30.04, 31.24),
        City("Lagos", "Nigeria", "Africa/Lagos", 6.52, 3.38),
        City("Nairobi", "Kenya", "Africa/Nairobi", -1.29, 36.82),
        City("Johannesburg", "South Africa", "Africa/Johannesburg", -26.20, 28.05),
        City("Dubai", "UAE", "Asia/Dubai", 25.20, 55.27),
        City("Riyadh", "Saudi Arabia", "Asia/Riyadh", 24.71, 46.68),
        City("Tehran", "Iran", "Asia/Tehran", 35.69, 51.39),
        City("Karachi", "Pakistan", "Asia/Karachi", 24.86, 67.01),
        City("New Delhi", "India", "Asia/Kolkata", 28.61, 77.21),
        City("Mumbai", "India", "Asia/Kolkata", 19.08, 72.88),
        City("Dhaka", "Bangladesh", "Asia/Dhaka", 23.81, 90.41),
        City("Kathmandu", "Nepal", "Asia/Kathmandu", 27.72, 85.32),
        City("Colombo", "Sri Lanka", "Asia/Colombo", 6.93, 79.86),
        City("Bangkok", "Thailand", "Asia/Bangkok", 13.76, 100.50),
        City("Jakarta", "Indonesia", "Asia/Jakarta", -6.21, 106.85),
        City("Singapore", "Singapore", "Asia/Singapore", 1.35, 103.82),
        City("Hong Kong", "China", "Asia/Hong_Kong", 22.32, 114.17),
        City("Beijing", "China", "Asia/Shanghai", 39.90, 116.41),
        City("Seoul", "South Korea", "Asia/Seoul", 37.57, 126.98),
        City("Tokyo", "Japan", "Asia/Tokyo", 35.68, 139.69),
        City("Manila", "Philippines", "Asia/Manila", 14.60, 120.98),
        City("Perth", "Australia", "Australia/Perth", -31.95, 115.86),
        City("Sydney", "Australia", "Australia/Sydney", -33.87, 151.21),
        City("Auckland", "New Zealand", "Pacific/Auckland", -36.85, 174.76)
    )
    private val DEFAULT = listOf("New York", "London", "Dubai", "Tokyo", "Sydney", "Los Angeles")
    private fun sp(c: Context) = c.getSharedPreferences("world", Context.MODE_PRIVATE)
    fun saved(c: Context): MutableList<City> {
        val s = sp(c).getString("cities", null)
        val names = if (s == null) DEFAULT else s.split("|").filter { it.isNotEmpty() }
        return names.mapNotNull { n -> ALL.firstOrNull { it.name == n } }.toMutableList()
    }
    fun save(c: Context, l: List<City>) { sp(c).edit().putString("cities", l.joinToString("|") { it.name }).apply() }
    /** best-guess position for the device's own time zone */
    fun localCity(): City {
        val tz = java.util.TimeZone.getDefault()
        ALL.firstOrNull { it.tz == tz.id }?.let { return it }
        val off = tz.rawOffset / 3600000.0
        return City("Local", "", tz.id, 22.0, (off * 15.0).coerceIn(-180.0, 180.0))
    }
}
