package com.chronox.clock

import android.content.Context
import android.graphics.*
import android.os.SystemClock
import android.view.GestureDetector
import android.view.MotionEvent
import android.view.ScaleGestureDetector
import android.view.View
import java.util.Date
import kotlin.math.*

private class SphereJob(val idx: Int, val size: Int, val ax: Float, val ay: Float, val az: Float, val spin: Float, val lx: Float, val ly: Float, val lz: Float)
private class DB(val kind: Int, val id: Int) { var wx = 0f; var wy = 0f; var wz = 0f; var sx = 0f; var sy = 0f; var zf = 0f; var sr = 0f; var rW = 0f }

class SolarView(ctx: Context) : View(ctx) {
    var onSpeedAuto: ((Int) -> Unit)? = null
    var onExit: (() -> Unit)? = null
    var bottomPad = dp(236)
    @Volatile var daysPerSec = 7.0
    @Volatile var playing = true
    private var userSpeed = false
    var showOrbits = true; var showLabels = true; var showMoons = true; var showBelt = true
    var trueScale = false
        set(v) { field = v; orbitDirty = true; if (focus < 0) { distTarget = overviewDist(); startFrom() } }

    private var simDays = (System.currentTimeMillis() / 86400000.0 + 2440587.5) - 2451545.0
    private var yaw = 0.9f; private var pitch = 0.62f
    private var camDist = 13f; private var distTarget = 13f; private var startLog = ln(13f)
    private var transT = 1f
    private var tgx = 0f; private var tgy = 0f; private var tgz = 0f; private var stx = 0f; private var sty = 0f; private var stz = 0f
    private var focus = -1
    private var velYaw = 0f; private var velPitch = 0f; private var lastDx = 0f; private var lastDy = 0f
    private var lastT = 0L; private var lastTouch = 0L; private var touching = false
    private var downX = 0f; private var downY = 0f; private var moved = 0f; private var downT = 0L

    private val bx = FloatArray(9); private val by = FloatArray(9); private val bz = FloatArray(9); private val helioR = DoubleArray(9)
    private val tmpD = DoubleArray(3); private val tmpF = FloatArray(3); private val pole = FloatArray(3)
    private val orbit = Array(9) { FloatArray(129 * 3) }
    private var orbitDirty = true; private var orbitDay = 0.0
    private val lineBuf = FloatArray(129 * 4)
    private val BELT = 520
    private val beltA = FloatArray(BELT); private val beltPh = FloatArray(BELT); private val beltZ = FloatArray(BELT); private val beltBuf = FloatArray(BELT * 2)
    private val starV = FloatArray(300 * 3); private val starS = FloatArray(300); private val starP = FloatArray(300)
    private val milky = FloatArray(170 * 3)

    private var camX = 0f; private var camY = 0f; private var camZ = 0f
    private var fx = 0f; private var fy = 0f; private var fz = 0f
    private var rx = 0f; private var ry = 0f; private var rz = 0f
    private var ux = 0f; private var uy = 0f; private var uz = 0f
    private var F = 1f; private var cxv = 0f; private var cyv = 0f; private var vw = 0f; private var vh = 0f
    private val pj = FloatArray(3)
    private var sunSx = 0f; private var sunSy = 0f; private var sunVis = false

    private val sunDB = DB(0, 0)
    private val planetDB = Array(9) { DB(1, it) }
    private val moonDB = Array(Solar.MOONS.size) { DB(2, it) }
    private val hits = ArrayList<DB>()
    private val placed = ArrayList<RectF>()

    private val fill = fillPaint(); private val line = strokePaint(Color.WHITE, dp(1.2f)).apply { strokeCap = Paint.Cap.ROUND }
    private val ringPaint = strokePaint(Color.WHITE, dp(2)).apply { strokeJoin = Paint.Join.ROUND }
    private val txt = textPaint(Color.WHITE, dp(11), MED, Paint.Align.LEFT)
    private val txtS = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.STROKE; color = 0xCC000814.toInt(); strokeWidth = dp(2.4f); typeface = MED; textSize = dp(11); strokeJoin = Paint.Join.ROUND }
    private val bmpPaint = Paint(Paint.FILTER_BITMAP_FLAG or Paint.ANTI_ALIAS_FLAG)
    private val glowPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { xfermode = PorterDuffXfermode(PorterDuff.Mode.SCREEN) }
    private val moonPaints = Array(Solar.MOONS.size) { Paint(Paint.FILTER_BITMAP_FLAG or Paint.ANTI_ALIAS_FLAG).apply { colorFilter = PorterDuffColorFilter(alphaColor(Solar.MOONS[it].color, 0.5f), PorterDuff.Mode.SRC_ATOP) } }
    private val ringBand1 = floatArrayOf(1.24f, 1.55f, 2.03f); private val ringBand2 = floatArrayOf(1.52f, 1.98f, 2.27f)
    private val ringCol = intArrayOf(0x66B8A488, 0xE0E6D2A8.toInt(), 0xB8CDB894.toInt())
    private val path = Path(); private val dst = RectF(); private val card = RectF(); private val backR = RectF(); private val sysR = RectF()
    private val df = java.text.SimpleDateFormat("d MMM yyyy  HH:mm", java.util.Locale.getDefault())

    // live sphere renderer
    @Volatile private var job: SphereJob? = null
    @Volatile private var running = false
    private var thread: Thread? = null
    private var liveFront: Bitmap? = null; private var liveBack: Bitmap? = null
    @Volatile private var liveIdx = -1
    private val liveLock = Any()
    private val livePx = IntArray(344 * 344)
    private var earthUp = false

    private val scaleDet = ScaleGestureDetector(ctx, object : ScaleGestureDetector.SimpleOnScaleGestureListener() {
        override fun onScale(d: ScaleGestureDetector): Boolean {
            distTarget = clampDist(distTarget / d.scaleFactor)
            if (transT >= 1f) { camDist = distTarget; startLog = ln(distTarget) }
            return true
        }
    })
    private val gestDet = GestureDetector(ctx, object : GestureDetector.SimpleOnGestureListener() {
        override fun onDown(e: MotionEvent): Boolean = true
        override fun onDoubleTap(e: MotionEvent): Boolean { goOverview(); thud(); return true }
    })

    init {
        val r = java.util.Random(17)
        for (i in 0 until 300) {
            val a = r.nextFloat() * 6.2832f; val z = r.nextFloat() * 2f - 1f; val s = sqrt(1f - z * z)
            starV[i * 3] = s * cos(a); starV[i * 3 + 1] = s * sin(a); starV[i * 3 + 2] = z
            starS[i] = 0.5f + r.nextFloat() * r.nextFloat() * 2.2f; starP[i] = r.nextFloat() * 6.28f
        }
        for (i in 0 until 170) {
            val a = r.nextFloat() * 6.2832f; val off = (r.nextFloat() - 0.5f) * (r.nextFloat() - 0.5f) * 0.9f
            val x = cos(a); val y = sin(a) * 0.5f - off * 0.87f; val z = sin(a) * 0.87f + off * 0.5f
            val l = sqrt(x * x + y * y + z * z); milky[i * 3] = x / l; milky[i * 3 + 1] = y / l; milky[i * 3 + 2] = z / l
        }
        for (i in 0 until BELT) { beltA[i] = 2.15f + r.nextFloat() * 1.15f; beltPh[i] = r.nextFloat() * 6.2832f; beltZ[i] = (r.nextFloat() - 0.5f) * 0.1f }
    }

    // ------------------------------------------------------------------ control API
    private fun overviewDist() = if (trueScale) 70f else 13f
    private fun clampDist(d: Float): Float {
        val mn = if (focus >= 1) Solar.dispR(focus) * 2.2f else if (focus == 0) 0.35f else 1.5f
        val mx = if (trueScale) 140f else 26f
        return d.coerceIn(mn, mx)
    }
    private fun startFrom() { stx = tgx; sty = tgy; stz = tgz; startLog = ln(camDist); transT = 0f }
    fun focusOn(i: Int) {
        if (i == focus) return
        focus = i; startFrom()
        distTarget = Solar.dispR(i) * Solar.focusMult(i)
        autoSpeed()
    }
    fun goOverview() { if (focus == -1) return; focus = -1; distTarget = overviewDist(); startFrom(); autoSpeed() }
    private fun autoSpeed() {
        if (userSpeed) return
        val idx = if (focus >= 1) 2 else if (focus == 0) 3 else 4
        daysPerSec = Solar.SPEEDS[idx]; onSpeedAuto?.invoke(idx)
    }
    fun setSpeedIndex(i: Int) { userSpeed = true; daysPerSec = Solar.SPEEDS[i.coerceIn(0, Solar.SPEEDS.size - 1)] }
    fun today() { simDays = (System.currentTimeMillis() / 86400000.0 + 2440587.5) - 2451545.0 }

    fun start() {
        if (running) return
        running = true; SolarTex.ensure(); Planet.ensure()
        thread = Thread {
            while (running) {
                val t0 = SystemClock.uptimeMillis()
                if (SolarTex.ready && Planet.ready && !earthUp) { try { SolarTex.makeSprite(3) } catch (e: Throwable) { }; earthUp = true }
                val j = job
                if (j == null || !SolarTex.ready) { try { Thread.sleep(30) } catch (e: InterruptedException) { }; continue }
                SphereR.render(livePx, j.size, j.idx, j.ax, j.ay, j.az, j.spin, j.lx, j.ly, j.lz)
                var b = liveBack
                if (b == null || b.width != j.size) { b = Bitmap.createBitmap(j.size, j.size, Bitmap.Config.ARGB_8888); liveBack = b }
                b.setPixels(livePx, 0, j.size, 0, 0, j.size, j.size)
                synchronized(liveLock) { val t = liveFront; liveFront = b; liveBack = t; liveIdx = j.idx }
                postInvalidateOnAnimation()
                val spent = SystemClock.uptimeMillis() - t0
                if (spent < 30) try { Thread.sleep(30 - spent) } catch (e: InterruptedException) { }
            }
        }.also { it.priority = Thread.NORM_PRIORITY - 1; it.start() }
        invalidate()
    }
    fun stop() { running = false; thread?.interrupt(); thread = null }
    override fun onDetachedFromWindow() { stop(); super.onDetachedFromWindow() }

    // ------------------------------------------------------------------ math helpers
    private fun comp(x: Double, y: Double, z: Double) {
        val r = sqrt(x * x + y * y + z * z); val k = if (trueScale || r < 1e-9) 1.0 else 1.0 / sqrt(r)
        tmpF[0] = (x * k).toFloat(); tmpF[1] = (y * k).toFloat(); tmpF[2] = (z * k).toFloat()
    }
    private fun proj(x: Float, y: Float, z: Float): Boolean {
        val dx = x - camX; val dy = y - camY; val dz = z - camZ
        val zf = dx * fx + dy * fy + dz * fz
        if (zf < 0.012f) return false
        pj[0] = cxv + F * (dx * rx + dy * ry) / zf; pj[1] = cyv - F * (dx * ux + dy * uy + dz * uz) / zf; pj[2] = zf
        return true
    }
    private fun ease(t: Float): Float = if (t < 0.5f) 4f * t * t * t else { val q = -2f * t + 2f; 1f - q * q * q / 2f }
    private fun updatePositions() {
        for (i in 1..8) {
            Solar.helio(i, simDays, tmpD); helioR[i] = sqrt(tmpD[0] * tmpD[0] + tmpD[1] * tmpD[1] + tmpD[2] * tmpD[2])
            comp(tmpD[0], tmpD[1], tmpD[2]); bx[i] = tmpF[0]; by[i] = tmpF[1]; bz[i] = tmpF[2]
        }
    }
    private fun ensureOrbits() {
        if (!orbitDirty && abs(simDays - orbitDay) < 1500.0) return
        for (i in 1..8) for (k in 0..128) {
            Solar.helio(i, simDays, tmpD, 2 * PI * k / 128.0); comp(tmpD[0], tmpD[1], tmpD[2])
            orbit[i][k * 3] = tmpF[0]; orbit[i][k * 3 + 1] = tmpF[1]; orbit[i][k * 3 + 2] = tmpF[2]
        }
        orbitDirty = false; orbitDay = simDays
    }
    private fun minPx(i: Int): Float = if (i == 0) dp(15) else dp(6f + 3.2f * sqrt(Solar.R_KM[i] / 6371f))

    // ------------------------------------------------------------------ drawing
    override fun onDraw(c: Canvas) {
        vw = width.toFloat(); vh = height.toFloat()
        val now = SystemClock.uptimeMillis(); val dt = if (lastT == 0L) 0f else ((now - lastT) / 1000f).coerceAtMost(0.1f); lastT = now
        val tt = now / 1000f
        c.drawColor(0xFF02030A.toInt())
        cxv = vw / 2f; cyv = (dp(96) + vh - bottomPad) / 2f; F = min(vw, vh) * 1.25f
        if (!SolarTex.ready) {
            fill.color = 0xFF02030A.toInt()
            for (i in 0 until 120) { fill.color = alphaColor(Color.WHITE, 0.2f + 0.5f * (0.5f + 0.5f * sin(tt * 1.5f + i))); c.drawCircle(((i * 7919) % 1000) / 1000f * vw, ((i * 104729) % 1000) / 1000f * vh, dp(1.2f), fill) }
            line.color = C.CYAN; line.strokeWidth = dp(4); dst.set(vw / 2f - dp(30), vh / 2f - dp(30), vw / 2f + dp(30), vh / 2f + dp(30))
            c.drawArc(dst, tt * 300f, 100f, false, line)
            txt.textAlign = Paint.Align.CENTER; txt.color = 0xCCFFFFFF.toInt(); txt.textSize = dp(14); c.drawText("Preparing the solar system\u2026", vw / 2f, vh / 2f + dp(66), txt)
            txt.textAlign = Paint.Align.LEFT; txt.textSize = dp(11)
            drawHud(c, tt)
            postInvalidateOnAnimation(); return
        }
        if (playing) simDays = (simDays + dt * daysPerSec).coerceIn(-70000.0, 45000.0)
        if (!touching) {
            yaw += velYaw * dt; pitch = (pitch + velPitch * dt).coerceIn(-1.5f, 1.5f)
            val dec = exp(-dt * 3f); velYaw *= dec; velPitch *= dec
            if (abs(velYaw) < 0.02f && now - lastTouch > 4000L) yaw += 0.035f * dt
        }
        updatePositions(); ensureOrbits()
        if (transT < 1f) transT = min(1f, transT + dt / 1.7f)
        val e = ease(transT)
        val dxT = if (focus >= 1) bx[focus] else 0f; val dyT = if (focus >= 1) by[focus] else 0f; val dzT = if (focus >= 1) bz[focus] else 0f
        tgx = stx + (dxT - stx) * e; tgy = sty + (dyT - sty) * e; tgz = stz + (dzT - stz) * e
        camDist = exp(startLog + (ln(distTarget) - startLog) * e)
        val cp = cos(pitch)
        camX = tgx + camDist * cp * cos(yaw); camY = tgy + camDist * cp * sin(yaw); camZ = tgz + camDist * sin(pitch)
        fx = -cp * cos(yaw); fy = -cp * sin(yaw); fz = -sin(pitch)
        var rxv = fy; var ryv = -fx; val rl = max(1e-4f, sqrt(rxv * rxv + ryv * ryv)); rx = rxv / rl; ry = ryv / rl; rz = 0f
        ux = ry * fz - rz * fy; uy = rz * fx - rx * fz; uz = rx * fy - ry * fx

        drawStars(c, tt)
        val nearFade = (camDist / 1.4f).coerceIn(0f, 1f)
        if (showOrbits) drawOrbits(c, nearFade)
        drawTrails(c, nearFade)
        if (showBelt) drawBelt(c)
        computeItems()
        drawSunGlow(c, tt)
        val list = ArrayList<DB>()
        if (sunDB.zf > 0f) list.add(sunDB)
        for (i in 1..8) if (planetDB[i].zf > 0f) list.add(planetDB[i])
        for (m in moonDB) if (m.zf > 0f) list.add(m)
        list.sortByDescending { it.zf }
        hits.clear()
        for (d in list) {
            when (d.kind) { 0 -> drawSun(c, d, tt); 1 -> { drawPlanet(c, d, tt); hits.add(d) }; else -> drawMoon(c, d) }
            if (d.kind == 0) hits.add(d)
        }
        updateJob()
        if (showLabels) drawLabels(c)
        drawFlare(c)
        drawHud(c, tt)
        if (focus >= 0) drawCard(c, tt)
        postInvalidateOnAnimation()
    }

    private fun drawStars(c: Canvas, tt: Float) {
        for (i in 0 until 170) {
            val dx = milky[i * 3]; val dy = milky[i * 3 + 1]; val dz = milky[i * 3 + 2]
            val zf = dx * fx + dy * fy + dz * fz; if (zf < 0.25f) continue
            val sx = cxv + F * (dx * rx + dy * ry) / zf; val sy = cyv - F * (dx * ux + dy * uy + dz * uz) / zf
            if (sx < -dp(40) || sx > vw + dp(40) || sy < -dp(40) || sy > vh + dp(40)) continue
            fill.color = if (i % 3 == 0) 0x0F9FB8FF else 0x0FFFD9B0; c.drawCircle(sx, sy, dp(16f + (i % 5) * 5f), fill)
        }
        for (i in 0 until 300) {
            val dx = starV[i * 3]; val dy = starV[i * 3 + 1]; val dz = starV[i * 3 + 2]
            val zf = dx * fx + dy * fy + dz * fz; if (zf < 0.25f) continue
            val sx = cxv + F * (dx * rx + dy * ry) / zf; val sy = cyv - F * (dx * ux + dy * uy + dz * uz) / zf
            if (sx < 0 || sx > vw || sy < 0 || sy > vh) continue
            fill.color = alphaColor(Color.WHITE, 0.30f + 0.6f * (0.5f + 0.5f * sin(tt * (0.8f + starS[i]) + starP[i])) * 0.85f)
            c.drawCircle(sx, sy, dp(starS[i] * 0.6f), fill)
        }
    }

    private fun drawOrbits(c: Canvas, nearFade: Float) {
        for (i in 1..8) {
            var n = 0; var px = 0f; var py = 0f; var ok = false
            for (k in 0..128) {
                val good = proj(orbit[i][k * 3], orbit[i][k * 3 + 1], orbit[i][k * 3 + 2])
                if (good && ok) { lineBuf[n * 4] = px; lineBuf[n * 4 + 1] = py; lineBuf[n * 4 + 2] = pj[0]; lineBuf[n * 4 + 3] = pj[1]; n++ }
                ok = good; px = pj[0]; py = pj[1]
            }
            val hi = if (focus == i) 0.7f else 0.26f
            line.color = alphaColor(Solar.COL[i], hi * nearFade); line.strokeWidth = dp(if (focus == i) 1.6f else 1.1f)
            c.drawLines(lineBuf, 0, n * 4, line)
        }
    }

    private fun drawTrails(c: Canvas, nearFade: Float) {
        for (i in 1..8) {
            val step = Solar.YEAR_D[i] / 150.0
            var px = 0f; var py = 0f; var ok = false
            for (k in 0..22) {
                Solar.helio(i, simDays - k * step, tmpD); comp(tmpD[0], tmpD[1], tmpD[2])
                val good = proj(tmpF[0], tmpF[1], tmpF[2])
                if (good && ok) {
                    val a = (1f - k / 23f); line.color = alphaColor(Solar.COL[i], 0.75f * a * a * nearFade); line.strokeWidth = dp(0.8f + 2.2f * a)
                    c.drawLine(px, py, pj[0], pj[1], line)
                }
                ok = good; px = pj[0]; py = pj[1]
            }
        }
    }

    private fun drawBelt(c: Canvas) {
        var n = 0
        for (j in 0 until BELT) {
            val a = beltPh[j] + 2.0 * PI * simDays / (365.25 * beltA[j].toDouble().pow(1.5))
            comp(beltA[j] * cos(a), beltA[j] * sin(a), beltZ[j].toDouble())
            if (proj(tmpF[0], tmpF[1], tmpF[2])) { beltBuf[n * 2] = pj[0]; beltBuf[n * 2 + 1] = pj[1]; n++ }
        }
        line.color = 0x88B8AFA3.toInt(); line.strokeWidth = dp(1.5f); c.drawPoints(beltBuf, 0, n * 2, line)
    }

    private fun computeItems() {
        // sun
        sunDB.wx = 0f; sunDB.wy = 0f; sunDB.wz = 0f; sunDB.rW = Solar.dispR(0)
        if (proj(0f, 0f, 0f)) { sunDB.sx = pj[0]; sunDB.sy = pj[1]; sunDB.zf = pj[2]; sunDB.sr = max(F * sunDB.rW / pj[2], minPx(0)); sunVis = true } else { sunDB.zf = 0f; sunVis = false }
        sunSx = sunDB.sx; sunSy = sunDB.sy
        for (i in 1..8) {
            val d = planetDB[i]; d.wx = bx[i]; d.wy = by[i]; d.wz = bz[i]; d.rW = Solar.dispR(i)
            if (proj(d.wx, d.wy, d.wz)) { d.sx = pj[0]; d.sy = pj[1]; d.zf = pj[2]; d.sr = max(F * d.rW / pj[2], minPx(i)).coerceAtMost(6000f) } else d.zf = 0f
        }
        for (k in Solar.MOONS.indices) {
            val m = Solar.MOONS[k]; val d = moonDB[k]; val p = planetDB[m.parent]
            if (!showMoons || p.zf <= 0f || (p.sr < dp(22) && focus != m.parent)) { d.zf = 0f; continue }
            val a = m.phase0 + 2.0 * PI * simDays / m.periodD
            val rr = Solar.dispR(m.parent) * m.orbitMult; val ci = cos(Math.toRadians(m.incl.toDouble())); val si = sin(Math.toRadians(m.incl.toDouble()))
            d.wx = p.wx + (cos(a) * rr).toFloat(); d.wy = p.wy + (sin(a) * ci * rr).toFloat(); d.wz = p.wz + (sin(a) * si * rr).toFloat()
            d.rW = Solar.dispR(m.parent) * m.sizeRatio
            if (proj(d.wx, d.wy, d.wz)) { d.sx = pj[0]; d.sy = pj[1]; d.zf = pj[2]; d.sr = max(F * d.rW / pj[2], dp(2.6f)) } else d.zf = 0f
        }
    }

    private fun drawSunGlow(c: Canvas, tt: Float) {
        if (!sunVis) return
        val sr = sunDB.sr; val pulse = 1f + 0.04f * sin(tt * 2f)
        val r1 = min(sr * 9f * pulse, vw * 3f)
        glowPaint.shader = RadialGradient(sunSx, sunSy, r1, intArrayOf(0x66FFA030, 0x22FF7A18, 0), floatArrayOf(0f, 0.35f, 1f), Shader.TileMode.CLAMP)
        c.drawCircle(sunSx, sunSy, r1, glowPaint)
        val r2 = min(sr * 3.4f, vw * 2f)
        glowPaint.shader = RadialGradient(sunSx, sunSy, r2, intArrayOf(0xBBFFD27A.toInt(), 0x55FFB04A, 0), floatArrayOf(0f, 0.5f, 1f), Shader.TileMode.CLAMP)
        c.drawCircle(sunSx, sunSy, r2, glowPaint)
        for (k in 0 until 26) {
            val a = tt * 0.12f + k * 0.2417f; val l = sr * (1.9f + 1.5f * (0.5f + 0.5f * sin(tt * 1.3f + k * 2.1f)))
            line.color = 0x30FFE6A8; line.strokeWidth = dp(1.4f)
            c.drawLine(sunSx + cos(a) * sr * 1.1f, sunSy + sin(a) * sr * 1.1f, sunSx + cos(a) * l, sunSy + sin(a) * l, line)
        }
        glowPaint.shader = null
    }

    private fun spriteRot(d: DB): Float {
        if (!sunVis) return 0f
        return Math.toDegrees((atan2(sunSy - d.sy, sunSx - d.sx) - atan2(-0.6f, -0.55f)).toDouble()).toFloat()
    }
    private fun drawSprite(c: Canvas, bmp: Bitmap?, d: DB, paint: Paint) {
        if (bmp == null) { fill.color = Color.GRAY; c.drawCircle(d.sx, d.sy, d.sr, fill); return }
        c.save(); c.translate(d.sx, d.sy); c.rotate(spriteRot(d)); dst.set(-d.sr, -d.sr, d.sr, d.sr); c.drawBitmap(bmp, null, dst, paint); c.restore()
    }
    private fun drawLive(c: Canvas, idx: Int, d: DB): Boolean {
        synchronized(liveLock) {
            val b = liveFront
            if (b != null && liveIdx == idx) { dst.set(d.sx - d.sr, d.sy - d.sr, d.sx + d.sr, d.sy + d.sr); c.drawBitmap(b, null, dst, bmpPaint); return true }
        }
        return false
    }

    private fun drawSun(c: Canvas, d: DB, tt: Float) {
        if (focus == 0 && d.sr >= dp(46) && drawLive(c, 0, d)) return
        val sp = SolarTex.sprites[0] ?: return
        c.save(); c.translate(d.sx, d.sy); c.rotate(tt * 3f); dst.set(-d.sr, -d.sr, d.sr, d.sr); c.drawBitmap(sp, null, dst, bmpPaint); c.restore()
    }
    private fun drawMoon(c: Canvas, d: DB) { drawSprite(c, SolarTex.sprites[9], d, moonPaints[d.id]) }

    private fun drawPlanet(c: Canvas, d: DB, tt: Float) {
        val i = d.id; val sr = d.sr
        val ac = Solar.ATMO[i]
        if (ac != 0) {
            val r = sr * 1.55f
            glowPaint.shader = RadialGradient(d.sx, d.sy, r, intArrayOf(0, alphaColor(ac, 0.0f), alphaColor(ac, 0.28f), 0), floatArrayOf(0f, 0.62f, 0.72f, 1f), Shader.TileMode.CLAMP)
            c.drawCircle(d.sx, d.sy, r, glowPaint); glowPaint.shader = null
        }
        if (i == 6) rings(c, d, true)
        if (!(focus == i && sr >= dp(46) && drawLive(c, i, d))) drawSprite(c, SolarTex.sprites[i], d, bmpPaint)
        if (i == 6) rings(c, d, false)
    }

    private fun rings(c: Canvas, d: DB, back: Boolean) {
        Solar.poleVec(6, pole)
        var ux0 = pole[1]; var uy0 = -pole[0]; val ul = max(1e-4f, sqrt(ux0 * ux0 + uy0 * uy0)); ux0 /= ul; uy0 /= ul
        val vx0 = -pole[2] * uy0; val vy0 = pole[2] * ux0; val vz0 = pole[0] * uy0 - pole[1] * ux0
        val rW = d.rW
        for (band in 0..2) {
            val rm = (ringBand1[band] + ringBand2[band]) * 0.5f * rW
            path.reset(); var inPath = false; var px = 0f; var py = 0f; var pz = 0f; var ok = false
            for (k in 0..72) {
                val th = k * 6.2831853f / 72f; val cs = cos(th); val sn = sin(th)
                val good = proj(d.wx + rm * (cs * ux0 + sn * vx0), d.wy + rm * (cs * uy0 + sn * vy0), d.wz + rm * (sn * vz0))
                if (good && ok) {
                    val front = (pz + pj[2]) * 0.5f < d.zf
                    if (front != back) { if (!inPath) { path.moveTo(px, py); inPath = true }; path.lineTo(pj[0], pj[1]) } else inPath = false
                } else inPath = false
                ok = good; px = pj[0]; py = pj[1]; pz = pj[2]
            }
            ringPaint.color = ringCol[band]; ringPaint.strokeWidth = max(dp(1f), (ringBand2[band] - ringBand1[band]) * rW * F / d.zf)
            c.drawPath(path, ringPaint)
        }
    }

    private fun updateJob() {
        val i = focus
        if (i < 0) { job = null; return }
        val d = if (i == 0) sunDB else planetDB[i]
        if (d.zf <= 0f || d.sr < dp(46)) { job = null; return }
        val size = ((min(340f, max(96f, d.sr * 2f)) / 8f).toInt() * 8).coerceIn(96, 336)
        Solar.poleVec(i, pole)
        val axv = pole[0] * rx + pole[1] * ry; val ayv = pole[0] * ux + pole[1] * uy + pole[2] * uz; val azv = -(pole[0] * fx + pole[1] * fy + pole[2] * fz)
        var lxw = -d.wx; var lyw = -d.wy; var lzw = -d.wz; val ll = max(1e-6f, sqrt(lxw * lxw + lyw * lyw + lzw * lzw)); lxw /= ll; lyw /= ll; lzw /= ll
        val lxv = lxw * rx + lyw * ry; val lyv = lxw * ux + lyw * uy + lzw * uz; val lzv = -(lxw * fx + lyw * fy + lzw * fz)
        val spin = (((simDays * 24.0 / Solar.ROT_H[i]) % 1.0) * 2.0 * PI).toFloat()
        job = SphereJob(i, size, axv, ayv, azv, spin, lxv, lyv, lzv)
    }

    private fun fit(s: String, p: Paint, maxW: Float): String {
        if (p.measureText(s) <= maxW) return s
        var t = s; while (t.length > 3 && p.measureText("$t\u2026") > maxW) t = t.dropLast(1)
        return "$t\u2026"
    }
    private fun drawLabels(c: Canvas) {
        placed.clear()
        fun lab(name: String, d: DB, big: Boolean) {
            val a = if (focus == d.id && d.kind == 1 && d.sr > dp(60)) return else 1f
            txt.textSize = dp(if (big) 12f else 10.5f); txtS.textSize = txt.textSize
            val tw = txt.measureText(name); val x = d.sx - tw / 2f; val y = d.sy - d.sr - dp(8)
            val rc = RectF(x - dp(3), y - txt.textSize, x + tw + dp(3), y + dp(4))
            if (rc.right < 0 || rc.left > vw || rc.bottom < 0 || rc.top > vh) return
            for (p in placed) if (RectF.intersects(p, rc)) return
            placed.add(rc)
            txt.color = alphaColor(Color.WHITE, 0.92f * a); txtS.alpha = 190
            c.drawText(name, x, y, txtS); c.drawText(name, x, y, txt)
        }
        if (sunDB.zf > 0f) lab("Sun", sunDB, true)
        for (i in 1..8) if (planetDB[i].zf > 0f) lab(Solar.NAMES[i], planetDB[i], true)
        for (k in Solar.MOONS.indices) if (moonDB[k].zf > 0f && focus == Solar.MOONS[k].parent) lab(Solar.MOONS[k].name, moonDB[k], false)
        txt.textSize = dp(11)
    }

    private fun drawFlare(c: Canvas) {
        if (!sunVis) return
        if (sunSx < -vw || sunSx > 2 * vw || sunSy < -vh || sunSy > 2 * vh) return
        val vx = cxv - sunSx; val vy = cyv - sunSy
        val dist = sqrt(vx * vx + vy * vy)
        val k = (1f - dist / (vw * 1.1f)).coerceIn(0f, 1f) * (if (focus == 0) 0.25f else 1f)
        if (k < 0.03f) return
        val ts = floatArrayOf(0.35f, 0.8f, 1.25f, 1.75f); val rs = floatArrayOf(dp(24), dp(13), dp(38), dp(17))
        val cols = intArrayOf(0x66FFA040, 0x6640C8FF, 0x55FF7090, 0x66FFE080)
        for (i in 0..3) {
            val x = sunSx + vx * ts[i]; val y = sunSy + vy * ts[i]
            glowPaint.shader = RadialGradient(x, y, rs[i], intArrayOf(alphaColor(cols[i], 0.55f * k), 0), null, Shader.TileMode.CLAMP)
            c.drawCircle(x, y, rs[i], glowPaint)
        }
        glowPaint.shader = null
    }

    private fun speedText(): String {
        if (!playing) return "Paused"
        var best = 0; var bd = Double.MAX_VALUE
        for (i in Solar.SPEEDS.indices) { val dd = abs(ln(Solar.SPEEDS[i] / daysPerSec)); if (dd < bd) { bd = dd; best = i } }
        return Solar.SPEED_NAMES[best]
    }
    private fun drawHud(c: Canvas, tt: Float) {
        backR.set(dp(14), dp(40), dp(104), dp(80)); fill.color = 0x40101830; c.drawRoundRect(backR, dp(20), dp(20), fill)
        txt.textAlign = Paint.Align.CENTER; txt.color = Color.WHITE; txt.textSize = dp(14); c.drawText("\u2039 Back", backR.centerX(), backR.centerY() + dp(5), txt)
        if (focus >= 0) {
            sysR.set(vw - dp(130), dp(40), vw - dp(14), dp(80)); fill.color = 0x40101830; c.drawRoundRect(sysR, dp(20), dp(20), fill)
            c.drawText("System view", sysR.centerX(), sysR.centerY() + dp(5), txt)
        } else sysR.setEmpty()
        val ms = ((simDays + 2451545.0 - 2440587.5) * 86400000.0).toLong()
        txt.textSize = dp(13); txt.color = 0xE6FFFFFF.toInt(); c.drawText(df.format(Date(ms)), vw / 2f, dp(104), txt)
        txt.textSize = dp(11.5f); txt.color = C.CYAN; c.drawText(speedText() + (if (trueScale) "  \u00B7  true scale" else ""), vw / 2f, dp(121), txt)
        txt.textAlign = Paint.Align.LEFT; txt.textSize = dp(11)
    }

    private fun fmtLight(au: Double): String { val s = (au * 499.005).toInt(); return if (s >= 3600) "${s / 3600} h ${(s % 3600) / 60} min" else "${s / 60} min ${s % 60} s" }
    private fun drawCard(c: Canvas, tt: Float) {
        val i = focus
        val appear = ease(transT)
        val cw = min(vw - dp(24), dp(350)); val ch = dp(142)
        val top = vh - bottomPad - ch - dp(8) + (1f - appear) * dp(40)
        card.set((vw - cw) / 2f, top, (vw + cw) / 2f, top + ch)
        fill.color = alphaColor(0xFF0B1022.toInt(), 0.92f * appear); c.drawRoundRect(card, dp(24), dp(24), fill)
        line.color = alphaColor(Solar.COL[i], 0.6f * appear); line.strokeWidth = dp(1.2f); c.drawRoundRect(card, dp(24), dp(24), line)
        val x = card.left + dp(18); val mw = card.width() - dp(36)
        txt.textSize = dp(19); txt.color = alphaColor(Color.WHITE, appear); c.drawText(Solar.NAMES[i], x, card.top + dp(30), txt)
        txt.textSize = dp(11.5f); txt.color = alphaColor(Solar.COL[i], appear); txt.textAlign = Paint.Align.RIGHT; c.drawText(Solar.TYPE[i], card.right - dp(18), card.top + dp(29), txt); txt.textAlign = Paint.Align.LEFT
        val lines = ArrayList<String>()
        if (i == 0) {
            lines.add("Surface 5,500 \u00B0C \u00B7 core 15 million \u00B0C")
            lines.add("Radius 695,700 km \u00B7 109 \u00D7 Earth")
            lines.add("Sunlight takes 8 min 20 s to reach Earth")
            lines.add("Rotates once in about 25 days")
        } else {
            val r = helioR[i]; val a = Solar.semiMajor(i, simDays)
            val v = 29.78 * sqrt(max(0.0, 2.0 / r - 1.0 / a))
            lines.add(String.format("Distance from Sun %.3f AU \u00B7 %.1f M km", r, r * 149.598))
            lines.add(String.format("Speed %.1f km/s \u00B7 light takes %s", v, fmtLight(r)))
            val y = Solar.YEAR_D[i]
            lines.add("Day " + Solar.DAY[i] + " \u00B7 Year " + (if (y >= 1000) String.format("%.1f yr", y / 365.25) else String.format("%.0f d", y)))
            lines.add(String.format("Radius %,d km \u00B7 %s \u00B7 %s", Solar.R_KM[i].toInt(), Solar.GRAV[i], Solar.TEMP[i]))
        }
        txt.textSize = dp(12.5f); txt.color = alphaColor(0xFFC9D2EE.toInt(), appear)
        for ((k, s) in lines.withIndex()) c.drawText(fit(s, txt, mw), x, card.top + dp(54) + k * dp(19), txt)
        txt.textSize = dp(11.5f); txt.color = alphaColor(Solar.COL[i], appear)
        c.drawText(fit(Solar.MOONS_TXT[i] + " \u00B7 " + Solar.FACT[i], txt, mw), x, card.top + dp(54) + 4 * dp(19), txt)
        txt.textSize = dp(11)
    }

    // ------------------------------------------------------------------ touch
    override fun onTouchEvent(e: MotionEvent): Boolean {
        scaleDet.onTouchEvent(e); gestDet.onTouchEvent(e)
        if (scaleDet.isInProgress || e.pointerCount > 1) { moved += 200f; downX = e.x; downY = e.y; touching = true; lastTouch = SystemClock.uptimeMillis(); return true }
        when (e.actionMasked) {
            MotionEvent.ACTION_DOWN -> { touching = true; downX = e.x; downY = e.y; moved = 0f; velYaw = 0f; velPitch = 0f; downT = SystemClock.uptimeMillis(); lastTouch = downT }
            MotionEvent.ACTION_MOVE -> {
                val dx = e.x - downX; val dy = e.y - downY; moved += abs(dx) + abs(dy)
                yaw -= dx * 0.0065f; pitch = (pitch + dy * 0.0065f).coerceIn(-1.5f, 1.5f)
                lastDx = dx; lastDy = dy; downX = e.x; downY = e.y; lastTouch = SystemClock.uptimeMillis()
            }
            MotionEvent.ACTION_UP -> {
                touching = false; lastTouch = SystemClock.uptimeMillis()
                if (moved < dp(12) && lastTouch - downT < 350L) {
                    if (backR.contains(e.x, e.y)) { onExit?.invoke(); return true }
                    if (!sysR.isEmpty && sysR.contains(e.x, e.y)) { goOverview(); thud(); return true }
                    var best: DB? = null; var bd = Float.MAX_VALUE
                    for (d in hits) { val dd = hypot(d.sx - e.x, d.sy - e.y); val lim = max(d.sr * 1.25f, dp(30)); if (dd < lim && dd < bd) { bd = dd; best = d } }
                    if (best != null) { focusOn(if (best.kind == 0) 0 else best.id); thud() }
                } else { velYaw = -lastDx * 0.0065f * 30f * 0.6f; velPitch = lastDy * 0.0065f * 30f * 0.6f }
            }
            MotionEvent.ACTION_CANCEL -> touching = false
        }
        return true
    }
}
