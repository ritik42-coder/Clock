package com.chronox.clock

import android.content.Context
import android.graphics.*
import android.os.SystemClock
import android.view.GestureDetector
import android.view.MotionEvent
import android.view.ScaleGestureDetector
import android.view.View
import java.util.Date
import kotlin.math.*

private class SphereJob(val idx: Int, val size: Int, val ax: Float, val ay: Float, val az: Float, val spin: Float, val lx: Float, val ly: Float, val lz: Float)
private class DB(val kind: Int, val id: Int) { var wx = 0f; var wy = 0f; var wz = 0f; var sx = 0f; var sy = 0f; var zf = 0f; var sr = 0f; var rW = 0f }

class SolarView(ctx: Context) : View(ctx) {
    var onSpeedAuto: ((Int) -> Unit)? = null
    var onExit: (() -> Unit)? = null
    var bottomPad = dp(236)
    @Volatile var daysPerSec = 7.0
    @Volatile var playing = true
    private var userSpeed = false
    var showOrbits = true; var showLabels = true; var showMoons = true; var showBelt = true
    var showMinor = true
    var showMissions = false
        set(v) { field = v; if (focus == -1 && surface < 1) { distTarget = overviewDist(); startFrom() } }
    var trueScale = false
        set(v) { field = v; orbitDirty = true; if (focus == -1 && surface < 1) { distTarget = overviewDist(); startFrom() } }

    private val NM = Deep.MINORS.size; private val NS = Deep.MISSIONS.size
    private var simDays = (System.currentTimeMillis() / 86400000.0 + 2440587.5) - 2451545.0
    private var yaw = 0.9f; private var pitch = 0.62f
    private var camDist = 15f; private var distTarget = 15f; private var startLog = ln(15f)
    private var transT = 1f
    private var tgx = 0f; private var tgy = 0f; private var tgz = 0f; private var stx = 0f; private var sty = 0f; private var stz = 0f
    private var focus = -1
    private var surface = -1
    private var sYaw = 1.2f; private var sPitch = 0.2f; private var fovScale = 1.6f
    private var velYaw = 0f; private var velPitch = 0f; private var lastDx = 0f; private var lastDy = 0f
    private var lastT = 0L; private var lastTouch = 0L; private var touching = false
    private var downX = 0f; private var downY = 0f; private var moved = 0f; private var downT = 0L
    private var starK = 1f

    private val bx = FloatArray(9); private val by = FloatArray(9); private val bz = FloatArray(9); private val helioR = DoubleArray(9)
    private val mnx = FloatArray(NM); private val mny = FloatArray(NM); private val mnz = FloatArray(NM); private val mnR = DoubleArray(NM)
    private val msx = FloatArray(NS); private val msy = FloatArray(NS); private val msz = FloatArray(NS); private val msR = DoubleArray(NS); private val msOn = BooleanArray(NS)
    private val tmpD = DoubleArray(3); private val tmpF = FloatArray(3); private val pole = FloatArray(3)
    private val orbit = Array(9) { FloatArray(129 * 3) }
    private val mOrbit = Array(NM) { FloatArray(129 * 3) }
    private var orbitDirty = true; private var orbitDay = 0.0
    private val lineBuf = FloatArray(260 * 4)
    private val BELT = 520
    private val beltA = FloatArray(BELT); private val beltPh = FloatArray(BELT); private val beltZ = FloatArray(BELT); private val beltBuf = FloatArray(BELT * 2)
    private val starV = FloatArray(300 * 3); private val starS = FloatArray(300); private val starP = FloatArray(300)
    private val milky = FloatArray(170 * 3)

    private var camX = 0f; private var camY = 0f; private var camZ = 0f
    private var fx = 0f; private var fy = 0f; private var fz = 0f
    private var rx = 0f; private var ry = 0f; private var rz = 0f
    private var ux = 0f; private var uy = 0f; private var uz = 0f
    private var F = 1f; private var cxv = 0f; private var cyv = 0f; private var vw = 0f; private var vh = 0f
    private val pj = FloatArray(3)
    private var sunSx = 0f; private var sunSy = 0f; private var sunVis = false

    private val sunDB = DB(0, 0)
    private val planetDB = Array(9) { DB(1, it) }
    private val moonDB = Array(Solar.MOONS.size) { DB(2, it) }
    private val minorDB = Array(NM) { DB(3, it) }
    private val missionDB = Array(NS) { DB(4, it) }
    private val hits = ArrayList<DB>()
    private val placed = ArrayList<RectF>()

    private val fill = fillPaint(); private val line = strokePaint(Color.WHITE, dp(1.2f)).apply { strokeCap = Paint.Cap.ROUND }
    private val ringPaint = strokePaint(Color.WHITE, dp(2)).apply { strokeJoin = Paint.Join.ROUND }
    private val txt = textPaint(Color.WHITE, dp(11), MED, Paint.Align.LEFT)
    private val txtS = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.STROKE; color = 0xCC000814.toInt(); strokeWidth = dp(2.4f); typeface = MED; textSize = dp(11); strokeJoin = Paint.Join.ROUND }
    private val bmpPaint = Paint(Paint.FILTER_BITMAP_FLAG or Paint.ANTI_ALIAS_FLAG)
    private val glowPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { xfermode = PorterDuffXfermode(PorterDuff.Mode.SCREEN) }
    private val moonPaints = Array(Solar.MOONS.size) { Paint(Paint.FILTER_BITMAP_FLAG or Paint.ANTI_ALIAS_FLAG).apply { colorFilter = PorterDuffColorFilter(alphaColor(Solar.MOONS[it].color, 0.5f), PorterDuff.Mode.SRC_ATOP) } }
    private val ringBand1 = floatArrayOf(1.24f, 1.55f, 2.03f); private val ringBand2 = floatArrayOf(1.52f, 1.98f, 2.27f)
    private val ringCol = intArrayOf(0x66B8A488, 0xE0E6D2A8.toInt(), 0xB8CDB894.toInt())
    private val SKY_TOP = intArrayOf(0, 0, 0xFFB69A5A.toInt(), 0xFF2A64D2.toInt(), 0xFF8E6A4C.toInt(), 0xFF9A7A58.toInt(), 0xFF9A8A60.toInt(), 0xFF5AA8B5.toInt(), 0xFF2A4AAA.toInt())
    private val SKY_HOR = intArrayOf(0, 0, 0xFFE6C070.toInt(), 0xFF9ACBF2.toInt(), 0xFFD8A878.toInt(), 0xFFD8B890.toInt(), 0xFFE0CC90.toInt(), 0xFF9AE0E6.toInt(), 0xFF5A82D8.toInt())
    private val GROUND = intArrayOf(0, 0xFF6E6A66.toInt(), 0xFF7A5A2E.toInt(), 0xFF2A3E2C.toInt(), 0xFF8A4A2C.toInt(), 0xFFB88A62.toInt(), 0xFFC8AE78.toInt(), 0xFF6EA8B2.toInt(), 0xFF3C58B8.toInt())
    private val path = Path(); private val dst = RectF(); private val card = RectF(); private val backR = RectF(); private val sysR = RectF(); private val standR = RectF()
    private val df = java.text.SimpleDateFormat("d MMM yyyy  HH:mm", java.util.Locale.getDefault())
    private val df2 = java.text.SimpleDateFormat("d MMM yyyy", java.util.Locale.getDefault())
    private var solarTime = 12f; private var sunEl = 0f

    @Volatile private var job: SphereJob? = null
    @Volatile private var running = false
    private var thread: Thread? = null
    private var liveFront: Bitmap? = null; private var liveBack: Bitmap? = null
    @Volatile private var liveIdx = -1
    private val liveLock = Any()
    private val livePx = IntArray(344 * 344)
    private var earthUp = false

    private val scaleDet = ScaleGestureDetector(ctx, object : ScaleGestureDetector.SimpleOnScaleGestureListener() {
        override fun onScale(d: ScaleGestureDetector): Boolean {
            if (surface >= 1) { fovScale = (fovScale * d.scaleFactor).coerceIn(0.6f, 9f); return true }
            distTarget = clampDist(distTarget / d.scaleFactor)
            if (transT >= 1f) { camDist = distTarget; startLog = ln(distTarget) }
            return true
        }
    })
    private val gestDet = GestureDetector(ctx, object : GestureDetector.SimpleOnGestureListener() {
        override fun onDown(e: MotionEvent): Boolean = true
        override fun onDoubleTap(e: MotionEvent): Boolean { goOverview(); thud(); return true }
    })

    init {
        val r = java.util.Random(17)
        for (i in 0 until 300) {
            val a = r.nextFloat() * 6.2832f; val z = r.nextFloat() * 2f - 1f; val s = sqrt(1f - z * z)
            starV[i * 3] = s * cos(a); starV[i * 3 + 1] = s * sin(a); starV[i * 3 + 2] = z
            starS[i] = 0.5f + r.nextFloat() * r.nextFloat() * 2.2f; starP[i] = r.nextFloat() * 6.28f
        }
        for (i in 0 until 170) {
            val a = r.nextFloat() * 6.2832f; val off = (r.nextFloat() - 0.5f) * (r.nextFloat() - 0.5f) * 0.9f
            val x = cos(a); val y = sin(a) * 0.5f - off * 0.87f; val z = sin(a) * 0.87f + off * 0.5f
            val l = sqrt(x * x + y * y + z * z); milky[i * 3] = x / l; milky[i * 3 + 1] = y / l; milky[i * 3 + 2] = z / l
        }
        for (i in 0 until BELT) { beltA[i] = 2.15f + r.nextFloat() * 1.15f; beltPh[i] = r.nextFloat() * 6.2832f; beltZ[i] = (r.nextFloat() - 0.5f) * 0.1f }
    }

    // ------------------------------------------------------------------ ids / control API
    private fun isMinor(id: Int) = id in 10..29
    private fun isMission(id: Int) = id >= 30
    private fun overviewDist() = if (trueScale) 70f else if (showMissions) 42f else 16f
    private fun focusRad(id: Int): Float = when {
        id in 0..8 -> Solar.dispR(id)
        isMinor(id) -> 0.012f
        else -> 0.01f
    }
    private fun focusDistFor(id: Int): Float = when {
        id in 0..8 -> Solar.dispR(id) * Solar.focusMult(id)
        isMinor(id) -> if (Deep.MINORS[id - 10].comet) 0.45f else 0.07f
        else -> 0.5f
    }
    private fun clampDist(d: Float): Float {
        val mn = when { focus in 1..8 -> Solar.dispR(focus) * 2.2f; focus == 0 -> 0.35f; isMinor(focus) -> 0.02f; isMission(focus) -> 0.05f; else -> 1.5f }
        val mx = if (trueScale) 140f else 70f
        return d.coerceIn(mn, mx)
    }
    private fun startFrom() { stx = tgx; sty = tgy; stz = tgz; startLog = ln(camDist); transT = 0f }
    fun focusOn(i: Int) {
        if (surface >= 1) return
        if (i == focus) return
        focus = i; startFrom(); distTarget = focusDistFor(i); autoSpeed()
    }
    fun goOverview() {
        if (surface >= 1) { surface = -1; startFrom(); autoSpeed(); return }
        if (focus == -1) return
        focus = -1; distTarget = overviewDist(); startFrom(); autoSpeed()
    }
    private fun enterSurface(i: Int) { surface = i; sYaw = 1.2f; sPitch = 0.18f; fovScale = 1.6f; autoSpeed() }
    private fun autoSpeed() {
        if (userSpeed) return
        val idx = if (surface >= 1) 2 else if (focus >= 1) 2 else if (focus == 0) 3 else 4
        daysPerSec = Solar.SPEEDS[idx]; onSpeedAuto?.invoke(idx)
    }
    fun setSpeedIndex(i: Int) { userSpeed = true; daysPerSec = Solar.SPEEDS[i.coerceIn(0, Solar.SPEEDS.size - 1)] }
    fun today() { simDays = (System.currentTimeMillis() / 86400000.0 + 2440587.5) - 2451545.0 }

    fun start() {
        if (running) return
        running = true; SolarTex.ensure(); Planet.ensure()
        thread = Thread {
            while (running) {
                val t0 = SystemClock.uptimeMillis()
                if (SolarTex.ready && Planet.ready && !earthUp) { try { SolarTex.makeSprite(3) } catch (e: Throwable) { }; earthUp = true }
                val j = job
                if (j == null || !SolarTex.ready) { try { Thread.sleep(30) } catch (e: InterruptedException) { }; continue }
                SphereR.render(livePx, j.size, j.idx, j.ax, j.ay, j.az, j.spin, j.lx, j.ly, j.lz)
                var b = liveBack
                if (b == null || b.width != j.size) { b = Bitmap.createBitmap(j.size, j.size, Bitmap.Config.ARGB_8888); liveBack = b }
                b.setPixels(livePx, 0, j.size, 0, 0, j.size, j.size)
                synchronized(liveLock) { val t = liveFront; liveFront = b; liveBack = t; liveIdx = j.idx }
                postInvalidateOnAnimation()
                val spent = SystemClock.uptimeMillis() - t0
                if (spent < 30) try { Thread.sleep(30 - spent) } catch (e: InterruptedException) { }
            }
        }.also { it.priority = Thread.NORM_PRIORITY - 1; it.start() }
        invalidate()
    }
    fun stop() { running = false; thread?.interrupt(); thread = null }
    override fun onDetachedFromWindow() { stop(); super.onDetachedFromWindow() }

    // ------------------------------------------------------------------ math helpers
    private fun sm(e0: Float, e1: Float, x: Float): Float { val t = ((x - e0) / (e1 - e0)).coerceIn(0f, 1f); return t * t * (3f - 2f * t) }
    private fun comp(x: Double, y: Double, z: Double) {
        val r = sqrt(x * x + y * y + z * z); val k = if (trueScale || surface >= 1 || r < 1e-9) 1.0 else 1.0 / sqrt(r)
        tmpF[0] = (x * k).toFloat(); tmpF[1] = (y * k).toFloat(); tmpF[2] = (z * k).toFloat()
    }
    private fun proj(x: Float, y: Float, z: Float): Boolean {
        val dx = x - camX; val dy = y - camY; val dz = z - camZ
        val zf = dx * fx + dy * fy + dz * fz
        if (zf < 0.0004f) return false
        pj[0] = cxv + F * (dx * rx + dy * ry) / zf; pj[1] = cyv - F * (dx * ux + dy * uy + dz * uz) / zf; pj[2] = zf
        return true
    }
    private fun ease(t: Float): Float = if (t < 0.5f) 4f * t * t * t else { val q = -2f * t + 2f; 1f - q * q * q / 2f }
    private fun updatePositions() {
        for (i in 1..8) {
            Solar.helio(i, simDays, tmpD); helioR[i] = sqrt(tmpD[0] * tmpD[0] + tmpD[1] * tmpD[1] + tmpD[2] * tmpD[2])
            comp(tmpD[0], tmpD[1], tmpD[2]); bx[i] = tmpF[0]; by[i] = tmpF[1]; bz[i] = tmpF[2]
        }
        if (surface >= 1) return
        for (k in 0 until NM) {
            Deep.minorPos(k, simDays, tmpD); mnR[k] = sqrt(tmpD[0] * tmpD[0] + tmpD[1] * tmpD[1] + tmpD[2] * tmpD[2])
            comp(tmpD[0], tmpD[1], tmpD[2]); mnx[k] = tmpF[0]; mny[k] = tmpF[1]; mnz[k] = tmpF[2]
        }
        for (k in 0 until NS) {
            msOn[k] = Deep.missionPos(k, simDays, tmpD)
            if (msOn[k]) { msR[k] = sqrt(tmpD[0] * tmpD[0] + tmpD[1] * tmpD[1] + tmpD[2] * tmpD[2]); comp(tmpD[0], tmpD[1], tmpD[2]); msx[k] = tmpF[0]; msy[k] = tmpF[1]; msz[k] = tmpF[2] }
        }
    }
    private fun focusPos() {
        val id = focus
        when {
            id in 1..8 -> { tmpF[0] = bx[id]; tmpF[1] = by[id]; tmpF[2] = bz[id] }
            isMinor(id) -> { tmpF[0] = mnx[id - 10]; tmpF[1] = mny[id - 10]; tmpF[2] = mnz[id - 10] }
            isMission(id) -> { val k = id - 30; tmpF[0] = msx[k]; tmpF[1] = msy[k]; tmpF[2] = msz[k] }
            else -> { tmpF[0] = 0f; tmpF[1] = 0f; tmpF[2] = 0f }
        }
    }
    private fun ensureOrbits() {
        if (!orbitDirty && abs(simDays - orbitDay) < 1500.0) return
        for (i in 1..8) for (k in 0..128) {
            Solar.helio(i, simDays, tmpD, 2 * PI * k / 128.0); comp(tmpD[0], tmpD[1], tmpD[2])
            orbit[i][k * 3] = tmpF[0]; orbit[i][k * 3 + 1] = tmpF[1]; orbit[i][k * 3 + 2] = tmpF[2]
        }
        for (m in 0 until NM) for (k in 0..128) {
            Deep.minorPos(m, simDays, tmpD, 2 * PI * k / 128.0); comp(tmpD[0], tmpD[1], tmpD[2])
            mOrbit[m][k * 3] = tmpF[0]; mOrbit[m][k * 3 + 1] = tmpF[1]; mOrbit[m][k * 3 + 2] = tmpF[2]
        }
        orbitDirty = false; orbitDay = simDays
    }
    private fun minPx(i: Int): Float = if (i == 0) (if (surface >= 1) dp(9) else dp(15)) else dp(6f + 3.2f * sqrt(Solar.R_KM[i] / 6371f))

    // ------------------------------------------------------------------ main draw
    override fun onDraw(c: Canvas) {
        vw = width.toFloat(); vh = height.toFloat()
        val now = SystemClock.uptimeMillis(); val dt = if (lastT == 0L) 0f else ((now - lastT) / 1000f).coerceAtMost(0.1f); lastT = now
        val tt = now / 1000f
        c.drawColor(0xFF02030A.toInt())
        cxv = vw / 2f; cyv = (dp(96) + vh - bottomPad) / 2f; F = min(vw, vh) * 1.25f
        if (!SolarTex.ready) {
            for (i in 0 until 120) { fill.color = alphaColor(Color.WHITE, 0.2f + 0.5f * (0.5f + 0.5f * sin(tt * 1.5f + i))); c.drawCircle(((i * 7919) % 1000) / 1000f * vw, ((i * 104729) % 1000) / 1000f * vh, dp(1.2f), fill) }
            line.color = C.CYAN; line.strokeWidth = dp(4); dst.set(vw / 2f - dp(30), vh / 2f - dp(30), vw / 2f + dp(30), vh / 2f + dp(30))
            c.drawArc(dst, tt * 300f, 100f, false, line)
            txt.textAlign = Paint.Align.CENTER; txt.color = 0xCCFFFFFF.toInt(); txt.textSize = dp(14); c.drawText("Preparing the solar system\u2026", vw / 2f, vh / 2f + dp(66), txt)
            txt.textAlign = Paint.Align.LEFT; txt.textSize = dp(11)
            drawHud(c); postInvalidateOnAnimation(); return
        }
        if (playing) simDays = (simDays + dt * daysPerSec).coerceIn(-70000.0, 45000.0)
        if (surface >= 1) { drawSurface(c, dt, tt); postInvalidateOnAnimation(); return }
        starK = 1f
        if (!touching) {
            yaw += velYaw * dt; pitch = (pitch + velPitch * dt).coerceIn(-1.5f, 1.5f)
            val dec = exp(-dt * 3f); velYaw *= dec; velPitch *= dec
            if (abs(velYaw) < 0.02f && now - lastTouch > 4000L) yaw += 0.035f * dt
        }
        updatePositions(); ensureOrbits()
        if (transT < 1f) transT = min(1f, transT + dt / 1.7f)
        val e = ease(transT)
        if (focus == -1 || focus == 0) { tmpF[0] = 0f; tmpF[1] = 0f; tmpF[2] = 0f } else focusPos()
        tgx = stx + (tmpF[0] - stx) * e; tgy = sty + (tmpF[1] - sty) * e; tgz = stz + (tmpF[2] - stz) * e
        camDist = exp(startLog + (ln(distTarget) - startLog) * e)
        val cp = cos(pitch)
        camX = tgx + camDist * cp * cos(yaw); camY = tgy + camDist * cp * sin(yaw); camZ = tgz + camDist * sin(pitch)
        fx = -cp * cos(yaw); fy = -cp * sin(yaw); fz = -sin(pitch)
        val rxv = fy; val ryv = -fx; val rl = max(1e-4f, sqrt(rxv * rxv + ryv * ryv)); rx = rxv / rl; ry = ryv / rl; rz = 0f
        ux = ry * fz - rz * fy; uy = rz * fx - rx * fz; uz = rx * fy - ry * fx

        drawStars(c, tt)
        val nearFade = (camDist / 1.4f).coerceIn(0f, 1f)
        if (showOrbits) { drawOrbits(c, nearFade); if (showMinor) drawMinorOrbits(c, nearFade) }
        drawTrails(c, nearFade)
        if (showBelt) drawBelt(c)
        if (showMissions) drawMissionPaths(c)
        computeItems()
        drawSunGlow(c, tt)
        val list = ArrayList<DB>()
        if (sunDB.zf > 0f) list.add(sunDB)
        for (i in 1..8) if (planetDB[i].zf > 0f) list.add(planetDB[i])
        for (m in moonDB) if (m.zf > 0f) list.add(m)
        for (m in minorDB) if (m.zf > 0f) list.add(m)
        for (m in missionDB) if (m.zf > 0f) list.add(m)
        list.sortByDescending { it.zf }
        hits.clear()
        for (d in list) {
            when (d.kind) { 0 -> drawSun(c, d, tt); 1 -> drawPlanet(c, d); 2 -> drawMoon(c, d); 3 -> drawMinor(c, d); else -> drawMission(c, d, tt) }
            if (d.kind != 2) hits.add(d)
        }
        updateJob()
        if (showLabels) drawLabels(c)
        drawFlare(c)
        drawHud(c)
        if (focus >= 0) drawCard(c)
        postInvalidateOnAnimation()
    }

    // ------------------------------------------------------------------ standing on a planet
    private fun drawSurface(c: Canvas, dt: Float, tt: Float) {
        val i = surface
        updatePositions()
        Solar.poleVec(i, pole)
        var e1x = pole[1]; var e1y = -pole[0]; var el1 = sqrt(e1x * e1x + e1y * e1y)
        if (el1 < 1e-3f) { e1x = 1f; e1y = 0f; el1 = 1f }; e1x /= el1; e1y /= el1
        val e2x = -pole[2] * e1y; val e2y = pole[2] * e1x; val e2z = pole[0] * e1y - pole[1] * e1x
        val spin = (((simDays * 24.0 / Solar.ROT_H[i]) % 1.0) * 2.0 * PI).toFloat()
        val cs = cos(spin); val sn = sin(spin)
        val lx = cs * e1x + sn * e2x; val ly = cs * e1y + sn * e2y; val lz = sn * e2z
        val lat = 0.6f; val cl = cos(lat); val sl = sin(lat)
        val zx = cl * lx + sl * pole[0]; val zy = cl * ly + sl * pole[1]; val zz = cl * lz + sl * pole[2]
        var ex = pole[1] * zz - pole[2] * zy; var ey = pole[2] * zx - pole[0] * zz; var ez = pole[0] * zy - pole[1] * zx
        val elen = max(1e-4f, sqrt(ex * ex + ey * ey + ez * ez)); ex /= elen; ey /= elen; ez /= elen
        val nx = zy * ez - zz * ey; val ny = zz * ex - zx * ez; val nz = zx * ey - zy * ex
        val ce = cos(sPitch); val se = sin(sPitch); val ca = cos(sYaw); val sa = sin(sYaw)
        fx = ce * (ca * nx + sa * ex) + se * zx; fy = ce * (ca * ny + sa * ey) + se * zy; fz = ce * (ca * nz + sa * ez) + se * zz
        val rxv = fy * zz - fz * zy; val ryv = fz * zx - fx * zz; val rzv = fx * zy - fy * zx
        val rl = max(1e-4f, sqrt(rxv * rxv + ryv * ryv + rzv * rzv)); rx = rxv / rl; ry = ryv / rl; rz = rzv / rl
        ux = ry * fz - rz * fy; uy = rz * fx - rx * fz; uz = rx * fy - ry * fx
        camX = bx[i] + zx * 1e-5f; camY = by[i] + zy * 1e-5f; camZ = bz[i] + zz * 1e-5f
        F = min(vw, vh) * 1.25f * fovScale
        // sun geometry
        var sdx = -bx[i]; var sdy = -by[i]; var sdz = -bz[i]; val sdl = max(1e-6f, sqrt(sdx * sdx + sdy * sdy + sdz * sdz)); sdx /= sdl; sdy /= sdl; sdz /= sdl
        val sinEl = sdx * zx + sdy * zy + sdz * zz
        sunEl = Math.toDegrees(asin(sinEl.coerceIn(-1f, 1f).toDouble())).toFloat()
        val mx = pole[1] * lz - pole[2] * ly; val my = pole[2] * lx - pole[0] * lz; val mz = pole[0] * ly - pole[1] * lx
        val sL = sdx * lx + sdy * ly + sdz * lz; val sE = sdx * mx + sdy * my + sdz * mz
        solarTime = (((12.0 + Math.toDegrees(atan2(-sE.toDouble(), sL.toDouble())) / 15.0) % 24.0 + 24.0) % 24.0).toFloat()
        val atmo = i != 1
        val dayK = if (atmo) sm(-0.12f, 0.22f, sinEl) else 0f
        starK = 1f - dayK
        val hy = cyv + F * tan(sPitch)
        val gy = hy.coerceIn(0f, vh)
        // sky
        val night = 0xFF02030A.toInt()
        val tw = exp(-((sinEl + 0.05f) / 0.12f) * ((sinEl + 0.05f) / 0.12f)) * (if (atmo) 1f else 0f)
        var top = mixColor(night, SKY_TOP[i], dayK); var hor = mixColor(night, SKY_HOR[i], dayK)
        hor = mixColor(hor, 0xFFFF8A4A.toInt(), tw * 0.65f); top = mixColor(top, 0xFF3A2A5A.toInt(), tw * 0.35f)
        if (gy > 0f) { fill.shader = LinearGradient(0f, 0f, 0f, gy, top, hor, Shader.TileMode.CLAMP); c.drawRect(0f, 0f, vw, gy, fill); fill.shader = null }
        drawStars(c, tt)
        computeItems()
        drawSunGlow(c, tt)
        val list = ArrayList<DB>()
        if (sunDB.zf > 0f) list.add(sunDB)
        for (k in 1..8) if (k != i && planetDB[k].zf > 0f) list.add(planetDB[k])
        list.sortByDescending { it.zf }
        hits.clear()
        for (d in list) { if (d.kind == 0) drawSun(c, d, tt) else drawPlanet(c, d); hits.add(d) }
        // ground
        if (gy < vh) {
            val lit = if (atmo) 0.22f + 0.78f * dayK else sm(-0.02f, 0.2f, sinEl)
            val g0 = scaleColor(GROUND[i], 0.18f + 0.82f * lit); val g1 = scaleColor(GROUND[i], 0.06f + 0.4f * lit)
            if (atmo && gy > dp(24)) { fill.shader = LinearGradient(0f, gy - dp(26), 0f, gy, 0, alphaColor(hor, 0.55f), Shader.TileMode.CLAMP); c.drawRect(0f, gy - dp(26), vw, gy, fill); fill.shader = null }
            fill.shader = LinearGradient(0f, gy, 0f, vh, g0, g1, Shader.TileMode.CLAMP); c.drawRect(0f, gy, vw, vh, fill); fill.shader = null
            line.color = alphaColor(Color.WHITE, 0.25f); line.strokeWidth = dp(1); c.drawLine(0f, gy, vw, gy, line)
        }
        // compass letters
        val dirs = arrayOf(floatArrayOf(nx, ny, nz), floatArrayOf(ex, ey, ez), floatArrayOf(-nx, -ny, -nz), floatArrayOf(-ex, -ey, -ez)); val letters = arrayOf("N", "E", "S", "W")
        txt.textAlign = Paint.Align.CENTER; txt.textSize = dp(13); txt.color = 0xE6FFFFFF.toInt()
        for (q in 0..3) {
            val zf = dirs[q][0] * fx + dirs[q][1] * fy + dirs[q][2] * fz
            if (zf > 0.15f) { val sx = cxv + F * (dirs[q][0] * rx + dirs[q][1] * ry + dirs[q][2] * rz) / zf; if (sx > 0 && sx < vw) c.drawText(letters[q], sx, gy.coerceIn(dp(30), vh - dp(20)) + dp(22), txt) }
        }
        txt.textAlign = Paint.Align.LEFT; txt.textSize = dp(11)
        if (showLabels) drawLabels(c)
        drawFlare(c)
        drawHud(c)
        drawSurfaceCard(c)
    }

    private fun scaleColor(c: Int, k: Float): Int {
        val r = (((c shr 16) and 255) * k).toInt().coerceIn(0, 255); val g = (((c shr 8) and 255) * k).toInt().coerceIn(0, 255); val b = ((c and 255) * k).toInt().coerceIn(0, 255)
        return (255 shl 24) or (r shl 16) or (g shl 8) or b
    }

    // ------------------------------------------------------------------ scene pieces
    private fun drawStars(c: Canvas, tt: Float) {
        if (starK < 0.02f) return
        for (i in 0 until 170) {
            val dx = milky[i * 3]; val dy = milky[i * 3 + 1]; val dz = milky[i * 3 + 2]
            val zf = dx * fx + dy * fy + dz * fz; if (zf < 0.25f) continue
            val sx = cxv + F * (dx * rx + dy * ry + dz * rz) / zf; val sy = cyv - F * (dx * ux + dy * uy + dz * uz) / zf
            if (sx < -dp(40) || sx > vw + dp(40) || sy < -dp(40) || sy > vh + dp(40)) continue
            fill.color = alphaColor(if (i % 3 == 0) 0xFF9FB8FF.toInt() else 0xFFFFD9B0.toInt(), 0.06f * starK); c.drawCircle(sx, sy, dp(16f + (i % 5) * 5f), fill)
        }
        for (i in 0 until 300) {
            val dx = starV[i * 3]; val dy = starV[i * 3 + 1]; val dz = starV[i * 3 + 2]
            val zf = dx * fx + dy * fy + dz * fz; if (zf < 0.25f) continue
            val sx = cxv + F * (dx * rx + dy * ry + dz * rz) / zf; val sy = cyv - F * (dx * ux + dy * uy + dz * uz) / zf
            if (sx < 0 || sx > vw || sy < 0 || sy > vh) continue
            fill.color = alphaColor(Color.WHITE, (0.30f + 0.6f * (0.5f + 0.5f * sin(tt * (0.8f + starS[i]) + starP[i])) * 0.85f) * starK)
            c.drawCircle(sx, sy, dp(starS[i] * 0.6f), fill)
        }
    }

    private fun drawOrbitSet(c: Canvas, o: FloatArray, col: Int, alpha: Float, width: Float) {
        var n = 0; var px = 0f; var py = 0f; var ok = false
        for (k in 0..128) {
            val good = proj(o[k * 3], o[k * 3 + 1], o[k * 3 + 2])
            if (good && ok) { lineBuf[n * 4] = px; lineBuf[n * 4 + 1] = py; lineBuf[n * 4 + 2] = pj[0]; lineBuf[n * 4 + 3] = pj[1]; n++ }
            ok = good; px = pj[0]; py = pj[1]
        }
        line.color = alphaColor(col, alpha); line.strokeWidth = width
        c.drawLines(lineBuf, 0, n * 4, line)
    }
    private fun drawOrbits(c: Canvas, nearFade: Float) {
        for (i in 1..8) drawOrbitSet(c, orbit[i], Solar.COL[i], (if (focus == i) 0.7f else 0.26f) * nearFade, dp(if (focus == i) 1.6f else 1.1f))
    }
    private fun drawMinorOrbits(c: Canvas, nearFade: Float) {
        for (k in 0 until NM) drawOrbitSet(c, mOrbit[k], Deep.MINORS[k].color, (if (focus == 10 + k) 0.6f else 0.2f) * nearFade, dp(1f))
    }

    private fun drawTrails(c: Canvas, nearFade: Float) {
        for (i in 1..8) {
            val step = Solar.YEAR_D[i] / 150.0
            var px = 0f; var py = 0f; var ok = false
            for (k in 0..22) {
                Solar.helio(i, simDays - k * step, tmpD); comp(tmpD[0], tmpD[1], tmpD[2])
                val good = proj(tmpF[0], tmpF[1], tmpF[2])
                if (good && ok) {
                    val a = (1f - k / 23f); line.color = alphaColor(Solar.COL[i], 0.75f * a * a * nearFade); line.strokeWidth = dp(0.8f + 2.2f * a)
                    c.drawLine(px, py, pj[0], pj[1], line)
                }
                ok = good; px = pj[0]; py = pj[1]
            }
        }
    }

    private fun drawBelt(c: Canvas) {
        var n = 0
        for (j in 0 until BELT) {
            val a = beltPh[j] + 2.0 * PI * simDays / (365.25 * beltA[j].toDouble().pow(1.5))
            comp(beltA[j] * cos(a), beltA[j] * sin(a), beltZ[j].toDouble())
            if (proj(tmpF[0], tmpF[1], tmpF[2])) { beltBuf[n * 2] = pj[0]; beltBuf[n * 2 + 1] = pj[1]; n++ }
        }
        line.color = 0x88B8AFA3.toInt(); line.strokeWidth = dp(1.5f); c.drawPoints(beltBuf, 0, n * 2, line)
    }

    private fun drawMissionPaths(c: Canvas) {
        for (k in 0 until NS) {
            val m = Deep.MISSIONS[k]
            if (!msOn[k]) continue
            val from = if (m.conic != null) max(m.launch, simDays - 270.0) else m.launch
            val n = if (m.conic != null) 220 else 160
            val step = (simDays - from) / n
            var px = 0f; var py = 0f; var ok = false
            for (q in 0..n) {
                Deep.missionPos(k, from + q * step, tmpD); comp(tmpD[0], tmpD[1], tmpD[2])
                val good = proj(tmpF[0], tmpF[1], tmpF[2])
                if (good && ok) { val a = 0.15f + 0.8f * q / n; line.color = alphaColor(m.color, a); line.strokeWidth = dp(1.3f + 1.0f * q / n); c.drawLine(px, py, pj[0], pj[1], line) }
                ok = good; px = pj[0]; py = pj[1]
            }
            for (w in m.wps) {
                if (w.day > simDays || (w.label.isEmpty() && w.body < 1)) continue
                val idx = m.wps.indexOf(w); val p = m.pts[idx]
                comp(p[0], p[1], p[2])
                if (!proj(tmpF[0], tmpF[1], tmpF[2])) continue
                ringPaint.color = alphaColor(m.color, 0.9f); ringPaint.strokeWidth = dp(1.4f); c.drawCircle(pj[0], pj[1], dp(4.5f), ringPaint)
                if (showLabels && focus == 30 + k && w.label.isNotEmpty()) {
                    txt.textSize = dp(10); txtS.textSize = dp(10); txt.color = alphaColor(m.color, 0.95f)
                    c.drawText(w.label, pj[0] + dp(7), pj[1] - dp(6), txtS); c.drawText(w.label, pj[0] + dp(7), pj[1] - dp(6), txt); txt.textSize = dp(11)
                }
            }
        }
    }

    private fun computeItems() {
        val sf = surface >= 1
        sunDB.wx = 0f; sunDB.wy = 0f; sunDB.wz = 0f; sunDB.rW = if (sf) 0.00465f else Solar.dispR(0)
        if (proj(0f, 0f, 0f)) { sunDB.sx = pj[0]; sunDB.sy = pj[1]; sunDB.zf = pj[2]; sunDB.sr = max(F * sunDB.rW / pj[2], minPx(0)); sunVis = true } else { sunDB.zf = 0f; sunVis = false }
        sunSx = sunDB.sx; sunSy = sunDB.sy
        for (i in 1..8) {
            val d = planetDB[i]; d.wx = bx[i]; d.wy = by[i]; d.wz = bz[i]; d.rW = if (sf) Solar.R_KM[i] / 149597870f else Solar.dispR(i)
            if (i != surface && proj(d.wx, d.wy, d.wz)) { d.sx = pj[0]; d.sy = pj[1]; d.zf = pj[2]; d.sr = max(F * d.rW / pj[2], minPx(i)).coerceAtMost(6000f) } else d.zf = 0f
        }
        if (sf) { for (d in moonDB) d.zf = 0f; for (d in minorDB) d.zf = 0f; for (d in missionDB) d.zf = 0f; return }
        for (k in Solar.MOONS.indices) {
            val m = Solar.MOONS[k]; val d = moonDB[k]; val p = planetDB[m.parent]
            if (!showMoons || p.zf <= 0f || (p.sr < dp(22) && focus != m.parent)) { d.zf = 0f; continue }
            val a = m.phase0 + 2.0 * PI * simDays / m.periodD
            val rr = Solar.dispR(m.parent) * m.orbitMult; val ci = cos(Math.toRadians(m.incl.toDouble())); val si = sin(Math.toRadians(m.incl.toDouble()))
            d.wx = p.wx + (cos(a) * rr).toFloat(); d.wy = p.wy + (sin(a) * ci * rr).toFloat(); d.wz = p.wz + (sin(a) * si * rr).toFloat()
            d.rW = Solar.dispR(m.parent) * m.sizeRatio
            if (proj(d.wx, d.wy, d.wz)) { d.sx = pj[0]; d.sy = pj[1]; d.zf = pj[2]; d.sr = max(F * d.rW / pj[2], dp(2.6f)) } else d.zf = 0f
        }
        for (k in 0 until NM) {
            val d = minorDB[k]; val m = Deep.MINORS[k]
            if (!showMinor) { d.zf = 0f; continue }
            d.wx = mnx[k]; d.wy = mny[k]; d.wz = mnz[k]; d.rW = if (m.comet) 0.008f else 0.010f + 0.003f * (m.rKm / 1200f)
            if (proj(d.wx, d.wy, d.wz)) { d.sx = pj[0]; d.sy = pj[1]; d.zf = pj[2]; d.sr = max(F * d.rW / pj[2], dp(if (m.comet) 4f else 5.5f)) } else d.zf = 0f
        }
        for (k in 0 until NS) {
            val d = missionDB[k]
            if (!showMissions || !msOn[k]) { d.zf = 0f; continue }
            d.wx = msx[k]; d.wy = msy[k]; d.wz = msz[k]; d.rW = 0.01f
            if (proj(d.wx, d.wy, d.wz)) { d.sx = pj[0]; d.sy = pj[1]; d.zf = pj[2]; d.sr = max(F * d.rW / pj[2], dp(6f)) } else d.zf = 0f
        }
    }

    private fun drawSunGlow(c: Canvas, tt: Float) {
        if (!sunVis) return
        val sr = sunDB.sr; val pulse = 1f + 0.04f * sin(tt * 2f)
        val r1 = min(sr * 9f * pulse, vw * 3f)
        glowPaint.shader = RadialGradient(sunSx, sunSy, r1, intArrayOf(0x66FFA030, 0x22FF7A18, 0), floatArrayOf(0f, 0.35f, 1f), Shader.TileMode.CLAMP)
        c.drawCircle(sunSx, sunSy, r1, glowPaint)
        val r2 = min(sr * 3.4f, vw * 2f)
        glowPaint.shader = RadialGradient(sunSx, sunSy, r2, intArrayOf(0xBBFFD27A.toInt(), 0x55FFB04A, 0), floatArrayOf(0f, 0.5f, 1f), Shader.TileMode.CLAMP)
        c.drawCircle(sunSx, sunSy, r2, glowPaint)
        for (k in 0 until 26) {
            val a = tt * 0.12f + k * 0.2417f; val l = sr * (1.9f + 1.5f * (0.5f + 0.5f * sin(tt * 1.3f + k * 2.1f)))
            line.color = 0x30FFE6A8; line.strokeWidth = dp(1.4f)
            c.drawLine(sunSx + cos(a) * sr * 1.1f, sunSy + sin(a) * sr * 1.1f, sunSx + cos(a) * l, sunSy + sin(a) * l, line)
        }
        glowPaint.shader = null
    }

    private fun spriteRot(d: DB): Float {
        if (!sunVis) return 0f
        return Math.toDegrees((atan2(sunSy - d.sy, sunSx - d.sx) - atan2(-0.6f, -0.55f)).toDouble()).toFloat()
    }
    private fun drawSprite(c: Canvas, bmp: Bitmap?, d: DB, paint: Paint) {
        if (bmp == null) { fill.color = Color.GRAY; c.drawCircle(d.sx, d.sy, d.sr, fill); return }
        c.save(); c.translate(d.sx, d.sy); c.rotate(spriteRot(d)); dst.set(-d.sr, -d.sr, d.sr, d.sr); c.drawBitmap(bmp, null, dst, paint); c.restore()
    }
    private fun drawLive(c: Canvas, idx: Int, d: DB): Boolean {
        synchronized(liveLock) {
            val b = liveFront
            if (b != null && liveIdx == idx) { dst.set(d.sx - d.sr, d.sy - d.sr, d.sx + d.sr, d.sy + d.sr); c.drawBitmap(b, null, dst, bmpPaint); return true }
        }
        return false
    }

    private fun drawSun(c: Canvas, d: DB, tt: Float) {
        if (focus == 0 && d.sr >= dp(46) && drawLive(c, 0, d)) return
        val sp = SolarTex.sprites[0] ?: return
        c.save(); c.translate(d.sx, d.sy); c.rotate(tt * 3f); dst.set(-d.sr, -d.sr, d.sr, d.sr); c.drawBitmap(sp, null, dst, bmpPaint); c.restore()
    }
    private fun drawMoon(c: Canvas, d: DB) { drawSprite(c, SolarTex.sprites[9], d, moonPaints[d.id]) }

    private fun drawPlanet(c: Canvas, d: DB) {
        val i = d.id; val sr = d.sr
        val ac = Solar.ATMO[i]
        if (ac != 0) {
            val r = sr * 1.55f
            glowPaint.shader = RadialGradient(d.sx, d.sy, r, intArrayOf(0, alphaColor(ac, 0.0f), alphaColor(ac, 0.28f), 0), floatArrayOf(0f, 0.62f, 0.72f, 1f), Shader.TileMode.CLAMP)
            c.drawCircle(d.sx, d.sy, r, glowPaint); glowPaint.shader = null
        }
        if (i == 6) rings(c, d, true)
        if (!(focus == i && sr >= dp(46) && drawLive(c, i, d))) drawSprite(c, SolarTex.sprites[i], d, bmpPaint)
        if (i == 6) rings(c, d, false)
    }

    private fun drawMinor(c: Canvas, d: DB) {
        val m = Deep.MINORS[d.id]
        if (m.comet) { drawComet(c, d, m); return }
        glowPaint.shader = RadialGradient(d.sx, d.sy, d.sr * 2.4f, intArrayOf(alphaColor(m.color, 0.35f), 0), null, Shader.TileMode.CLAMP)
        c.drawCircle(d.sx, d.sy, d.sr * 2.4f, glowPaint); glowPaint.shader = null
        if (!(focus == 10 + d.id && d.sr >= dp(46) && drawLive(c, m.tex, d))) drawSprite(c, SolarTex.sprites[m.tex], d, bmpPaint)
    }

    private fun drawComet(c: Canvas, d: DB, m: Minor) {
        val r = mnR[d.id].toFloat()
        if (r < 9f) {
            val len = (2.4f / max(0.45f, r).pow(0.85f)).coerceAtMost(3.4f)
            val l = max(1e-6f, sqrt(d.wx * d.wx + d.wy * d.wy + d.wz * d.wz))
            val dxn = d.wx / l; val dyn = d.wy / l; val dzn = d.wz / l
            if (proj(d.wx + dxn * len, d.wy + dyn * len, d.wz + dzn * len)) {
                val ex = pj[0]; val ey = pj[1]
                // ion tail (straight, blue) and dust tail (curved, warm)
                glowPaint.style = Paint.Style.STROKE; glowPaint.strokeCap = Paint.Cap.ROUND
                glowPaint.shader = LinearGradient(d.sx, d.sy, ex, ey, 0xCC9AD8FF.toInt(), 0, Shader.TileMode.CLAMP); glowPaint.strokeWidth = dp(4.5f)
                c.drawLine(d.sx, d.sy, ex, ey, glowPaint)
                val mx = (d.sx + ex) / 2f; val my = (d.sy + ey) / 2f; val nxp = -(ey - d.sy) * 0.18f; val nyp = (ex - d.sx) * 0.18f
                path.reset(); path.moveTo(d.sx, d.sy); path.quadTo(mx + nxp, my + nyp, d.sx + (ex - d.sx) * 0.9f + nxp * 1.6f, d.sy + (ey - d.sy) * 0.9f + nyp * 1.6f)
                glowPaint.shader = LinearGradient(d.sx, d.sy, ex, ey, 0x99FFE2B0.toInt(), 0, Shader.TileMode.CLAMP); glowPaint.strokeWidth = dp(9f)
                c.drawPath(path, glowPaint)
                glowPaint.shader = null; glowPaint.style = Paint.Style.FILL
            }
        }
        glowPaint.shader = RadialGradient(d.sx, d.sy, d.sr * 3.2f, intArrayOf(0xCCD8F4FF.toInt(), 0x449AD8FF, 0), floatArrayOf(0f, 0.4f, 1f), Shader.TileMode.CLAMP)
        c.drawCircle(d.sx, d.sy, d.sr * 3.2f, glowPaint); glowPaint.shader = null
        fill.color = Color.WHITE; c.drawCircle(d.sx, d.sy, d.sr * 0.55f, fill)
    }

    private fun drawMission(c: Canvas, d: DB, tt: Float) {
        val m = Deep.MISSIONS[d.id]
        val r = dp(14f) * (1f + 0.15f * sin(tt * 4f))
        glowPaint.shader = RadialGradient(d.sx, d.sy, r, intArrayOf(alphaColor(m.color, 0.6f), 0), null, Shader.TileMode.CLAMP)
        c.drawCircle(d.sx, d.sy, r, glowPaint); glowPaint.shader = null
        val s = dp(5f)
        path.reset(); path.moveTo(d.sx, d.sy - s); path.lineTo(d.sx + s, d.sy); path.lineTo(d.sx, d.sy + s); path.lineTo(d.sx - s, d.sy); path.close()
        fill.color = Color.WHITE; c.drawPath(path, fill)
        ringPaint.color = m.color; ringPaint.strokeWidth = dp(1.6f); c.drawPath(path, ringPaint)
    }

    private fun rings(c: Canvas, d: DB, back: Boolean) {
        Solar.poleVec(6, pole)
        var ux0 = pole[1]; var uy0 = -pole[0]; val ul = max(1e-4f, sqrt(ux0 * ux0 + uy0 * uy0)); ux0 /= ul; uy0 /= ul
        val vx0 = -pole[2] * uy0; val vy0 = pole[2] * ux0; val vz0 = pole[0] * uy0 - pole[1] * ux0
        val rW = d.rW
        for (band in 0..2) {
            val rm = (ringBand1[band] + ringBand2[band]) * 0.5f * rW
            path.reset(); var inPath = false; var px = 0f; var py = 0f; var pz = 0f; var ok = false
            for (k in 0..72) {
                val th = k * 6.2831853f / 72f; val cs = cos(th); val sn = sin(th)
                val good = proj(d.wx + rm * (cs * ux0 + sn * vx0), d.wy + rm * (cs * uy0 + sn * vy0), d.wz + rm * (sn * vz0))
                if (good && ok) {
                    val front = (pz + pj[2]) * 0.5f < d.zf
                    if (front != back) { if (!inPath) { path.moveTo(px, py); inPath = true }; path.lineTo(pj[0], pj[1]) } else inPath = false
                } else inPath = false
                ok = good; px = pj[0]; py = pj[1]; pz = pj[2]
            }
            ringPaint.color = ringCol[band]; ringPaint.strokeWidth = max(dp(1f), (ringBand2[band] - ringBand1[band]) * rW * F / d.zf)
            c.drawPath(path, ringPaint)
        }
    }

    private fun updateJob() {
        val i = focus
        if (i < 0 || isMission(i)) { job = null; return }
        val d = when { i == 0 -> sunDB; i in 1..8 -> planetDB[i]; else -> minorDB[i - 10] }
        val tex = when { i in 0..8 -> i; else -> Deep.MINORS[i - 10].tex }
        if (tex < 0 || d.zf <= 0f || d.sr < dp(46)) { job = null; return }
        val size = ((min(340f, max(96f, d.sr * 2f)) / 8f).toInt() * 8).coerceIn(96, 336)
        if (i in 0..8) Solar.poleVec(i, pole) else { pole[0] = 0f; pole[1] = 0f; pole[2] = 1f }
        val axv = pole[0] * rx + pole[1] * ry + pole[2] * rz; val ayv = pole[0] * ux + pole[1] * uy + pole[2] * uz; val azv = -(pole[0] * fx + pole[1] * fy + pole[2] * fz)
        var lxw = -d.wx; var lyw = -d.wy; var lzw = -d.wz; val ll = max(1e-6f, sqrt(lxw * lxw + lyw * lyw + lzw * lzw)); lxw /= ll; lyw /= ll; lzw /= ll
        val lxv = lxw * rx + lyw * ry + lzw * rz; val lyv = lxw * ux + lyw * uy + lzw * uz; val lzv = -(lxw * fx + lyw * fy + lzw * fz)
        val rot = if (i in 0..8) Solar.ROT_H[i] else Deep.MINORS[i - 10].rotH
        val spin = (((simDays * 24.0 / rot) % 1.0) * 2.0 * PI).toFloat()
        job = SphereJob(tex, size, axv, ayv, azv, spin, lxv, lyv, lzv)
    }

    private fun fit(s: String, p: Paint, maxW: Float): String {
        if (p.measureText(s) <= maxW) return s
        var t = s; while (t.length > 3 && p.measureText("$t\u2026") > maxW) t = t.dropLast(1)
        return "$t\u2026"
    }
    private fun drawLabels(c: Canvas) {
        placed.clear()
        fun lab(name: String, d: DB, big: Boolean, col: Int) {
            if (d.kind == 1 && focus == d.id && d.sr > dp(60)) return
            txt.textSize = dp(if (big) 12f else 10.5f); txtS.textSize = txt.textSize
            val tw = txt.measureText(name); val x = d.sx - tw / 2f; val y = d.sy - d.sr - dp(8)
            val rc = RectF(x - dp(3), y - txt.textSize, x + tw + dp(3), y + dp(4))
            if (rc.right < 0 || rc.left > vw || rc.bottom < 0 || rc.top > vh) return
            for (p in placed) if (RectF.intersects(p, rc)) return
            placed.add(rc)
            txt.color = alphaColor(col, 0.95f); txtS.alpha = 190
            c.drawText(name, x, y, txtS); c.drawText(name, x, y, txt)
        }
        if (sunDB.zf > 0f) lab("Sun", sunDB, true, Color.WHITE)
        for (i in 1..8) if (planetDB[i].zf > 0f) lab(Solar.NAMES[i], planetDB[i], true, Color.WHITE)
        for (k in 0 until NM) if (minorDB[k].zf > 0f) lab(Deep.MINORS[k].name, minorDB[k], false, 0xFFCFE6FF.toInt())
        for (k in 0 until NS) if (missionDB[k].zf > 0f) lab(Deep.MISSIONS[k].name, missionDB[k], true, Deep.MISSIONS[k].color)
        if (surface < 1) for (k in Solar.MOONS.indices) if (moonDB[k].zf > 0f && focus == Solar.MOONS[k].parent) lab(Solar.MOONS[k].name, moonDB[k], false, 0xFFDDDDDD.toInt())
        txt.textSize = dp(11)
    }

    private fun drawFlare(c: Canvas) {
        if (!sunVis) return
        if (sunSx < -vw || sunSx > 2 * vw || sunSy < -vh || sunSy > 2 * vh) return
        val vx = cxv - sunSx; val vy = cyv - sunSy
        val dist = sqrt(vx * vx + vy * vy)
        val k = (1f - dist / (vw * 1.1f)).coerceIn(0f, 1f) * (if (focus == 0) 0.25f else 1f)
        if (k < 0.03f) return
        val ts = floatArrayOf(0.35f, 0.8f, 1.25f, 1.75f); val rs = floatArrayOf(dp(24), dp(13), dp(38), dp(17))
        val cols = intArrayOf(0x66FFA040, 0x6640C8FF, 0x55FF7090, 0x66FFE080)
        for (i in 0..3) {
            val x = sunSx + vx * ts[i]; val y = sunSy + vy * ts[i]
            glowPaint.shader = RadialGradient(x, y, rs[i], intArrayOf(alphaColor(cols[i], 0.55f * k), 0), null, Shader.TileMode.CLAMP)
            c.drawCircle(x, y, rs[i], glowPaint)
        }
        glowPaint.shader = null
    }

    private fun speedText(): String {
        if (!playing) return "Paused"
        var best = 0; var bd = Double.MAX_VALUE
        for (i in Solar.SPEEDS.indices) { val dd = abs(ln(Solar.SPEEDS[i] / daysPerSec)); if (dd < bd) { bd = dd; best = i } }
        return Solar.SPEED_NAMES[best]
    }
    private fun drawHud(c: Canvas) {
        backR.set(dp(14), dp(40), dp(104), dp(80)); fill.color = 0x40101830; c.drawRoundRect(backR, dp(20), dp(20), fill)
        txt.textAlign = Paint.Align.CENTER; txt.color = Color.WHITE; txt.textSize = dp(14); c.drawText("\u2039 Back", backR.centerX(), backR.centerY() + dp(5), txt)
        if (focus >= 0 || surface >= 1) {
            sysR.set(vw - dp(150), dp(40), vw - dp(14), dp(80)); fill.color = 0x40101830; c.drawRoundRect(sysR, dp(20), dp(20), fill)
            c.drawText(if (surface >= 1) "Leave surface" else "System view", sysR.centerX(), sysR.centerY() + dp(5), txt)
        } else sysR.setEmpty()
        if (focus in 1..8 && surface < 1) {
            standR.set(vw - dp(150), dp(88), vw - dp(14), dp(126)); fill.color = 0x40101830; c.drawRoundRect(standR, dp(20), dp(20), fill)
            txt.color = C.CYAN; c.drawText("Stand here", standR.centerX(), standR.centerY() + dp(5), txt)
        } else standR.setEmpty()
        val ms = ((simDays + 2451545.0 - 2440587.5) * 86400000.0).toLong()
        txt.textAlign = Paint.Align.LEFT
        txt.textSize = dp(13); txt.color = 0xE6FFFFFF.toInt(); c.drawText(df.format(Date(ms)), dp(18), dp(104), txt)
        val extra = (if (trueScale && surface < 1) "  \u00B7  true scale" else "") + (if (showMissions && surface < 1) "  \u00B7  missions" else "")
        txt.textSize = dp(11.5f); txt.color = C.CYAN; c.drawText(speedText() + extra, dp(18), dp(121), txt)
        txt.textSize = dp(11)
    }

    private fun fmtLight(au: Double): String { val s = (au * 499.005).toInt(); return if (s >= 3600) "${s / 3600} h ${(s % 3600) / 60} min" else "${s / 60} min ${s % 60} s" }
    private fun drawLines(c: Canvas, x: Float, mw: Float, top: Float, lines: List<String>, col: Int, accent: Int, appear: Float) {
        for ((k, s) in lines.withIndex()) {
            val last = k == lines.size - 1 && lines.size >= 5
            txt.textSize = dp(if (last) 11.5f else 12.5f); txt.color = alphaColor(if (last) accent else col, appear)
            c.drawText(fit(s, txt, mw), x, top + dp(54) + k * dp(19), txt)
        }
        txt.textSize = dp(11)
    }
    private fun drawCard(c: Canvas) {
        val i = focus; val appear = ease(transT)
        val title: String; val type: String; val col: Int
        val lines = ArrayList<String>()
        if (i == 0) {
            title = "Sun"; type = Solar.TYPE[0]; col = Solar.COL[0]
            lines.add("Surface 5,500 \u00B0C \u00B7 core 15 million \u00B0C"); lines.add("Radius 695,700 km \u00B7 109 \u00D7 Earth")
            lines.add("Sunlight takes 8 min 20 s to reach Earth"); lines.add("Rotates once in about 25 days")
        } else if (i in 1..8) {
            title = Solar.NAMES[i]; type = Solar.TYPE[i]; col = Solar.COL[i]
            val r = helioR[i]; val a = Solar.semiMajor(i, simDays); val v = 29.78 * sqrt(max(0.0, 2.0 / r - 1.0 / a))
            lines.add(String.format("Distance from Sun %.3f AU \u00B7 %.1f M km", r, r * 149.598))
            lines.add(String.format("Speed %.1f km/s \u00B7 light takes %s", v, fmtLight(r)))
            val y = Solar.YEAR_D[i]
            lines.add("Day " + Solar.DAY[i] + " \u00B7 Year " + (if (y >= 1000) String.format("%.1f yr", y / 365.25) else String.format("%.0f d", y)))
            lines.add(String.format("Radius %,d km \u00B7 %s \u00B7 %s", Solar.R_KM[i].toInt(), Solar.GRAV[i], Solar.TEMP[i]))
            lines.add(Solar.MOONS_TXT[i] + " \u00B7 " + Solar.FACT[i])
        } else if (isMinor(i)) {
            val m = Deep.MINORS[i - 10]; title = m.name; type = if (m.comet) "Comet" else "Dwarf planet"; col = m.color
            val r = mnR[i - 10]; val v = 29.78 * sqrt(max(0.0, 2.0 / r - 1.0 / m.a))
            lines.add(String.format("Distance from Sun %.2f AU \u00B7 %.1f M km", r, r * 149.598))
            lines.add(String.format("Speed %.1f km/s \u00B7 light takes %s", v, fmtLight(r)))
            lines.addAll(m.info)
        } else {
            val k = i - 30; val m = Deep.MISSIONS[k]; title = m.name; type = "Spacecraft"; col = m.color
            val r = msR[k]; val v = if (m.conic != null) 29.78 * sqrt(max(0.0, 2.0 / max(r, 0.01) - 1.0 / m.conic[0])) else m.speed
            val ms = ((m.launch + 2451545.0 - 2440587.5) * 86400000.0).toLong()
            lines.add("Launched " + df2.format(Date(ms)) + String.format(" \u00B7 %.1f AU out", r))
            lines.add(String.format("Speed %.1f km/s \u00B7 signal takes %s", v, fmtLight(r)))
            lines.addAll(m.info)
        }
        val cw = min(vw - dp(24), dp(350)); val ch = dp(142)
        val top = vh - bottomPad - ch - dp(8) + (1f - appear) * dp(40)
        card.set((vw - cw) / 2f, top, (vw + cw) / 2f, top + ch)
        fill.color = alphaColor(0xFF0B1022.toInt(), 0.92f * appear); c.drawRoundRect(card, dp(24), dp(24), fill)
        line.color = alphaColor(col, 0.6f * appear); line.strokeWidth = dp(1.2f); c.drawRoundRect(card, dp(24), dp(24), line)
        val x = card.left + dp(18); val mw = card.width() - dp(36)
        txt.textSize = dp(19); txt.color = alphaColor(Color.WHITE, appear); c.drawText(fit(title, txt, mw - dp(100)), x, card.top + dp(30), txt)
        txt.textSize = dp(11.5f); txt.color = alphaColor(col, appear); txt.textAlign = Paint.Align.RIGHT; c.drawText(type, card.right - dp(18), card.top + dp(29), txt); txt.textAlign = Paint.Align.LEFT
        drawLines(c, x, mw, card.top, lines, 0xFFC9D2EE.toInt(), col, appear)
    }
    private fun drawSurfaceCard(c: Canvas) {
        val i = surface; val cw = min(vw - dp(24), dp(350)); val ch = dp(142)
        card.set((vw - cw) / 2f, vh - bottomPad - ch - dp(8), (vw + cw) / 2f, vh - bottomPad - dp(8))
        fill.color = alphaColor(0xFF0B1022.toInt(), 0.85f); c.drawRoundRect(card, dp(24), dp(24), fill)
        line.color = alphaColor(Solar.COL[i], 0.6f); line.strokeWidth = dp(1.2f); c.drawRoundRect(card, dp(24), dp(24), line)
        val x = card.left + dp(18); val mw = card.width() - dp(36)
        txt.textSize = dp(19); txt.color = Color.WHITE; c.drawText("Standing on " + Solar.NAMES[i], x, card.top + dp(30), txt)
        val h = solarTime.toInt(); val mi = ((solarTime - h) * 60f).toInt()
        val lines = listOf(String.format("Local solar time %02d:%02d", h, mi),
            String.format("Sun %s the horizon \u00B7 elevation %+d\u00B0", if (sunEl >= 0) "above" else "below", sunEl.toInt()),
            "Day length " + Solar.DAY[i], "Gravity " + Solar.GRAV[i] + " \u00B7 " + Solar.TEMP[i], "Drag to look around \u00B7 pinch to zoom the view")
        drawLines(c, x, mw, card.top, lines, 0xFFC9D2EE.toInt(), Solar.COL[i], 1f)
    }

    // ------------------------------------------------------------------ touch
    override fun onTouchEvent(e: MotionEvent): Boolean {
        scaleDet.onTouchEvent(e); gestDet.onTouchEvent(e)
        if (scaleDet.isInProgress || e.pointerCount > 1) { moved += 200f; downX = e.x; downY = e.y; touching = true; lastTouch = SystemClock.uptimeMillis(); return true }
        when (e.actionMasked) {
            MotionEvent.ACTION_DOWN -> { touching = true; downX = e.x; downY = e.y; moved = 0f; velYaw = 0f; velPitch = 0f; downT = SystemClock.uptimeMillis(); lastTouch = downT }
            MotionEvent.ACTION_MOVE -> {
                val dx = e.x - downX; val dy = e.y - downY; moved += abs(dx) + abs(dy)
                if (surface >= 1) { sYaw -= dx * 0.005f / fovScale; sPitch = (sPitch + dy * 0.005f / fovScale).coerceIn(-0.35f, 1.5f) }
                else { yaw -= dx * 0.0065f; pitch = (pitch + dy * 0.0065f).coerceIn(-1.5f, 1.5f) }
                lastDx = dx; lastDy = dy; downX = e.x; downY = e.y; lastTouch = SystemClock.uptimeMillis()
            }
            MotionEvent.ACTION_UP -> {
                touching = false; lastTouch = SystemClock.uptimeMillis()
                if (moved < dp(12) && lastTouch - downT < 350L) {
                    if (backR.contains(e.x, e.y)) { onExit?.invoke(); return true }
                    if (!sysR.isEmpty && sysR.contains(e.x, e.y)) { goOverview(); thud(); return true }
                    if (!standR.isEmpty && standR.contains(e.x, e.y)) { enterSurface(focus); thud(); return true }
                    if (surface >= 1) return true
                    var best: DB? = null; var bd = Float.MAX_VALUE
                    for (d in hits) { val dd = hypot(d.sx - e.x, d.sy - e.y); val lim = max(d.sr * 1.25f, dp(30)); if (dd < lim && dd < bd) { bd = dd; best = d } }
                    if (best != null) { focusOn(when (best.kind) { 0 -> 0; 1 -> best.id; 3 -> 10 + best.id; else -> 30 + best.id }); thud() }
                } else if (surface < 1) { velYaw = -lastDx * 0.0065f * 30f * 0.6f; velPitch = lastDy * 0.0065f * 30f * 0.6f }
            }
            MotionEvent.ACTION_CANCEL -> touching = false
        }
        return true
    }
}
