package com.chronox.clock

import android.animation.ValueAnimator
import android.content.Context
import android.graphics.*
import android.graphics.drawable.GradientDrawable
import android.os.SystemClock
import android.view.*
import android.view.animation.DecelerateInterpolator
import android.view.animation.OvershootInterpolator
import android.widget.*
import kotlin.math.*

/** ScrollView whose children tilt, shrink and fade as they approach the top / bottom edge. */
class FxScrollView(ctx: Context, private val strength: Float = 1f) : ScrollView(ctx) {
    init { isVerticalScrollBarEnabled = false; overScrollMode = OVER_SCROLL_NEVER; clipToPadding = false }
    override fun onScrollChanged(l: Int, t: Int, ol: Int, ot: Int) { super.onScrollChanged(l, t, ol, ot); applyFx() }
    override fun onLayout(changed: Boolean, l: Int, t: Int, r: Int, b: Int) { super.onLayout(changed, l, t, r, b); applyFx() }
    fun applyFx() {
        val c = getChildAt(0) as? ViewGroup ?: return
        val vh = height.toFloat(); if (vh <= 0f) return
        val edge = dp(80)
        for (i in 0 until c.childCount) {
            val v = c.getChildAt(i)
            val cy = v.top + v.height / 2f - scrollY
            val dTop = (edge - cy) / edge
            val dBot = (cy - (vh - edge)) / edge
            val d = smooth(max(dTop, dBot))
            v.cameraDistance = 9000f * DENSITY
            v.pivotY = if (dTop > dBot) v.height.toFloat() else 0f
            v.scaleX = 1f - 0.10f * d * strength
            v.scaleY = v.scaleX
            v.alpha = 1f - 0.65f * d * strength
            v.rotationX = (if (dTop > dBot) 1f else -1f) * 16f * d * strength
        }
    }
}

class WheelView(ctx: Context, private val items: List<String>, private val loop: Boolean) : View(ctx) {
    var onChange: (() -> Unit)? = null
    private val n = items.size
    private var pos = 0f
    private var lastTick = Int.MIN_VALUE
    private var anim: ValueAnimator? = null
    private var vt: VelocityTracker? = null
    private var lastY = 0f
    private val p = textPaint(C.TEXT, dp(30), LIGHT, Paint.Align.CENTER)
    private val band = fillPaint(C.GLASS)
    private val bandStroke = strokePaint(C.GLASS2, dp(1))

    val selectedIndex: Int get() = fmod(pos.roundToInt(), n)

    override fun onSizeChanged(w: Int, h: Int, ow: Int, oh: Int) { p.textSize = h / 5f * 0.80f }

    fun setSelected(i: Int, animate: Boolean) {
        anim?.cancel()
        val target: Float = if (loop) {
            val base = pos.roundToInt()
            var delta = i - fmod(base, n)
            if (delta > n / 2) delta -= n
            if (delta < -n / 2) delta += n
            (base + delta).toFloat()
        } else i.toFloat()
        if (!animate) { pos = target; lastTick = target.roundToInt(); invalidate(); return }
        anim = animF(pos, target, 450L, DecelerateInterpolator(2f)) { pos = it; invalidate() }
    }

    override fun onDraw(c: Canvas) {
        val cy = height / 2f; val ih = height / 5f
        val r = RectF(dp(4), cy - ih * 0.5f, width - dp(4), cy + ih * 0.5f)
        c.drawRoundRect(r, dp(14), dp(14), band); c.drawRoundRect(r, dp(14), dp(14), bandStroke)
        val base = pos.roundToInt()
        val rad = ih / 0.42f
        for (k in -3..3) {
            val idx = base + k
            if (!loop && (idx < 0 || idx >= n)) continue
            val rel = idx - pos
            val ang = rel * 0.42f
            if (abs(ang) > 1.35f) continue
            val y = cy + rad * sin(ang)
            val s = cos(ang)
            p.color = mixColor(C.DIM, C.TEXT, 1f - min(1f, abs(rel)))
            p.alpha = (255f * s * s * s).toInt().coerceIn(0, 255)
            c.save(); c.translate(width / 2f, y); c.scale(0.78f + 0.22f * s, s)
            c.drawText(items[fmod(idx, n)], 0f, -(p.ascent() + p.descent()) / 2f, p)
            c.restore()
        }
    }

    private fun moveBy(d: Float) {
        pos += d
        if (!loop) pos = pos.coerceIn(0f, (n - 1).toFloat())
        onTickCheck(); invalidate()
    }
    private fun onTickCheck() {
        val nr = pos.roundToInt()
        if (nr != lastTick) { lastTick = nr; tick(); onChange?.invoke() }
    }

    override fun onTouchEvent(e: MotionEvent): Boolean {
        val ih = height / 5f
        when (e.actionMasked) {
            MotionEvent.ACTION_DOWN -> {
                parent?.requestDisallowInterceptTouchEvent(true); anim?.cancel()
                lastY = e.y; vt?.recycle(); vt = VelocityTracker.obtain(); vt?.addMovement(e)
            }
            MotionEvent.ACTION_MOVE -> { vt?.addMovement(e); val dy = e.y - lastY; lastY = e.y; moveBy(-dy / ih) }
            MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> {
                vt?.addMovement(e); vt?.computeCurrentVelocity(1000)
                val v = -(vt?.yVelocity ?: 0f) / ih
                vt?.recycle(); vt = null
                var target = (pos + v * 0.32f).roundToInt()
                if (!loop) target = target.coerceIn(0, n - 1)
                val dist = abs(target - pos)
                anim = animF(pos, target.toFloat(), (260f + dist * 45f).coerceAtMost(900f).toLong(), DecelerateInterpolator(1.8f), 0L, {
                    if (loop) pos = fmod(pos.roundToInt(), n).toFloat().also { lastTick = it.toInt() }
                    invalidate()
                }) { pos = it; onTickCheck(); invalidate() }
            }
        }
        return true
    }
}

class TimePickerView(ctx: Context, val is24: Boolean) : LinearLayout(ctx) {
    var onChanged: (() -> Unit)? = null
    private fun nums(a: Int, b: Int, pad: Boolean) = (a..b).map { if (pad) two(it) else "$it" }
    val hours = WheelView(ctx, if (is24) nums(0, 23, true) else nums(1, 12, false), true)
    val mins = WheelView(ctx, nums(0, 59, true), true)
    val ap: WheelView? = if (is24) null else WheelView(ctx, listOf("AM", "PM"), false)
    init {
        orientation = HORIZONTAL; gravity = Gravity.CENTER
        addView(hours, LayoutParams(dpi(92), dpi(200)))
        addView(TextView(ctx).apply { text = ":"; textSize = 34f; typeface = THIN; setTextColor(C.DIM); gravity = Gravity.CENTER; includeFontPadding = false },
            LayoutParams(dpi(20), dpi(200)))
        addView(mins, LayoutParams(dpi(92), dpi(200)))
        ap?.let { addView(it, LayoutParams(dpi(84), dpi(200)).apply { leftMargin = dpi(8) }) }
        val cb = { onChanged?.invoke(); Unit }
        hours.onChange = cb; mins.onChange = cb; ap?.onChange = cb
    }
    fun set(h24: Int, m: Int) {
        if (is24) hours.setSelected(h24, false) else { hours.setSelected((if (h24 % 12 == 0) 12 else h24 % 12) - 1, false); ap?.setSelected(if (h24 < 12) 0 else 1, false) }
        mins.setSelected(m, false)
    }
    fun hour24(): Int = if (is24) hours.selectedIndex else ((hours.selectedIndex + 1) % 12) + (if ((ap?.selectedIndex ?: 0) == 1) 12 else 0)
    fun minute(): Int = mins.selectedIndex
}

class ChipRow(ctx: Context, labels: List<String>, sel: Int, private val accent: Int, private val onSel: (Int) -> Unit) : HorizontalScrollView(ctx) {
    private val row = LinearLayout(ctx)
    private val chips = ArrayList<TextView>()
    private val prog = FloatArray(labels.size)
    var selected = sel
    init {
        isHorizontalScrollBarEnabled = false; overScrollMode = OVER_SCROLL_NEVER; clipToPadding = false
        row.orientation = LinearLayout.HORIZONTAL; addView(row)
        labels.forEachIndexed { i, s ->
            val tv = TextView(ctx).apply {
                text = s; textSize = 14f; typeface = MED; gravity = Gravity.CENTER
                setPadding(dpi(16), dpi(10), dpi(16), dpi(10))
                background = GradientDrawable().apply { cornerRadius = dp(22) }
                setOnClickListener { if (selected != i) { select(i, true); thud() }; onSel(i) }
                pressable()
            }
            row.addView(tv, LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply { rightMargin = dpi(8) })
            chips.add(tv); prog[i] = if (i == sel) 1f else 0f; style(i)
        }
    }
    private fun style(i: Int) {
        val t = prog[i]; val g = chips[i].background as GradientDrawable
        g.setColor(mixColor(0x14FFFFFF, alphaColor(accent, 0.22f), t))
        g.setStroke(dpi(1), mixColor(0x1FFFFFFF, accent, t))
        chips[i].setTextColor(mixColor(C.DIM, accent, t))
    }
    fun select(i: Int, animate: Boolean) {
        val old = selected; selected = i
        if (!animate) { chips.indices.forEach { prog[it] = if (it == i) 1f else 0f; style(it) }; return }
        val o0 = if (old in prog.indices) prog[old] else 0f; val n0 = if (i in prog.indices) prog[i] else 0f
        animF(0f, 1f, 260L, DecelerateInterpolator()) { t ->
            if (old in prog.indices && old != i) { prog[old] = o0 * (1 - t); style(old) }
            if (i in prog.indices) { prog[i] = n0 + (1 - n0) * t; style(i) }
        }
    }
}

class DaysView(ctx: Context, var mask: Int, private val accent: Int, private val onChange: (Int) -> Unit) : View(ctx) {
    private val prog = FloatArray(7) { if ((mask and (1 shl it)) != 0) 1f else 0f }
    private val bg = fillPaint(); private val tp = textPaint(C.DIM, dp(15), MED, Paint.Align.CENTER)
    override fun onDraw(c: Canvas) {
        val cell = width / 7f; val r = min(cell / 2f - dp(3), dp(22))
        for (i in 0 until 7) {
            val cx = cell * (i + 0.5f); val cy = height / 2f; val t = prog[i]
            bg.color = mixColor(C.GLASS, alphaColor(accent, 0.95f), t)
            c.drawCircle(cx, cy, r * (1f + 0.06f * t), bg)
            tp.color = mixColor(C.DIM, 0xFF05060D.toInt(), t)
            c.drawText(DAY_LETTERS[i], cx, cy - (tp.ascent() + tp.descent()) / 2f, tp)
        }
    }
    override fun onTouchEvent(e: MotionEvent): Boolean {
        if (e.actionMasked == MotionEvent.ACTION_DOWN) return true
        if (e.actionMasked == MotionEvent.ACTION_UP) {
            val i = (e.x / (width / 7f)).toInt().coerceIn(0, 6)
            mask = mask xor (1 shl i); tick()
            val to = if ((mask and (1 shl i)) != 0) 1f else 0f
            animF(prog[i], to, 240L, OvershootInterpolator(2f)) { prog[i] = it; invalidate() }
            onChange(mask)
        }
        return true
    }
}

class SwitchView(ctx: Context, on: Boolean, private val accent: Int, private val onChange: (Boolean) -> Unit) : View(ctx) {
    var checked = on
    private var p = if (on) 1f else 0f
    private val paint = fillPaint()
    override fun onMeasure(w: Int, h: Int) { setMeasuredDimension(dpi(58), dpi(32)) }
    override fun onDraw(c: Canvas) { drawSwitch(c, 0f, 0f, width.toFloat(), height.toFloat(), p, accent, paint) }
    init { setOnClickListener { checked = !checked; thud(); animF(p, if (checked) 1f else 0f, 260L, OvershootInterpolator(1.4f)) { p = it; invalidate() }; onChange(checked) } }
}

class ThemePicker(ctx: Context, var sel: Int, private val onSel: (Int) -> Unit) : View(ctx) {
    private val n = THEMES.size + 1
    private val cw = dp(78); private val gap = dp(10)
    private val prog = FloatArray(n) { if (it == sel) 1f else 0f }
    private val fill = fillPaint(); private val ring = strokePaint(Color.WHITE, dp(2.2f))
    private val tp = textPaint(Color.WHITE, dp(12), MED, Paint.Align.CENTER)
    override fun onMeasure(w: Int, h: Int) { setMeasuredDimension(((cw + gap) * n + dp(4)).toInt(), dpi(100)) }
    override fun onDraw(c: Canvas) {
        for (i in 0 until n) {
            val l = i * (cw + gap) + dp(2); val t = dp(4) ; val b = height - dp(10)
            val s = 1f + 0.06f * prog[i]
            c.save(); c.scale(s, s, l + cw / 2, (t + b) / 2)
            val rect = RectF(l, t, l + cw, b)
            if (i < THEMES.size) {
                val th = THEMES[i]
                fill.shader = LinearGradient(l, t, l + cw, b, intArrayOf(th.bg, mixColor(th.bg, th.c2, 0.55f), th.c1), floatArrayOf(0f, 0.55f, 1f), Shader.TileMode.CLAMP)
            } else {
                fill.shader = LinearGradient(l, t, l + cw, b, intArrayOf(THEMES[1].c1, THEMES[3].c1, THEMES[2].c1), null, Shader.TileMode.CLAMP)
            }
            c.drawRoundRect(rect, dp(18), dp(18), fill); fill.shader = null
            ring.alpha = (255 * prog[i]).toInt(); c.drawRoundRect(rect, dp(18), dp(18), ring)
            c.drawText(if (i < THEMES.size) THEMES[i].name else "Auto", l + cw / 2, b - dp(12), tp)
            c.restore()
        }
    }
    override fun onTouchEvent(e: MotionEvent): Boolean {
        if (e.actionMasked == MotionEvent.ACTION_DOWN) return true
        if (e.actionMasked == MotionEvent.ACTION_UP) {
            val i = ((e.x - dp(2)) / (cw + gap)).toInt().coerceIn(0, n - 1)
            val idx = if (i < THEMES.size) i else 6
            if (idx != sel) {
                val old = if (sel < THEMES.size) sel else n - 1
                sel = idx; thud()
                animF(0f, 1f, 280L, DecelerateInterpolator()) { t -> prog[old] = 1 - t; prog[i] = t; invalidate() }
                onSel(idx)
            }
        }
        return true
    }
}

/** Round glass / gradient button with cross-fading icon. */
class CircleBtn(ctx: Context, private val d: Float, private val primary: Boolean) : View(ctx) {
    companion object { const val PLAY = 0; const val PAUSE = 1; const val RESET = 2; const val LAP = 3; const val TEXT = 4 }
    var type = PLAY; private var old = PLAY; private var swap = 1f
    var label = ""
    var accent = C.CYAN; var accent2 = C.VIOLET
    var dimmed = false; set(v) { field = v; invalidate() }
    private val fill = fillPaint(); private val st = strokePaint(Color.WHITE, dp(2.4f)); private val path = Path()
    private val tp = textPaint(Color.WHITE, dp(17), BOLD, Paint.Align.CENTER)
    override fun onMeasure(w: Int, h: Int) { setMeasuredDimension(d.toInt(), d.toInt()) }
    fun setIcon(t: Int, animate: Boolean = true) {
        if (t == type) return
        old = type; type = t; swap = 0f
        if (animate) animF(0f, 1f, 300L, OvershootInterpolator(1.3f)) { swap = it; invalidate() } else { swap = 1f; invalidate() }
    }
    init { pressable() }
    override fun onDraw(c: Canvas) {
        val cx = width / 2f; val r = width / 2f - dp(5)
        val alpha = if (dimmed) 0.4f else 1f
        if (primary) {
            fill.color = alphaColor(accent, 0.22f * alpha); c.drawCircle(cx, cx, r + dp(4), fill)
            fill.shader = LinearGradient(0f, 0f, width.toFloat(), height.toFloat(), accent, accent2, Shader.TileMode.CLAMP)
            fill.alpha = (255 * alpha).toInt()
        } else { fill.shader = null; fill.color = alphaColor(0xFFFFFFFF.toInt(), 0.10f * alpha) }
        c.drawCircle(cx, cx, r, fill); fill.shader = null; fill.alpha = 255
        val ink = if (primary) 0xFF05060D.toInt() else C.TEXT
        icon(c, old, cx, ink, (1f - swap) * alpha, 1f - 0.4f * swap, -90f * swap)
        icon(c, type, cx, ink, swap * alpha, 0.6f + 0.4f * swap, 90f * (1f - swap))
    }
    private fun icon(c: Canvas, t: Int, cx: Float, ink: Int, a: Float, s: Float, rot: Float) {
        if (a <= 0.01f) return
        c.save(); c.translate(cx, cx); c.scale(s, s); c.rotate(rot)
        val u = width * 0.17f
        fill.color = alphaColor(ink, a); st.color = alphaColor(ink, a); st.strokeWidth = dp(2.6f)
        when (t) {
            PLAY -> { path.reset(); path.moveTo(-u * 0.7f, -u); path.lineTo(u * 1.1f, 0f); path.lineTo(-u * 0.7f, u); path.close(); c.drawPath(path, fill) }
            PAUSE -> { c.drawRoundRect(-u * 0.95f, -u, -u * 0.2f, u, dp(3), dp(3), fill); c.drawRoundRect(u * 0.2f, -u, u * 0.95f, u, dp(3), dp(3), fill) }
            RESET -> { val r = RectF(-u, -u, u, u); c.drawArc(r, -60f, 300f, false, st); path.reset(); path.moveTo(u * 0.95f, -u * 1.25f); path.lineTo(u * 0.95f, -u * 0.1f); path.lineTo(-u * 0.1f, -u * 0.55f); path.close(); c.drawPath(path, fill) }
            LAP -> { c.drawLine(-u * 0.7f, -u * 1.1f, -u * 0.7f, u * 1.1f, st); path.reset(); path.moveTo(-u * 0.7f, -u * 1.0f); path.lineTo(u * 1.1f, -u * 0.45f); path.lineTo(-u * 0.7f, u * 0.1f); path.close(); c.drawPath(path, fill) }
            else -> { tp.color = alphaColor(ink, a); c.drawText(label, 0f, -(tp.ascent() + tp.descent()) / 2f, tp) }
        }
        c.restore()
    }
}

/** Slow-drifting colour blobs + twinkling stars behind everything. */
class AuroraView(ctx: Context) : View(ctx) {
    private val cols = intArrayOf(C.VIOLET, C.CYAN, C.MAGENTA, C.ORANGE)
    private val targets = arrayOf(
        floatArrayOf(1f, 0.35f, 0.5f, 0.10f), floatArrayOf(0.4f, 1f, 0.2f, 0.25f),
        floatArrayOf(0.5f, 0.4f, 1f, 0.2f), floatArrayOf(0.3f, 0.5f, 0.35f, 0.9f))
    private val w = floatArrayOf(1f, 0.35f, 0.5f, 0.1f)
    private val paints = Array(4) { fillPaint() }
    private val star = fillPaint()
    private val sx = FloatArray(60); private val sy = FloatArray(60); private val sp = FloatArray(60)
    private var r = 0f
    init { val rnd = java.util.Random(7); for (i in 0 until 60) { sx[i] = rnd.nextFloat(); sy[i] = rnd.nextFloat(); sp[i] = 0.5f + rnd.nextFloat() * 2f } }
    override fun onSizeChanged(nw: Int, nh: Int, ow: Int, oh: Int) {
        r = max(nw, nh) * 0.58f
        for (i in 0 until 4) paints[i].shader = RadialGradient(0f, 0f, r, intArrayOf(alphaColor(cols[i], 0.40f), alphaColor(cols[i], 0f)), null, Shader.TileMode.CLAMP)
    }
    fun setTab(i: Int) {
        val from = w.copyOf(); val to = targets[i]
        animF(0f, 1f, 700L, DecelerateInterpolator()) { t -> for (k in 0 until 4) w[k] = from[k] + (to[k] - from[k]) * t }
    }
    override fun onDraw(c: Canvas) {
        c.drawColor(C.BG)
        val t = (SystemClock.uptimeMillis() % 1_000_000L) / 1000f
        val W = width.toFloat(); val H = height.toFloat()
        for (i in 0 until 4) {
            val x = W * (0.5f + 0.42f * sin(t * (0.11f + i * 0.03f) + i * 1.7f))
            val y = H * (0.5f + 0.42f * cos(t * (0.09f + i * 0.025f) + i * 2.3f))
            c.save(); c.translate(x, y); paints[i].alpha = (255 * w[i]).toInt(); c.drawCircle(0f, 0f, r, paints[i]); c.restore()
        }
        for (i in 0 until 60) {
            val a = 0.15f + 0.45f * (0.5f + 0.5f * sin(t * sp[i] + i))
            star.color = alphaColor(Color.WHITE, a); c.drawCircle(sx[i] * W, sy[i] * H, dp(1.1f), star)
        }
        postInvalidateOnAnimation()
    }
}

class BottomNavView(ctx: Context) : View(ctx) {
    var onSelect: ((Int) -> Unit)? = null
    private val labels = arrayOf("Alarm", "World", "Timer", "Stopwatch")
    private val accents = intArrayOf(C.VIOLET, C.CYAN, C.MAGENTA, C.ORANGE)
    private var sel = 0; private var selPos = 0f; private var target = 0f
    private val pill = fillPaint(0xEE0C1022.toInt()); private val edge = strokePaint(0x30FFFFFF, dp(1))
    private val blob = fillPaint(); private val ip = strokePaint(Color.WHITE, dp(2.1f)); private val ifill = fillPaint()
    private val lp = textPaint(Color.WHITE, dp(11), MED, Paint.Align.CENTER)
    private val rect = RectF(); private val path = Path()
    override fun onMeasure(w: Int, h: Int) { setMeasuredDimension(MeasureSpec.getSize(w), dpi(76)) }
    fun select(i: Int, animate: Boolean = true) {
        sel = i; target = i.toFloat()
        if (!animate) { selPos = target; invalidate(); return }
        animF(selPos, target, 520L, OvershootInterpolator(1.15f)) { selPos = it; invalidate() }
    }
    private fun accentAt(p: Float): Int { val a = floor(p).toInt().coerceIn(0, 3); val b = min(3, a + 1); return mixColor(accents[a], accents[b], p - a) }
    override fun onDraw(c: Canvas) {
        val bar = RectF(dp(2), dp(4), width - dp(2), height - dp(4)); val rad = bar.height() / 2f
        c.drawRoundRect(bar, rad, rad, pill); c.drawRoundRect(bar, rad, rad, edge)
        val cell = bar.width() / 4f; val acc = accentAt(selPos)
        val cx = bar.left + cell * (selPos + 0.5f)
        val stretch = 1f + min(1f, abs(target - selPos)) * 0.22f
        val bw = cell * 0.86f * stretch; val bh = bar.height() - dp(12)
        rect.set(cx - bw / 2, bar.centerY() - bh / 2, cx + bw / 2, bar.centerY() + bh / 2)
        blob.color = alphaColor(acc, 0.10f); c.drawRoundRect(rect.left - dp(4), rect.top - dp(4), rect.right + dp(4), rect.bottom + dp(4), bh / 2, bh / 2, blob)
        blob.color = alphaColor(acc, 0.20f); c.drawRoundRect(rect, bh / 2, bh / 2, blob)
        for (i in 0 until 4) {
            val near = 1f - min(1f, abs(i - selPos))
            val ix = bar.left + cell * (i + 0.5f); val iy = bar.centerY() - dp(7) * near
            val col = mixColor(C.DIM, acc, near); ip.color = col; ifill.color = col
            icon(c, i, ix, iy, dp(24) * (1f + 0.1f * near))
            if (near > 0.02f) { lp.color = alphaColor(acc, near); c.drawText(labels[i], ix, bar.centerY() + dp(19), lp) }
        }
    }
    private fun icon(c: Canvas, i: Int, cx: Float, cy: Float, s: Float) {
        when (i) {
            0 -> {
                c.drawCircle(cx, cy + 0.06f * s, 0.36f * s, ip)
                c.drawLine(cx, cy + 0.06f * s, cx, cy - 0.12f * s, ip); c.drawLine(cx, cy + 0.06f * s, cx + 0.14f * s, cy + 0.14f * s, ip)
                rect.set(cx - 0.58f * s, cy - 0.46f * s, cx - 0.18f * s, cy - 0.06f * s); c.drawArc(rect, 180f, 90f, false, ip)
                rect.set(cx + 0.18f * s, cy - 0.46f * s, cx + 0.58f * s, cy - 0.06f * s); c.drawArc(rect, 270f, 90f, false, ip)
            }
            1 -> {
                c.drawCircle(cx, cy, 0.4f * s, ip); rect.set(cx - 0.17f * s, cy - 0.4f * s, cx + 0.17f * s, cy + 0.4f * s); c.drawOval(rect, ip)
                c.drawLine(cx - 0.4f * s, cy, cx + 0.4f * s, cy, ip)
            }
            2 -> {
                path.reset(); path.moveTo(cx - 0.28f * s, cy - 0.4f * s); path.lineTo(cx + 0.28f * s, cy - 0.4f * s); path.lineTo(cx, cy)
                path.lineTo(cx + 0.28f * s, cy + 0.4f * s); path.lineTo(cx - 0.28f * s, cy + 0.4f * s); path.lineTo(cx, cy); path.close(); c.drawPath(path, ip)
            }
            else -> {
                c.drawCircle(cx, cy + 0.06f * s, 0.36f * s, ip); c.drawLine(cx - 0.1f * s, cy - 0.46f * s, cx + 0.1f * s, cy - 0.46f * s, ip)
                c.drawLine(cx, cy - 0.46f * s, cx, cy - 0.3f * s, ip); c.drawLine(cx, cy + 0.06f * s, cx + 0.15f * s, cy - 0.1f * s, ip)
            }
        }
    }
    override fun onTouchEvent(e: MotionEvent): Boolean {
        if (e.actionMasked == MotionEvent.ACTION_DOWN) return true
        if (e.actionMasked == MotionEvent.ACTION_UP) {
            val i = ((e.x - dp(2)) / ((width - dp(4)) / 4f)).toInt().coerceIn(0, 3)
            if (i != sel) { thud(); select(i); onSelect?.invoke(i) }
        }
        return true
    }
}
