package com.chronox.clock

import android.content.Context
import android.graphics.*
import android.view.View
import android.view.animation.LinearInterpolator
import java.util.TimeZone
import kotlin.math.*

/** ~4.4 s cinematic intro: starfield, bloom, drawing rings, ticks cascade, hands spin to real time, shockwave + particles, title reveal. */
class SplashView(ctx: Context, private val onReveal: () -> Unit, private val onDone: () -> Unit) : View(ctx) {
    private var t = 0f
    private var revealed = false
    private val rnd = java.util.Random(11)
    private val pa = FloatArray(110) { rnd.nextFloat() * 6.2832f }
    private val ps = FloatArray(110) { 0.35f + rnd.nextFloat() * 0.8f }
    private val pz = FloatArray(110) { 1f + rnd.nextFloat() * 3.2f }
    private val pc = IntArray(110) { intArrayOf(C.CYAN, C.VIOLET, C.MAGENTA, C.ORANGE, Color.WHITE)[rnd.nextInt(5)] }
    private val sx = FloatArray(90) { rnd.nextFloat() }; private val sy = FloatArray(90) { rnd.nextFloat() }; private val sp = FloatArray(90) { 1f + rnd.nextFloat() * 3f }
    private val fill = fillPaint(); private val ring = strokePaint(Color.WHITE, dp(5)); private val thin = strokePaint(Color.WHITE, dp(1.5f))
    private val tick = strokePaint(Color.WHITE, dp(2)); private val hand = strokePaint(Color.WHITE, dp(5))
    private val letter = textPaint(Color.WHITE, dp(42), BOLD); private val tag = textPaint(C.DIM, dp(12), MED, Paint.Align.CENTER)
    private val oval = RectF(); private val m = Matrix()
    private var sweep: SweepGradient? = null
    private val tz = TimeZone.getDefault()
    private val title = "CHRONOX"

    init {
        animF(0f, 1f, 4400L, LinearInterpolator(), 0L, { onDone() }) {
            t = it
            if (!revealed && it > 0.9f) { revealed = true; onReveal() }
            alpha = 1f - smooth(seg(it, 0.92f, 1f)); val s = 1f + 0.18f * smooth(seg(it, 0.88f, 1f)); scaleX = s; scaleY = s
            invalidate()
        }
    }
    override fun onSizeChanged(w: Int, h: Int, ow: Int, oh: Int) {
        sweep = SweepGradient(w / 2f, h * 0.40f, intArrayOf(C.CYAN, C.VIOLET, C.MAGENTA, C.ORANGE, C.CYAN), null)
    }

    override fun onDraw(c: Canvas) {
        val w = width.toFloat(); val h = height.toFloat()
        c.drawColor(C.BG)
        val cx = w / 2f; val cy = h * 0.40f; val R = min(w, h) * 0.26f
        // stars
        val sa = seg(t, 0f, 0.15f)
        for (i in sx.indices) { fill.color = alphaColor(Color.WHITE, sa * (0.15f + 0.5f * (0.5f + 0.5f * sin(t * 20f * sp[i] + i)))); c.drawCircle(sx[i] * w, sy[i] * h, dp(1.2f), fill) }
        c.save(); val zoom = 0.9f + 0.1f * t; c.scale(zoom, zoom, cx, cy)
        // bloom
        val b = seg(t, 0.04f, 0.5f)
        if (b > 0f) {
            val br = R * (0.6f + 2.6f * easeOutCubic(b)); val ba = 0.55f * sin(min(1f, b) * 1.57f) * (1f - 0.5f * seg(t, 0.7f, 1f))
            fill.shader = RadialGradient(cx, cy, br, intArrayOf(alphaColor(C.VIOLET, ba), alphaColor(C.CYAN, ba * 0.35f), 0), floatArrayOf(0f, 0.5f, 1f), Shader.TileMode.CLAMP)
            c.drawCircle(cx, cy, br, fill); fill.shader = null
        }
        // rings
        val r1 = easeOutCubic(seg(t, 0.08f, 0.46f))
        m.reset(); m.postRotate(-90f + t * 360f, cx, cy); sweep?.setLocalMatrix(m)
        oval.set(cx - R, cy - R, cx + R, cy + R)
        ring.shader = sweep; ring.alpha = 255
        if (r1 > 0f) { ring.strokeWidth = dp(11); ring.alpha = 70; c.drawArc(oval, -90f, 360f * r1, false, ring); ring.strokeWidth = dp(5); ring.alpha = 255; c.drawArc(oval, -90f, 360f * r1, false, ring) }
        ring.shader = null
        val r2 = easeOutCubic(seg(t, 0.16f, 0.55f))
        thin.color = alphaColor(Color.WHITE, 0.55f); oval.set(cx - R * 1.2f, cy - R * 1.2f, cx + R * 1.2f, cy + R * 1.2f); c.drawArc(oval, 90f, -360f * r2, false, thin)
        val r3 = seg(t, 0.2f, 0.5f)
        if (r3 > 0f) {
            thin.color = alphaColor(C.CYAN, 0.5f * r3); thin.pathEffect = DashPathEffect(floatArrayOf(dp(3), dp(14)), t * dp(260))
            c.drawCircle(cx, cy, R * 1.38f, thin); thin.pathEffect = null
        }
        // ticks cascade
        for (i in 0 until 60) {
            val a = seg(t, 0.14f + i * 0.0045f, 0.14f + i * 0.0045f + 0.1f)
            if (a <= 0f) continue
            val ang = Math.toRadians(i * 6.0 - 90.0); val big = i % 5 == 0
            val len = (if (big) 0.16f else 0.09f) * R * easeOutBack(a)
            val ra = R * 0.9f
            tick.color = alphaColor(if (big) Color.WHITE else C.DIM, a); tick.strokeWidth = dp(if (big) 3f else 1.6f)
            c.drawLine(cx + cos(ang).toFloat() * ra, cy + sin(ang).toFloat() * ra, cx + cos(ang).toFloat() * (ra - len), cy + sin(ang).toFloat() * (ra - len), tick)
        }
        // hands spin to the real time
        val p = partsFor(tz, System.currentTimeMillis())
        val hA = ((p[0] % 12) + p[1] / 60f) * 30f; val mA = (p[1] + p[2] / 60f) * 6f
        val e = smooth(seg(t, 0.34f, 0.74f)); val ha = seg(t, 0.30f, 0.42f)
        if (ha > 0f) {
            fun hnd(deg: Float, len: Float, wd: Float, col: Int) {
                val a = Math.toRadians(deg - 90.0); hand.strokeWidth = wd; hand.color = alphaColor(col, ha)
                c.drawLine(cx, cy, cx + cos(a).toFloat() * R * len, cy + sin(a).toFloat() * R * len, hand)
            }
            hnd(hA - (1f - e) * 720f, 0.5f, dp(7), Color.WHITE)
            hnd(mA - (1f - e) * 2880f, 0.74f, dp(5), Color.WHITE)
            hnd(t * 7200f, 0.8f, dp(2.4f), C.MAGENTA)
            val pop = easeOutBack(seg(t, 0.68f, 0.8f))
            fill.color = C.CYAN; c.drawCircle(cx, cy, dp(9) * pop, fill); fill.color = C.BG; c.drawCircle(cx, cy, dp(3.5f) * pop, fill)
        }
        // shockwave + particles
        val sw = seg(t, 0.70f, 0.96f)
        if (sw > 0f) {
            thin.color = alphaColor(C.CYAN, 0.8f * (1f - sw)); thin.strokeWidth = dp(3) * (1f - sw) + 1f
            c.drawCircle(cx, cy, R * (1f + 2.6f * easeOutCubic(sw)), thin); thin.strokeWidth = dp(1.5f)
            for (i in pa.indices) {
                val d = R * (0.9f + 3.2f * ps[i] * easeOutCubic(sw))
                fill.color = alphaColor(pc[i], (1f - sw) * 0.9f)
                c.drawCircle(cx + cos(pa[i]) * d, cy + sin(pa[i]) * d, dp(pz[i]) * (1f - 0.6f * sw), fill)
            }
        }
        c.restore()
        // title
        letter.textSize = min(w, h) * 0.105f
        val gap = letter.textSize * 0.22f
        var tw = 0f; for (ch in title) tw += letter.measureText(ch.toString()) + gap
        tw -= gap
        var x = cx - tw / 2f; val ty = cy + R * 1.95f
        for (i in title.indices) {
            val a = seg(t, 0.62f + i * 0.04f, 0.62f + i * 0.04f + 0.14f)
            val s = easeOutBack(a); val chs = title[i].toString()
            letter.color = alphaColor(mixColor(C.CYAN, C.MAGENTA, i / 6f), a); letter.alpha = (255 * a).toInt()
            c.save(); c.translate(x, ty + (1f - a) * dp(36)); c.scale(0.6f + 0.4f * s, 0.6f + 0.4f * s)
            c.drawText(chs, 0f, 0f, letter); c.restore()
            x += letter.measureText(chs) + gap
        }
        // light sweep over title
        val ls = seg(t, 0.84f, 0.96f)
        if (ls > 0f && ls < 1f) {
            val lx = cx - tw / 2f + (tw + dp(80)) * ls - dp(40)
            fill.shader = LinearGradient(lx - dp(30), 0f, lx + dp(30), 0f, intArrayOf(0, 0x66FFFFFF, 0), null, Shader.TileMode.CLAMP)
            c.drawRect(cx - tw / 2f, ty - letter.textSize, cx + tw / 2f, ty + dp(8), fill); fill.shader = null
        }
        tag.letterSpacing = 0.3f; tag.color = alphaColor(C.DIM, seg(t, 0.8f, 0.92f))
        c.drawText("TIME, BEAUTIFULLY MASTERED", cx, ty + dp(36), tag)
    }
}
