package com.chronox.clock

import android.content.Context
import android.graphics.*
import android.graphics.drawable.GradientDrawable
import android.text.InputType
import android.text.format.DateFormat
import android.view.*
import android.view.animation.DecelerateInterpolator
import android.view.animation.OvershootInterpolator
import android.widget.*
import java.util.TimeZone
import kotlin.math.*

class AlarmCardView(ctx: Context, var alarm: Alarm, private val is24: Boolean, private val onToggle: (Boolean) -> Unit, private val onOpen: () -> Unit) : View(ctx) {
    private var on = if (alarm.enabled) 1f else 0f
    private val bg = fillPaint(); private val st = strokePaint(0x26FFFFFF, dp(1)); private val tp = textPaint(C.TEXT, dp(50), THIN)
    private val sub = textPaint(C.DIM, dp(14), REG); private val ap = textPaint(C.DIM, dp(16), MED)
    private val sw = fillPaint(); private val rect = RectF()
    private var downX = 0f; private var downY = 0f
    init { pressable() }
    fun updateAlarm(a: Alarm) { alarm = a; animF(on, if (a.enabled) 1f else 0f, 300L, DecelerateInterpolator()) { on = it; invalidate() } }
    override fun onDraw(c: Canvas) {
        val th = themeFor(alarm.theme, alarm.hour)
        rect.set(dp(6), dp(6), width - dp(6), height - dp(6))
        bg.shader = LinearGradient(rect.left, rect.top, rect.right, rect.bottom,
            intArrayOf(mixColor(0x2AFFFFFF, alphaColor(th.c2, 0.30f), on), mixColor(0x10FFFFFF, alphaColor(th.c1, 0.16f), on)), null, Shader.TileMode.CLAMP)
        c.drawRoundRect(rect, dp(28), dp(28), bg); bg.shader = null
        st.color = mixColor(0x22FFFFFF, alphaColor(th.c1, 0.55f), on); c.drawRoundRect(rect, dp(28), dp(28), st)
        if (on > 0.02f) { bg.color = alphaColor(th.c1, 0.9f * on); c.drawRoundRect(dp(6), height * 0.3f, dp(10), height * 0.7f, dp(2), dp(2), bg) }
        tp.color = mixColor(C.DIM, C.TEXT, on)
        val ts = hm(alarm.hour, alarm.minute, is24); val tx = dp(26); val ty = height * 0.52f
        c.drawText(ts, tx, ty, tp)
        if (!is24) { ap.color = mixColor(C.DIM, th.c1, on); c.drawText(ampmOf(alarm.hour), tx + tp.measureText(ts) + dp(6), ty, ap) }
        val label = (if (alarm.label.isBlank()) "Alarm" else alarm.label) + "  \u00B7  " + daysSummary(alarm.days)
        sub.color = mixColor(0xFF6A7090.toInt(), C.DIM, on); c.drawText(label, tx, height - dp(26), sub)
        drawSwitch(c, width - dp(26) - dp(58), dp(26), dp(58), dp(32), on, th.c1, sw)
        if (on > 0.05f) {
            sub.color = alphaColor(th.c1, on); sub.textAlign = Paint.Align.RIGHT
            c.drawText("in " + untilText(Scheduler.nextTrigger(alarm) - System.currentTimeMillis()), width - dp(26), height * 0.52f + dp(22), sub)
            sub.textAlign = Paint.Align.LEFT
        }
    }
    override fun onTouchEvent(e: MotionEvent): Boolean {
        when (e.actionMasked) {
            MotionEvent.ACTION_DOWN -> { downX = e.x; downY = e.y; return true }
            MotionEvent.ACTION_UP -> if (abs(e.x - downX) < dp(12) && abs(e.y - downY) < dp(12)) {
                if (e.x > width - dp(110) && e.y < height * 0.5f) { thud(); onToggle(!alarm.enabled) } else onOpen()
            }
        }
        return true
    }
}

class AlarmPage(ctx: Context) : Page(ctx) {
    private val is24 = DateFormat.is24HourFormat(ctx)
    private val scroll = FxScrollView(ctx)
    private val list = LinearLayout(ctx).apply { orientation = LinearLayout.VERTICAL }
    private val header = LiveHeader(ctx, is24) {
        val n = Scheduler.nextEnabled(ctx)
        if (n == null) "No alarms set" else "Next alarm in " + untilText(n - System.currentTimeMillis())
    }
    var onEditor: ((Boolean) -> Unit)? = null
    private val fab = CircleBtn(ctx, dp(72), true)
    private var editor: AlarmEditor? = null
    private val tickRun = object : Runnable { override fun run() { updateSubtitle(); postDelayed(this, 1000) } }

    init {
        scroll.addView(list, FrameLayout.LayoutParams(-1, -2)); addView(scroll, LayoutParams(-1, -1))
        fab.type = CircleBtn.TEXT; fab.label = "+"; fab.accent = C.VIOLET; fab.accent2 = C.CYAN
        fab.setOnClickListener { hold(); openEditor(null) }
        addView(fab, LayoutParams(-2, -2, Gravity.BOTTOM or Gravity.END))
        reload(false)
    }

    override fun applyInsets() {
        scroll.setPadding(dpi(18), topInset + dpi(18), dpi(18), bottomInset + dpi(96))
        (fab.layoutParams as LayoutParams).apply { bottomMargin = bottomInset + dpi(4); rightMargin = dpi(24) }
        fab.requestLayout(); scroll.applyFx()
    }
    override fun onShow() { post(tickRun) }
    override fun onHide() { removeCallbacks(tickRun) }
    override fun playEntrance() { reload(true) }
    override fun onAttachedToWindow() { super.onAttachedToWindow(); post(tickRun) }
    override fun onDetachedFromWindow() { removeCallbacks(tickRun); super.onDetachedFromWindow() }

    private fun updateSubtitle() {
        header.invalidate()
    }

    private fun reload(animate: Boolean, highlightId: Int = -1) {
        list.removeAllViews()
        list.addView(header, LinearLayout.LayoutParams(-1, dpi(150)).apply { bottomMargin = dpi(10) })
        val alarms = AlarmStore.load(context).sortedWith(compareBy({ it.hour }, { it.minute }))
        if (alarms.isEmpty()) {
            list.addView(tv(context, "Tap + to create your first alarm", 15f, C.DIM, REG).apply { gravity = Gravity.CENTER; setPadding(0, dpi(80), 0, 0) }, LinearLayout.LayoutParams(-1, -2))
        }
        alarms.forEachIndexed { i, a ->
            lateinit var cardRef: AlarmCardView
            lateinit var rowRef: SwipeRow
            val card = AlarmCardView(context, a, is24, { on ->
                val cur = AlarmStore.find(context, a.id)
                if (cur != null) {
                    cur.enabled = on; AlarmStore.upsert(context, cur)
                    if (on) { Scheduler.schedule(context, cur); toast("Rings in " + untilText(Scheduler.nextTrigger(cur) - System.currentTimeMillis())) } else Scheduler.cancel(context, cur)
                    cardRef.updateAlarm(cur); updateSubtitle()
                }
            }, { openEditor(AlarmStore.find(context, a.id)) })
            cardRef = card
            val row = SwipeRow(context, card, dpi(132)) {
                val cur = AlarmStore.find(context, a.id); if (cur != null) Scheduler.cancel(context, cur)
                AlarmStore.remove(context, a.id); list.removeView(rowRef); updateSubtitle()
            }
            rowRef = row
            list.addView(row)
            if (animate || a.id == highlightId) {
                row.alpha = 0f; row.translationY = dp(70); row.scaleX = 0.94f; row.scaleY = 0.94f
                row.animate().alpha(1f).translationY(0f).scaleX(1f).scaleY(1f).setStartDelay(60L * min(i, 8) + 60).setDuration(520).setInterpolator(OvershootInterpolator(0.9f)).start()
            }
        }
        updateSubtitle(); scroll.post { scroll.applyFx() }
    }

    private fun toast(s: String) = Toast.makeText(context, s, Toast.LENGTH_SHORT).show()

    fun openEditor(a: Alarm?) {
        if (editor != null) return
        val ed = AlarmEditor(context, a, is24, bottomInset, { saved ->
            val isNew = a == null
            AlarmStore.upsert(context, saved)
            try { Scheduler.schedule(context, saved) } catch (e: Exception) { }
            try { toast("Alarm rings in " + untilText(Scheduler.nextTrigger(saved) - System.currentTimeMillis())) } catch (e: Exception) { }
            closeEditor(); reload(false, if (isNew) saved.id else -1)
        }, { del ->
            Scheduler.cancel(context, del); AlarmStore.remove(context, del.id); closeEditor(); reload(false)
        }, { closeEditor() })
        editor = ed
        addView(ed, LayoutParams(-1, -1)); ed.open(); onEditor?.invoke(true)
    }
    private fun closeEditor() { onEditor?.invoke(false); editor?.close { editor?.let { removeView(it) }; editor = null } }
    fun handleBack(): Boolean { if (editor != null) { closeEditor(); return true }; return false }
}

class AlarmEditor(ctx: Context, private val src: Alarm?, is24: Boolean, bottomPad: Int, private val onSave: (Alarm) -> Unit, private val onDelete: (Alarm) -> Unit, private val onClose: () -> Unit) : FrameLayout(ctx) {
    private val dim = View(ctx).apply { setBackgroundColor(0xB0000000.toInt()); alpha = 0f }
    private val sheet = FrameLayout(ctx)
    private val sheetBg = GradientDrawable(GradientDrawable.Orientation.TOP_BOTTOM, intArrayOf(THEMES[0].bg, 0xFF0C1022.toInt()))
    private val a = src?.copy() ?: Alarm(0, 7, 0)
    private val picker = TimePickerView(ctx, is24)
    private val rings = tv(ctx, "", 14f, C.CYAN, MED)
    private var preview: AlarmPlayer? = null
    private val stop = Runnable { preview?.stop(); preview = null }

    init {
        addView(dim, LayoutParams(-1, -1)); dim.setOnClickListener { onClose() }
        sheetBg.cornerRadii = floatArrayOf(dp(34), dp(34), dp(34), dp(34), 0f, 0f, 0f, 0f)
        sheet.background = sheetBg
        addView(sheet, LayoutParams(-1, -1).apply { topMargin = dpi(60) })
        val sv = FxScrollView(ctx, 0.5f); val col = LinearLayout(ctx).apply { orientation = LinearLayout.VERTICAL; setPadding(dpi(22), dpi(22), dpi(22), dpi(30) + bottomPad) }
        sv.addView(col, FrameLayout.LayoutParams(-1, -2)); sheet.addView(sv, LayoutParams(-1, -1))

        col.addView(tv(ctx, if (src == null) "New alarm" else "Edit alarm", 28f, C.TEXT, THIN))
        col.addView(rings, LinearLayout.LayoutParams(-2, -2).apply { topMargin = dpi(6); bottomMargin = dpi(8) })
        col.addView(picker, LinearLayout.LayoutParams(-1, dpi(200)))
        picker.set(a.hour, a.minute); picker.onChanged = { a.hour = picker.hour24(); a.minute = picker.minute(); updateRings() }
        updateRings()

        fun section(t: String) = col.addView(tv(ctx, t.uppercase(), 12f, C.DIM, MED).apply { letterSpacing = 0.12f }, LinearLayout.LayoutParams(-2, -2).apply { topMargin = dpi(22); bottomMargin = dpi(10) })
        section("Repeat")
        col.addView(DaysView(ctx, a.days, C.CYAN) { a.days = it; updateRings() }, LinearLayout.LayoutParams(-1, dpi(52)))
        section("Label")
        val et = EditText(ctx).apply {
            setText(a.label); hint = "Alarm name"; setHintTextColor(0xFF5B6180.toInt()); setTextColor(C.TEXT); textSize = 16f; typeface = REG
            setSingleLine(); inputType = InputType.TYPE_CLASS_TEXT; background = glassBg(dp(18)); setPadding(dpi(18), dpi(14), dpi(18), dpi(14))
            addTextChangedListener(object : android.text.TextWatcher {
                override fun afterTextChanged(s: android.text.Editable?) { a.label = s?.toString() ?: "" }
                override fun beforeTextChanged(s: CharSequence?, st: Int, c: Int, af: Int) {}
                override fun onTextChanged(s: CharSequence?, st: Int, b: Int, c: Int) {}
            })
        }
        col.addView(et, LinearLayout.LayoutParams(-1, -2))
        section("Sound")
        col.addView(ChipRow(ctx, ToneSynth.NAMES.take(7), a.sound.coerceIn(0, 6), C.CYAN) { a.sound = it; previewSound(it) }, LinearLayout.LayoutParams(-1, -2))
        section("Vibration")
        col.addView(ChipRow(ctx, AlarmPlayer.VIBE_NAMES, a.vibe, C.MAGENTA) { a.vibe = it; previewVibe(it) }, LinearLayout.LayoutParams(-1, -2))
        section("Snooze")
        val snz = listOf(0, 5, 10, 15)
        col.addView(ChipRow(ctx, listOf("Off", "5 min", "10 min", "15 min"), snz.indexOf(a.snooze).coerceAtLeast(0), C.ORANGE) { a.snooze = snz[it] }, LinearLayout.LayoutParams(-1, -2))
        section("Ring theme")
        val hs = HorizontalScrollView(ctx).apply { isHorizontalScrollBarEnabled = false; overScrollMode = View.OVER_SCROLL_NEVER }
        hs.addView(ThemePicker(ctx, a.theme) { a.theme = it; applyTheme() })
        col.addView(hs, LinearLayout.LayoutParams(-1, -2))
        val g = LinearLayout(ctx).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
        g.addView(tv(ctx, "Gradually increase volume", 15f, C.TEXT, REG), LinearLayout.LayoutParams(0, -2, 1f))
        g.addView(SwitchView(ctx, a.gradual, C.GREEN) { a.gradual = it })
        col.addView(g, LinearLayout.LayoutParams(-1, -2).apply { topMargin = dpi(20) })

        val btns = LinearLayout(ctx).apply { orientation = LinearLayout.HORIZONTAL }
        if (src != null) btns.addView(ghostButton(ctx, "Delete", C.RED) { onDelete(src) }, LinearLayout.LayoutParams(0, dpi(56), 1f).apply { rightMargin = dpi(10) })
        else btns.addView(ghostButton(ctx, "Cancel", C.DIM) { onClose() }, LinearLayout.LayoutParams(0, dpi(56), 1f).apply { rightMargin = dpi(10) })
        btns.addView(bigButton(ctx, "Save", C.CYAN, C.VIOLET) {
            val out = a.copy(id = src?.id ?: AlarmStore.nextId(ctx), enabled = true)
            onSave(out)
        }, LinearLayout.LayoutParams(0, dpi(56), 2f))
        col.addView(btns, LinearLayout.LayoutParams(-1, -2).apply { topMargin = dpi(28) })
        applyTheme()
    }

    private fun applyTheme() {
        val th = themeFor(a.theme, a.hour)
        sheetBg.colors = intArrayOf(mixColor(th.bg, th.c2, 0.18f), 0xFF0C1022.toInt())
    }
    private fun updateRings() {
        val t = Scheduler.nextTrigger(a.copy(enabled = true))
        rings.text = "Rings in " + untilText(t - System.currentTimeMillis())
        applyTheme()
    }
    private fun previewSound(i: Int) {
        removeCallbacks(stop); preview?.stop()
        preview = AlarmPlayer(context).also { it.start(i, null, false, 0) }
        postDelayed(stop, 2600)
    }
    private fun previewVibe(i: Int) {
        removeCallbacks(stop); preview?.stop()
        preview = AlarmPlayer(context).also { it.vibrate(i) }
        postDelayed(stop, 1500)
    }
    fun open() {
        sheet.post {
            sheet.translationY = sheet.height.toFloat()
            animF(0f, 1f, 520L, DecelerateInterpolator(2f)) { sheet.translationY = (1 - it) * sheet.height; dim.alpha = it }
        }
    }
    fun close(done: () -> Unit) {
        removeCallbacks(stop); preview?.stop()
        animF(0f, 1f, 320L, DecelerateInterpolator(), 0L, { done() }) { sheet.translationY = it * sheet.height; dim.alpha = 1 - it }
    }
}

class LiveHeader(ctx: Context, private val is24: Boolean, private val next: () -> String) : View(ctx) {
    private val timeP = textPaint(C.TEXT, dp(60), THIN); private val secP = textPaint(C.CYAN, dp(22), MED)
    private val apP = textPaint(C.DIM, dp(16), MED); private val dateP = textPaint(C.DIM, dp(15), REG)
    private val nextP = textPaint(C.CYAN, dp(13), MED); private val chip = fillPaint(); private val chipS = strokePaint(0x44FFFFFF, dp(1))
    private val df = java.text.SimpleDateFormat("EEEE, d MMMM", java.util.Locale.getDefault())
    private val rect = RectF()
    override fun onDraw(c: Canvas) {
        val now = System.currentTimeMillis(); val tz = TimeZone.getDefault(); val p = partsFor(tz, now)
        val ts = hm(p[0], p[1], is24); val x = dp(4); val y = height * 0.44f
        c.drawText(ts, x, y, timeP)
        val w = timeP.measureText(ts)
        c.drawText(":" + two(p[2]), x + w + dp(4), y, secP)
        if (!is24) c.drawText(ampmOf(p[0]), x + w + dp(6), y - dp(26), apP)
        c.drawText(df.format(java.util.Date(now)), x + dp(4), y + dp(28), dateP)
        val t = next(); val tw = nextP.measureText(t)
        rect.set(x, height - dp(40), x + tw + dp(28), height - dp(8))
        chip.color = 0x1A3DE0FF; c.drawRoundRect(rect, dp(16), dp(16), chip); c.drawRoundRect(rect, dp(16), dp(16), chipS)
        c.drawText(t, rect.left + dp(14), rect.centerY() + dp(5), nextP)
        drawAnalog(c, width - dp(56), height * 0.46f, dp(52), tz, C.VIOLET, true)
        postInvalidateOnAnimation()
    }
}
