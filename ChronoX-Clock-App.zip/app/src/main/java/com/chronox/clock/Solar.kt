package com.chronox.clock

import android.graphics.*
import java.util.concurrent.atomic.AtomicBoolean
import kotlin.math.*

class SNoise(seed: Long) {
    private val g = FloatArray(256 * 256)
    init { val r = java.util.Random(seed); for (i in g.indices) g[i] = r.nextFloat() }
    private fun cell(ix: Int, iy: Int): Float = g[((iy and 255) shl 8) or (ix and 255)]
    fun at(x: Float, y: Float, per: Int): Float {
        val x0 = floor(x).toInt(); val y0 = floor(y).toInt()
        val fx = x - x0; val fy = y - y0
        val sx = fx * fx * (3f - 2f * fx); val sy = fy * fy * (3f - 2f * fy)
        val xa = Math.floorMod(x0, per); val xb = Math.floorMod(x0 + 1, per)
        val a = cell(xa, y0); val b = cell(xb, y0); val c = cell(xa, y0 + 1); val d = cell(xb, y0 + 1)
        return a + (b - a) * sx + (c - a) * sy + (a - b - c + d) * sx * sy
    }
    fun fbm(u: Float, v: Float, oct: Int, base: Int = 16): Float {
        var f = base; var amp = 0.5f; var s = 0f; var norm = 0f
        for (k in 0 until oct) { s += amp * at(u * f, v * f * 0.5f, f); norm += amp; amp *= 0.5f; f *= 2 }
        return s / norm
    }
}

class MoonDef(val name: String, val parent: Int, val periodD: Double, val orbitMult: Float, val sizeRatio: Float, val phase0: Float, val incl: Float, val color: Int)

object Solar {
    val NAMES = listOf("Sun", "Mercury", "Venus", "Earth", "Mars", "Jupiter", "Saturn", "Uranus", "Neptune")
    // JPL approximate Keplerian elements (1800-2050): a, da, e, de, I, dI, L, dL, long.peri, d, long.node, d  (per century)
    val EL = arrayOf(
        doubleArrayOf(0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0),
        doubleArrayOf(0.38709927, 0.00000037, 0.20563593, 0.00001906, 7.00497902, -0.00594749, 252.25032350, 149472.67411175, 77.45779628, 0.16047689, 48.33076593, -0.12534081),
        doubleArrayOf(0.72333566, 0.00000390, 0.00677672, -0.00004107, 3.39467605, -0.00078890, 181.97909950, 58517.81538729, 131.60246718, 0.00268329, 76.67984255, -0.27769418),
        doubleArrayOf(1.00000261, 0.00000562, 0.01671123, -0.00004392, -0.00001531, -0.01294668, 100.46457166, 35999.37244981, 102.93768193, 0.32327364, 0.0, 0.0),
        doubleArrayOf(1.52371034, 0.00001847, 0.09339410, 0.00007882, 1.84969142, -0.00813131, -4.55343205, 19140.30268499, -23.94362959, 0.44441088, 49.55953891, -0.29257343),
        doubleArrayOf(5.20288700, -0.00011607, 0.04838624, -0.00013253, 1.30439695, -0.00183714, 34.39644051, 3034.74612775, 14.72847983, 0.21252668, 100.47390909, 0.20469106),
        doubleArrayOf(9.53667594, -0.00125060, 0.05386179, -0.00050991, 2.48599187, 0.00193609, 49.95424423, 1222.49362201, 92.59887831, -0.41897216, 113.66242448, -0.28867794),
        doubleArrayOf(19.18916464, -0.00196176, 0.04725744, -0.00004397, 0.77263783, -0.00242939, 313.23810451, 428.48202785, 170.95427630, 0.40805281, 74.01692503, 0.04240589),
        doubleArrayOf(30.06992276, 0.00026291, 0.00859048, 0.00005105, 1.77004347, 0.00035372, -55.12002969, 218.45945325, 44.96476227, -0.32241464, 131.78422574, -0.00508664)
    )
    val R_KM = floatArrayOf(695700f, 2439.7f, 6051.8f, 6371f, 3389.5f, 69911f, 58232f, 25362f, 24622f)
    val ROT_H = floatArrayOf(609.12f, 1407.6f, -5832.5f, 23.934f, 24.623f, 9.925f, 10.656f, -17.24f, 16.11f)
    val POLE = arrayOf(floatArrayOf(0f, 86f), floatArrayOf(0f, 89.9f), floatArrayOf(0f, -87f), floatArrayOf(90f, 66.56f), floatArrayOf(353f, 64.8f),
        floatArrayOf(0f, 86.9f), floatArrayOf(79.5f, 61.95f), floatArrayOf(78f, -7.8f), floatArrayOf(311f, 61.7f))
    val COL = intArrayOf(0xFFFFC857.toInt(), 0xFFB8B1A8.toInt(), 0xFFF2D49B.toInt(), 0xFF5CA8FF.toInt(), 0xFFFF7A4D.toInt(), 0xFFE8C9A0.toInt(), 0xFFF3DC9A.toInt(), 0xFF8FE8F0.toInt(), 0xFF5D7CFF.toInt())
    val ATMO = intArrayOf(0, 0, 0xFFFFD79A.toInt(), 0xFF6AA8FF.toInt(), 0xFFFFB38A.toInt(), 0xFFFFE0B0.toInt(), 0xFFFFE9B5.toInt(), 0xFF9AF0FF.toInt(), 0xFF6C8CFF.toInt(), 0)
    val ATMO_K = floatArrayOf(0f, 0f, 1.0f, 1.1f, 0.35f, 0.45f, 0.4f, 0.8f, 0.8f, 0f)
    val YEAR_D = doubleArrayOf(0.0, 87.97, 224.7, 365.25, 686.98, 4332.6, 10759.2, 30688.5, 60182.0)
    val TYPE = listOf("Star", "Rocky planet", "Rocky planet", "Rocky planet \u00B7 Home", "Rocky planet", "Gas giant", "Gas giant", "Ice giant", "Ice giant")
    val DAY = listOf("25.4 d (equator)", "58.6 Earth days", "243 d (retrograde)", "23 h 56 m", "24 h 37 m", "9 h 56 m", "10 h 33 m", "17 h 14 m (retrograde)", "16 h 6 m")
    val MOONS_TXT = listOf("\u2013", "no moons", "no moons", "1 moon", "2 moons", "95 moons", "146 moons", "28 moons", "16 moons")
    val TEMP = listOf("5,500 \u00B0C surface", "167 \u00B0C avg", "464 \u00B0C", "15 \u00B0C avg", "\u221265 \u00B0C avg", "\u2212110 \u00B0C", "\u2212140 \u00B0C", "\u2212195 \u00B0C", "\u2212200 \u00B0C")
    val GRAV = listOf("274 m/s\u00B2", "3.7 m/s\u00B2", "8.9 m/s\u00B2", "9.8 m/s\u00B2", "3.7 m/s\u00B2", "24.8 m/s\u00B2", "10.4 m/s\u00B2", "8.7 m/s\u00B2", "11.2 m/s\u00B2")
    val FACT = listOf("Holds 99.86% of the Solar System's mass", "The fastest planet \u2013 a year lasts just 88 days",
        "Hottest planet, and it spins backwards", "The only known world with life", "Home of Olympus Mons, 22 km high",
        "Its Great Red Spot is a storm wider than Earth", "Rings 280,000 km wide but only ~10 m thick", "Rolls around the Sun tilted on its side", "Winds reach 2,100 km/h")
    val MOONS = listOf(
        MoonDef("Moon", 3, 27.3217, 4.2f, 0.27f, Math.toRadians(218.316).toFloat(), 5f, 0xFFD6D6DA.toInt()),
        MoonDef("Phobos", 4, 0.3189, 2.0f, 0.06f, 0.5f, 1f, 0xFFA89888.toInt()),
        MoonDef("Deimos", 4, 1.263, 3.1f, 0.045f, 2.2f, 2f, 0xFFB5A593.toInt()),
        MoonDef("Io", 5, 1.769, 2.5f, 0.05f, 0.3f, 0f, 0xFFF0D870.toInt()),
        MoonDef("Europa", 5, 3.551, 3.2f, 0.043f, 1.9f, 0f, 0xFFE8E0D0.toInt()),
        MoonDef("Ganymede", 5, 7.155, 4.1f, 0.075f, 4.0f, 0f, 0xFFB5ADA3.toInt()),
        MoonDef("Callisto", 5, 16.689, 5.3f, 0.068f, 5.2f, 0f, 0xFF8C8478.toInt()),
        MoonDef("Titan", 6, 15.945, 4.0f, 0.12f, 1.1f, 0f, 0xFFE0A850.toInt()),
        MoonDef("Titania", 7, 8.706, 2.6f, 0.06f, 0.8f, 0f, 0xFFB8B0A8.toInt()),
        MoonDef("Oberon", 7, 13.46, 3.4f, 0.06f, 3.6f, 0f, 0xFF9A9088.toInt()),
        MoonDef("Triton", 8, -5.877, 2.8f, 0.08f, 2.4f, 20f, 0xFFD8C8C0.toInt())
    )
    val SPEED_NAMES = listOf("Live", "1 hr/s", "4 hr/s", "1 day/s", "1 wk/s", "1 mo/s", "1 yr/s", "10 yr/s")
    val SPEEDS = doubleArrayOf(1.0 / 86400.0, 1.0 / 24.0, 1.0 / 6.0, 1.0, 7.0, 30.4375, 365.25, 3652.5)

    fun dispR(i: Int): Float = if (i == 0) 0.16f else 0.035f * (R_KM[i] / 6371f).pow(0.45f)
    fun focusMult(i: Int): Float = when (i) { 0 -> 4.4f; 3 -> 5.6f; 4 -> 5.0f; 5 -> 7.2f; 6 -> 7.6f; 7 -> 6.4f; 8 -> 5.6f; else -> 4.4f }
    fun poleVec(i: Int, out: FloatArray) {
        val lo = Math.toRadians(POLE[i][0].toDouble()); val la = Math.toRadians(POLE[i][1].toDouble())
        out[0] = (cos(la) * cos(lo)).toFloat(); out[1] = (cos(la) * sin(lo)).toFloat(); out[2] = sin(la).toFloat()
    }

    /** Heliocentric ecliptic position in AU for planet i at d days since J2000 (E: eccentric anomaly override when >= 0, used for orbit lines). */
    fun helio(i: Int, d: Double, o: DoubleArray, eOverride: Double = -100.0) {
        val e = EL[i]; val t = d / 36525.0
        val a = e[0] + e[1] * t; val ec = e[2] + e[3] * t; val inc = Math.toRadians(e[4] + e[5] * t)
        val l = e[6] + e[7] * t; val wp = e[8] + e[9] * t; val om = Math.toRadians(e[10] + e[11] * t)
        var ea: Double
        if (eOverride > -50.0) ea = eOverride
        else {
            var m = Math.toRadians((l - wp) % 360.0)
            while (m > PI) m -= 2 * PI
            while (m < -PI) m += 2 * PI
            ea = m + ec * sin(m)
            for (k in 0 until 6) ea -= (ea - ec * sin(ea) - m) / (1 - ec * cos(ea))
        }
        val xp = a * (cos(ea) - ec); val yp = a * sqrt(1 - ec * ec) * sin(ea)
        val w = Math.toRadians(wp) - om
        val cw = cos(w); val sw = sin(w); val co = cos(om); val so = sin(om); val ci = cos(inc); val si = sin(inc)
        o[0] = (cw * co - sw * so * ci) * xp + (-sw * co - cw * so * ci) * yp
        o[1] = (cw * so + sw * co * ci) * xp + (-sw * so + cw * co * ci) * yp
        o[2] = (sw * si) * xp + (cw * si) * yp
    }
    fun semiMajor(i: Int, d: Double): Double = EL[i][0] + EL[i][1] * d / 36525.0
}

object SolarTex {
    const val W = 512
    const val H = 256
    @Volatile var ready = false
    val tex = arrayOfNulls<IntArray>(10)
    val sprites = arrayOfNulls<Bitmap>(10)
    private val busy = AtomicBoolean(false)

    fun ensure() {
        if (ready || !busy.compareAndSet(false, true)) return
        Thread { try { build() } catch (e: Throwable) { busy.set(false) } }.also { it.priority = Thread.NORM_PRIORITY - 1; it.start() }
    }
    private fun sm(e0: Float, e1: Float, x: Float): Float { val t = ((x - e0) / (e1 - e0)).coerceIn(0f, 1f); return t * t * (3f - 2f * t) }
    private fun mixf(a: Float, b: Float, t: Float) = a + (b - a) * t
    private fun pack(r: Float, g: Float, b: Float): Int = (255 shl 24) or (r.toInt().coerceIn(0, 255) shl 16) or (g.toInt().coerceIn(0, 255) shl 8) or b.toInt().coerceIn(0, 255)
    private fun scale(c: Int, f: Float): Int {
        val r = (((c shr 16) and 255) * f).toInt().coerceIn(0, 255); val g = (((c shr 8) and 255) * f).toInt().coerceIn(0, 255); val b = ((c and 255) * f).toInt().coerceIn(0, 255)
        return (255 shl 24) or (r shl 16) or (g shl 8) or b
    }

    private fun craters(px: IntArray, count: Int, seed: Int, strength: Float) {
        val rnd = java.util.Random(seed.toLong())
        for (k in 0 until count) {
            val u0 = rnd.nextFloat(); val lat0 = (rnd.nextFloat() * 2f - 1f) * 1.3f
            val rr = 0.02f + rnd.nextFloat().pow(3f) * 0.15f
            val cx = u0 * W; val cy = (0.5f - lat0 / 3.14159265f) * H
            val cosL = max(0.25f, cos(lat0))
            val rx = (rr / cosL) / 6.2831853f * W; val ry = rr / 3.14159265f * H
            val x0 = (cx - rx * 1.3f).toInt(); val x1 = (cx + rx * 1.3f).toInt()
            val y0 = max(0, (cy - ry * 1.3f).toInt()); val y1 = min(H - 1, (cy + ry * 1.3f).toInt())
            for (yy in y0..y1) for (xx in x0..x1) {
                val dx = (xx - cx) / rx; val dy = (yy - cy) / ry; val d = sqrt(dx * dx + dy * dy)
                if (d > 1.3f) continue
                val f = if (d < 0.88f) 1f - strength * (1f - d * d * 0.5f) * 0.5f else if (d < 1.15f) 1f + strength * 0.35f * (1f - abs(d - 1f) / 0.15f) else 1f
                val i = yy * W + Math.floorMod(xx, W)
                px[i] = scale(px[i], f)
            }
        }
    }

    private fun gen(idx: Int): IntArray {
        val out = IntArray(W * H)
        val n1 = SNoise(101L + idx); val n2 = SNoise(202L + idx); val n3 = SNoise(303L + idx)
        for (y in 0 until H) {
            val v = (y + 0.5f) / H; val lat = (0.5f - v) * 3.14159265f; val alat = abs(lat)
            for (x in 0 until W) {
                val u = (x + 0.5f) / W
                var r: Float; var g: Float; var b: Float
                when (idx) {
                    0 -> {
                        val n = n1.fbm(u, v, 6, 16); val gr = n2.fbm(u, v, 4, 64)
                        r = 255f; g = mixf(135f, 225f, n * 0.7f + gr * 0.4f); b = mixf(30f, 110f, n * 0.6f + gr * 0.3f)
                        val sp = sm(0.80f, 0.88f, n3.fbm(u, v, 3, 8)) * (1f - sm(0.45f, 0.8f, alat))
                        r = mixf(r, 120f, sp); g = mixf(g, 40f, sp); b = mixf(b, 8f, sp)
                    }
                    1 -> { val n = n1.fbm(u, v, 6, 8); val k = 0.62f + 0.6f * n; r = 160f * k; g = 152f * k; b = 144f * k }
                    2 -> {
                        val w = n1.fbm(u, v, 3, 6); val n = n2.fbm((u + w * 0.3f) % 1f, v + w * 0.2f, 5, 8)
                        val st = sin(lat * 7f + w * 5f) * 0.07f
                        r = mixf(222f, 248f, n) * (1f + st); g = mixf(186f, 228f, n) * (1f + st); b = mixf(112f, 170f, n)
                    }
                    3 -> {
                        val n = n1.fbm(u, v, 5, 8); val land = sm(0.52f, 0.58f, n)
                        r = mixf(18f, 70f, land); g = mixf(66f, 130f, land); b = mixf(140f, 60f, land)
                        val ice = sm(1.15f, 1.3f, alat); r = mixf(r, 240f, ice); g = mixf(g, 244f, ice); b = mixf(b, 250f, ice)
                    }
                    4 -> {
                        val n = n1.fbm(u, v, 5, 8); val dark = sm(0.50f, 0.62f, n2.fbm(u, v, 3, 4))
                        r = mixf(200f, 118f, dark * 0.75f) * (0.82f + 0.4f * n); g = mixf(112f, 68f, dark * 0.75f) * (0.82f + 0.4f * n); b = mixf(68f, 48f, dark * 0.75f) * (0.82f + 0.4f * n)
                        val cap = sm(1.32f, 1.42f, alat); r = mixf(r, 245f, cap); g = mixf(g, 242f, cap); b = mixf(b, 240f, cap)
                    }
                    5 -> {
                        val warp = n1.fbm(u, v * 2f, 4, 8)
                        val bands = sin(lat * 9.5f + warp * 3.4f) * 0.5f + 0.5f; val belts = sin(lat * 21f + warp * 5f) * 0.5f + 0.5f
                        val streak = n2.fbm(u, v, 5, 32); val k = (0.82f + 0.3f * belts) * (0.9f + 0.2f * streak)
                        r = mixf(230f, 176f, bands) * k; g = mixf(210f, 118f, bands) * k; b = mixf(172f, 84f, bands) * k
                        var du = u - 0.30f; if (du > 0.5f) du -= 1f else if (du < -0.5f) du += 1f
                        val dv = v - 0.622f; val q = (du / 0.055f) * (du / 0.055f) + (dv / 0.028f) * (dv / 0.028f)
                        if (q < 1.6f) { val s = sm(1.6f, 0.3f, q); r = mixf(r, 196f, s); g = mixf(g, 78f, s); b = mixf(b, 52f, s) }
                    }
                    6 -> {
                        val warp = n1.fbm(u, v * 2f, 3, 8); val bands = sin(lat * 13f + warp * 2.2f) * 0.5f + 0.5f
                        val streak = n2.fbm(u, v, 4, 32); val k = 0.9f + 0.14f * streak
                        r = mixf(232f, 206f, bands) * k; g = mixf(212f, 176f, bands) * k; b = mixf(158f, 118f, bands) * k
                    }
                    7 -> {
                        val bands = sin(lat * 8f) * 0.5f + 0.5f; val n = n1.fbm(u, v, 3, 8)
                        r = mixf(150f, 170f, bands) * (0.96f + 0.06f * n); g = mixf(218f, 232f, bands) * (0.96f + 0.06f * n); b = mixf(226f, 238f, bands)
                        val pole = sm(0.9f, 1.4f, alat) * 0.12f; r += 40f * pole; g += 30f * pole; b += 20f * pole
                    }
                    8 -> {
                        val warp = n1.fbm(u, v * 2f, 3, 8); val bands = sin(lat * 10f + warp * 2.5f) * 0.5f + 0.5f
                        r = mixf(52f, 36f, bands); g = mixf(92f, 66f, bands); b = mixf(210f, 176f, bands)
                        val cl = sm(0.70f, 0.82f, n2.fbm(u, v * 3f, 5, 32)); r = mixf(r, 235f, cl * 0.8f); g = mixf(g, 240f, cl * 0.8f); b = mixf(b, 255f, cl * 0.8f)
                        var du = u - 0.60f; if (du > 0.5f) du -= 1f else if (du < -0.5f) du += 1f
                        val dv = v - 0.57f; val q = (du / 0.07f) * (du / 0.07f) + (dv / 0.035f) * (dv / 0.035f)
                        if (q < 1f) { val s = sm(1f, 0.2f, q); r = mixf(r, 20f, s * 0.8f); g = mixf(g, 36f, s * 0.8f); b = mixf(b, 100f, s * 0.8f) }
                    }
                    else -> {
                        val n = n1.fbm(u, v, 6, 8); val maria = sm(0.50f, 0.58f, n2.fbm(u, v, 3, 4))
                        val k = 0.7f + 0.55f * n; val m = mixf(1f, 0.55f, maria)
                        r = 170f * k * m; g = 168f * k * m; b = 165f * k * m
                    }
                }
                out[y * W + x] = pack(r, g, b)
            }
        }
        when (idx) { 1 -> craters(out, 260, 1, 0.55f); 9 -> craters(out, 220, 2, 0.5f); 4 -> craters(out, 70, 3, 0.3f) }
        return out
    }

    private fun build() {
        for (i in 0 until 10) tex[i] = gen(i)
        for (i in 0 until 10) makeSprite(i)
        ready = true
    }
    fun makeSprite(i: Int) {
        val size = 112; val px = IntArray(size * size)
        val ax = 0.15f; val ay = 0.92f; val az = 0.36f
        SphereR.render(px, size, i, ax, ay, az, 0.4f, -0.55f, 0.6f, 0.58f)
        sprites[i] = Bitmap.createBitmap(px, size, size, Bitmap.Config.ARGB_8888)
    }
}

object SphereR {
    private fun ch(a: Int, b: Int, c: Int, d: Int, tx: Float, ty: Float, sh: Int): Float {
        val a1 = ((a shr sh) and 255).toFloat(); val b1 = ((b shr sh) and 255).toFloat(); val c1 = ((c shr sh) and 255).toFloat(); val d1 = ((d shr sh) and 255).toFloat()
        val top = a1 + (b1 - a1) * tx; val bot = c1 + (d1 - c1) * tx
        return top + (bot - top) * ty
    }
    private fun sm3(e0: Float, e1: Float, x: Float): Float { val t = ((x - e0) / (e1 - e0)).coerceIn(0f, 1f); return t * t * (3f - 2f * t) }

    /** Renders a lit, rotating sphere. axis/light are in view space (x right, y up, z towards viewer). spin in radians. */
    fun render(out: IntArray, size: Int, idx: Int, ax: Float, ay: Float, az: Float, spin: Float, lx: Float, ly: Float, lz: Float) {
        val tex = SolarTex.tex[idx] ?: return
        val TW = SolarTex.W; val TH = SolarTex.H
        var e1x = ay; var e1y = -ax; var l1 = sqrt(e1x * e1x + e1y * e1y)
        if (l1 < 1e-3f) { e1x = 1f; e1y = 0f; l1 = 1f }
        e1x /= l1; e1y /= l1
        val e2x = -az * e1y; val e2y = az * e1x; val e2z = ax * e1y - ay * e1x
        val earth = idx == 3 && Planet.ready
        val emissive = idx == 0
        val ak = Solar.ATMO_K[idx]; val ac = Solar.ATMO[idx]
        val ar = ((ac shr 16) and 255).toFloat(); val ag = ((ac shr 8) and 255).toFloat(); val ab = (ac and 255).toFloat()
        val hx = lx; val hy = ly; val hz = lz + 1f
        val hn = max(1e-5f, sqrt(hx * hx + hy * hy + hz * hz)); val hxn = hx / hn; val hyn = hy / hn; val hzn = hz / hn
        val inv255 = 1f / 255f
        for (py in 0 until size) {
            val y = 1f - (py + 0.5f) * 2f / size
            for (px in 0 until size) {
                val i = py * size + px
                val x = (px + 0.5f) * 2f / size - 1f
                val d2 = x * x + y * y
                if (d2 >= 1f) { out[i] = 0; continue }
                val z = sqrt(1f - d2)
                val nA = x * ax + y * ay + z * az
                val lat = fastAtan2(nA, sqrt(max(0f, 1f - nA * nA)))
                val lon = fastAtan2(x * e2x + y * e2y + z * e2z, x * e1x + y * e1y) - spin
                var u = lon * 0.15915494f + 0.5f; u -= floor(u)
                val v = 0.5f - lat * 0.31830987f
                val lam = lx * x + ly * y + lz * z
                val lm = if (lam > 0f) lam else 0f
                var r: Float; var g: Float; var b: Float
                if (earth) {
                    val pw = Planet.TW; val ph = Planet.TH
                    val ui = (u * pw).toInt().coerceIn(0, pw - 1); val vi = (v * ph).toInt().coerceIn(0, ph - 1); val ti = vi * pw + ui
                    val dc = Planet.day[ti]
                    val landv = (Planet.landM[ti].toInt() and 255) * inv255
                    val cl = (Planet.cloud[ti].toInt() and 255) * inv255 * 0.9f
                    val li = (Planet.lights[ti].toInt() and 255) * inv255
                    val tw = sm3(-0.10f, 0.14f, lam)
                    val shade = 0.08f + 1.25f * lm
                    var dr = ((dc shr 16) and 255) * shade; var dg = ((dc shr 8) and 255) * shade; var db = (dc and 255) * shade
                    if (landv < 0.6f) {
                        val nd = x * hxn + y * hyn + z * hzn
                        if (nd > 0f) { val n2 = nd * nd; val n4 = n2 * n2; val n8 = n4 * n4; val n16 = n8 * n8; val n32 = n16 * n16; val n64 = n32 * n32
                            val sp = (n64 * n32 * 1.1f) * (1f - cl); dr += 255f * sp; dg += 245f * sp; db += 225f * sp }
                    }
                    val cb = 0.12f + 1.02f * lm
                    dr += (250f * cb - dr) * cl; dg += (252f * cb - dg) * cl; db += (255f * cb - db) * cl
                    var nr = 3f + 9f * landv; var ng = 6f + 13f * landv; var nb = 17f + 22f * landv
                    val lv = li * (1f - 0.85f * cl); nr += 255f * lv * 1.1f; ng += 188f * lv; nb += 92f * lv
                    r = nr + (dr - nr) * tw; g = ng + (dg - ng) * tw; b = nb + (db - nb) * tw
                } else {
                    val fu = u * TW - 0.5f; val fv = v * TH - 0.5f
                    val x0 = floor(fu).toInt(); val y0 = floor(fv).toInt(); val tx = fu - x0; val ty = fv - y0
                    val xa = Math.floorMod(x0, TW); val xb = Math.floorMod(x0 + 1, TW); val ya = y0.coerceIn(0, TH - 1); val yb = (y0 + 1).coerceIn(0, TH - 1)
                    val c00 = tex[ya * TW + xa]; val c10 = tex[ya * TW + xb]; val c01 = tex[yb * TW + xa]; val c11 = tex[yb * TW + xb]
                    r = ch(c00, c10, c01, c11, tx, ty, 16); g = ch(c00, c10, c01, c11, tx, ty, 8); b = ch(c00, c10, c01, c11, tx, ty, 0)
                    if (emissive) {
                        val limb = 0.5f + 0.6f * sqrt(z)
                        r *= limb * 1.05f; g *= limb * 1.05f; b *= limb * 1.05f
                    } else {
                        val shade = 0.035f + 1.14f * lm
                        r *= shade; g *= shade; b *= shade
                    }
                }
                if (ak > 0f) {
                    val fr = 1f - z; val f3 = fr * fr * fr
                    val rim = ak * f3 * (0.12f + 1.25f * lm)
                    r += ar * rim; g += ag * rim; b += ab * rim
                    val warm = exp(-lam * lam * 40f) * f3 * ak * 0.8f
                    r += 255f * warm; g += 110f * warm; b += 40f * warm
                }
                val rimD = if (d2 > 0.96f) sqrt(d2) else 0f
                val a = if (rimD > 0.985f) ((1f - rimD) / 0.015f * 255f).toInt().coerceIn(0, 255) else 255
                out[i] = (a shl 24) or (r.toInt().coerceIn(0, 255) shl 16) or (g.toInt().coerceIn(0, 255) shl 8) or b.toInt().coerceIn(0, 255)
            }
        }
    }
}
